# Leituras posteriores

`agregacao.py`, `metricas.py` e `previsoes.py` são utilitários compartilhados. `isolar_gradientes_cryptomamba.py` permanece no caminho exigido pelas fontes congeladas. As demais leituras estão agrupadas em `etapas/`:

| Etapa | Pasta |
|---|---|
| Simulações e comparações operacionais de futuros | [futuros](etapas/futuros/) |
| Diagnóstico operacional aprofundado | [diagnostico_operacional](etapas/diagnostico_operacional/) |
| Histórico acumulado versus móvel | [historico_treino](etapas/historico_treino/) |
| Reprodução e calibração da receita diária | [cryptomamba_diario](etapas/cryptomamba_diario/) |
| Conferência da reprodução | [cryptomamba_reproducivel](etapas/cryptomamba_reproducivel/) |
| Alvo de retorno diário | [alvo_retorno_diario](etapas/alvo_retorno_diario/) |
| Padronização e contribuição dos ramos | [padronizacao_diaria](etapas/padronizacao_diaria/) |
| Generalização e comparação das quatro moedas | [generalizacao_moedas](etapas/generalizacao_moedas/) |
| Retirada da penalização | [sem_penalizacao_diaria](etapas/sem_penalizacao_diaria/) |

Os originais estão preservados no pacote. Três leitores receberam somente ajustes dos caminhos de suas próprias fontes; a estrutura do código foi conferida sem outras alterações. O [índice de caminhos originais](../arquivo/desenvolvimento_encerrado/indice.json) registra a realocação e os hashes das versões adaptadas. O catálogo e os recibos identificam quais análises já foram executadas; a presença de um script não instrui sua repetição. Tabelas, figuras, carteiras e conferências existentes continuam nas pastas científicas originais.
