# Orientações para trabalhar no CryptoCasting

## Leitura inicial e estado atual

1. Ler `docs/exploracao_ia.md`: síntese única da fase exploratória com Astra posterior ao panorama web de 03/11/2026.
2. Consultar `plano.md`, `registros/catalogo_estudos.json` e o estado/ponteiro do ciclo pertinente. Documentação não substitui evidência do computador executor.
3. Para implementar, ler a arquitetura da camada afetada em `docs/arquitetura_*.md`; para preservar/transferir, `docs/armazenamento_e_reproducao.md`.
4. Decisões históricas e seus limites estão em `docs/adr/`; protocolos, fontes e orçamentos encerrados não são instruções atuais de execução.

Etapa de generalização diária para ETH, BNB e XRP **concluída e conferida em10/11/2026**, ADR0036, execução original `1f2b005888361d23c111`. ETH/BNB permanecem nos caminhos originais; XRP terminou em `XRPUSDT/continuacao_001` após interrupção externa. A tentativa de390épocas foi preservada; reexecução desde a época1 reproduziu os390registros científicos exatamente e controle42 passou. Nove ajustes principais e três controles novos,1000épocas cada,210carteiras; BTC `f3f8772670f244779ad7` herdado sem retreino. [Estado](registros/generalizacao_moedas/estado.json), [fechamento](registros/generalizacao_moedas/fechamento.json), [comparação das quatro moedas](registros/generalizacao_moedas/comparacao_quatro_moedas.json). Processo encerrado; autorização desta rodada cumprida. Nenhum novo treino, hipótese ou retreino BTC autorizado.

Manter receita padronizada, Adam0,01/decay0,001, arquitetura/alvo/seleção/política. Adaptar somente moeda, início de treino disponível, escalas próprias e filtros do instrumento. Os modelos são independentes, sem transferência de pesos. Qualificação aprovada; controle real exige mesma época e retorno exato antes das demais seeds/teste de cada moeda. Sondas posteriores dos ramos não selecionam modelos. A referência teve colapso funcional documentado; menor erro não significa vantagem operacional.

Dados oficiais e exceções estão congelados: cinco dias XRP complementados pela API; divergências de volume em14/29jan2025 conservam o arquivo diário; dois minutos de marcação XRP continuam ausentes no dado canônico, com envelope5m separado somente para risco. Não inventar candles ou excluir operações retrospectivamente. Fontes/dados/protocolos congelados imutáveis; verificar host/PID/boot/GPU/locks, não duplicar ou retomar automaticamente. Mamba-1 oficial, scan de referência CUDA sem fallback/fused.2024seleciona checkpoints;2025já consultado, retrospectivo.

Rodada sem penalização `8a0aeee4d78503b7f50d` e demais referências estão concluídas/preservadas; a hipótese de taxa menor permanece apenas proposta. A preparação antiga sem treino `92e3eb82e3f6adf99994` está indexada como histórica. A reorganização posterior autorizada pelo pesquisador consolidou fontes encerradas e versões editoriais anteriores no pacote histórico, agrupou leitores por etapa e removeu caches regeneráveis; recibos em `registros/organizacao_repositorio/20261110/`. O bloqueio de limpeza anterior permanece como incidente histórico. Não tratar organização local como backup externo.

## Objetivo e honestidade científica

Cenário operacional vigente escolhido pelo pesquisador em10/11/2026: **slippage provisório de0,01% por lado**, `configuracoes/custos_vigentes_001.json`. Reavaliação financeira sem treino em `registros/custos_vigentes/execucao.json`; publicação vigente somente após conferência integral, em `registros/custos_vigentes/vigente.json`. Não sobrescrever receitas, alvos, filtros, seleção ou publicações congeladas para simular um histórico diferente. Os5bp históricos permanecem na evidência original; a apresentação financeira vigente usa a releitura identificada. Não certificar1bp como custo real histórico Binance.

Prioridade atual do pesquisador: desenvolver Mamba + política operacional de futuros cripto, permitindo compras e vendas, buscando lucro líquido positivo, risco e estabilidade explícitos. Um ciclo negativo informa a próxima hipótese e não encerra automaticamente a pesquisa. Podemos propor alterações de entradas, alvo, candles, contexto, treinamento, arquitetura e política em etapas identificadas. Não garantir lucro, tratar busca finita como exaustiva ou escolher resultados favoráveis descartando os demais.

A proposta acadêmica original está em `docs/TCC_1_MuriloRFM.pdf`: OHLCV/indicadores, investigação iterativa e avaliação temporal. Objetivos e conclusões dos estudos anteriores permanecem históricos; a nova prioridade não os reescreve. Não presumir aprovação acadêmica de mudanças. LSTM, ARIMA e Naive são referências; definir sua participação por ciclo.

## Arquitetura e caminhos

- `mercado_binance/`: coleta, proveniência, validação e candles; `mercado_futuros/`: observações públicas de futuros. Não misturar escolha de entrada com coleta.
- `entradas_modelo/`: canais causais, alvos, contextos, divisões, purga e escalas. Mudar entradas não exige recoleta automaticamente.
- `modelos/`: contratos Mamba/LSTM, Naive e ARIMA. Dimensões das redes derivadas das entradas; ARIMA é univariado com histórico permitido próprio.
- `treinamento/` e `avaliacao/`: seleção, checkpoints e métricas. Consultar arquitetura e identidade antes de usar; versões científicas encerradas podem estar congeladas.
- `simulacao_operacoes/`: sinais, políticas e contabilidade separados; preços futuros/alvos observados nunca entram na decisão.
- `experimentos/`: novos ciclos com namespace próprio; `analises/`: leituras posteriores reutilizáveis, sem reabrir treinamento.
- `configuracoes/`: receitas; `registros/`: índices/evidências; `dados/experimentos/`: tentativas e publicações; `dados/diagnosticos/`: análises posteriores.
- `dados/reavaliacoes/`: revisões financeiras identificadas, com previsões preservadas e vínculo explícito aos estudos originais; não substituem os artefatos de treinamento.
- `arquivo/`: histórico preservado. Executores, testes específicos e ferramentas encerradas estão no pacote `arquivo/desenvolvimento_encerrado/fontes.zip`, com caminhos e hashes no índice. Remanescentes de `estudo_ohlcv/` e `experimento_cryptomamba/` são dependências reais ou fontes exigidas pela rodada ativa. Não restaurar todo o legado na área de trabalho por rotina.
- `dataview/`: panorama Next.js da trajetória até a generalização diária, com os detalhes OHLCV de03/11 preservados. Executar npm nesse diretório. Finanças vigentes usam a publicação de custos conferida; fontes originais continuam identificadas como históricas.

## Regras permanentes de execução

- Separar proposta, autorização, qualificação, identidade congelada, execução e auditoria. Cada ciclo exige escopo/orçamento identificados; autorização explícita já dada não exige confirmação redundante. Tetos não são metas de consumo.
- Antes de treinar, conferir ambiente/hardware, contratos/dimensões, forward/backward, atualização, reprodução e recarga. Mamba oficial CUDA; nenhum fallback silencioso ou computação paga não autorizada.
- Antes de iniciar/retomar, conferir host, PID Linux/Windows, lock, logs e progresso. Nunca duplicar processo vivo, inferir encerramento por timeout ou treinar para compensar artefatos ausentes em outra máquina.
- Selecionar checkpoints pelo critério definido na validação, não pelo teste. Qualificar controles antes da grade quando exigido; excluir controles das médias. Preservar seeds e pareamentos definidos no ciclo.
- Não chamar executor encerrado para regenerar relatórios. Usar leitura posterior identificada, com recibo próprio. Falhas e retomadas exigem diagnóstico e respeito ao protocolo específico; não repetir automaticamente.
- Fontes, configurações, protocolos, recibos e artefatos congelados são imutáveis sob sua identidade. Não regenerar hashes para aceitar divergências ou normalizar finais de linha em massa.
- Não enviar ordens reais. Autorizações de simulação não autorizam uso de conta, alavancagem real ou gastos.

## Dados, métricas e busca assistida por IA

- Ajustar scalers só no treino. Preservar causalidade, candles completos, unidades temporais, origens comuns, purga compatível com a realização do alvo e proveniência. Não interpolar lacunas ou selecionar exemplos pelo retorno futuro.
- Distinguir OHLCV coletado de canais efetivos, saída normalizada de retorno real, retorno terminal de payoff por lado, score de probabilidade e contexto de previsão de histórico de treino.
- Uma divisão fixa não é walk-forward. Reestimação por bloco usa somente passado permitido. Não aplicar checkpoint treinado no futuro a períodos anteriores.
- 2023 foi desenvolvimento adaptativo; 2024–2025 já foram consultados. Não alegar holdout intocado ao reutilizá-los. Verificar exposição específica de 2026 antes de reservar dados desse ano.
- Manter avaliador e proponente separados. Feedback deve mostrar sinal, suporte, regime, risco, custos e motivos de rejeição, não apenas retorno agregado. Não alimentar confirmação reservada ao processo de seleção.
- Identificar ablação de um fator versus comparação de receitas completas. Comparações exigem população/executor equivalentes ou diferenças declaradas. Histórico herdado não conta como novos treinos.
- Seeds e previsões horárias sobrepostas não são novos mercados independentes. Não somar retornos de carteiras independentes. Não inferir utilidade operacional de MSE isolado.
- Cortes descobertos nos diagnósticos são exploratórios; não promover filtros por lucro posterior. Permitir os dois lados não exige forçar atividade em todo regime.
- Lucro, drawdown, exposição, custos/funding e estabilidade são eixos distintos. Convenções de backtest não certificam execução, liquidação ou tarifas históricas Binance. Corrigir contabilidade e testar política são mudanças diferentes.

## Documentação e limpeza

- **Não criar um documento por interação.** Explicações ficam no chat. Esta fase usa `docs/exploracao_ia.md` como síntese; evoluir o documento pertinente antes de criar outro.
- `docs/README.md` é navegação, `plano.md` é próximo passo, `docs/andamento.md` é a cronologia única, `registros/catalogo_estudos.json` é o índice estruturado. Não repetir placares nesses guias.
- ADR somente para decisão material; protocolo/configuração para execução distinta; registros técnicos/logs/testes nas execuções. Não produzir versões concorrentes de síntese ou cópias de resultados sem função científica.
- Preservar antes de editar documentos vinculados a fechamentos. Não editar o PDF acadêmico compilado. Artefato ignorado pelo Git não está apagado nem protegido remotamente.
- Limpeza pode excluir caches/builds/temporários comprovadamente regeneráveis e conteúdo editorial redundante. Não apagar checkpoints, previsões, dados, incidentes, controles ou fontes porque o resultado foi ruim ou o arquivo foi gerado pelo Codex.
- Conferir dependências/hashes antes de excluir ou mover. Protocolos/relatórios encerrados mantidos por hash são anexos científicos, não desenhos vigentes. Não reescrever o histórico Git.
- Após manutenção, conferir vínculos, catálogo e integridade pertinente; relatar alcance e limitações. Fonte operacional: `python -m manutencao.auditar_repositorio --integridade --exigir-completo` no computador com os artefatos. A biblioteca original `auditar_catalogo.py` está preservada; o comando atual acrescenta a localização explícita dos bytes históricos no pacote, sem substituir hashes esperados. Fontes da rodada ativa permanecem nos caminhos reais.
- Identificadores novos em português; manter nomes oficiais dos argumentos das APIs.
