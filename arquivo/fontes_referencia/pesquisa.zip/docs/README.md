# Documentação do CryptoCasting

## Leitura principal

**[Exploração do processo de melhoria de modelos com IA](exploracao_ia.md)** reúne toda a fase Astra posterior ao panorama web de 03/11: propósito, evolução, resultados, limitações e requisitos para a próxima etapa. É a síntese única dessa fase; protocolos e relatórios por ciclo são anexos científicos preservados.

[Plano atual](../plano.md) · [Cronologia única](andamento.md) · [Catálogo](../registros/catalogo_estudos.json) · [Mapa dos registros](../registros/README.md).

## Base acadêmica e arquitetura

| Assunto | Documento |
|---|---|
| Proposta original e redação | [TCC1](TCC_1_MuriloRFM.pdf), [roteiro para o artigo](roteiro_redacao_tcc.md) |
| Projeto LaTeX e futura narrativa | [Espaço de escrita reservado](../escrita_tcc/README.md) |
| Referência OHLCV anterior | [Desenho](desenho_ohlcv24.md), [panorama web até 03/11](../dataview/README.md) |
| Dados e entradas | [Arquitetura dos dados](arquitetura_dados.md) |
| Contratos dos modelos | [Arquitetura dos modelos](arquitetura_modelos.md) |
| Treino e seleção | [Arquitetura do treinamento](arquitetura_treinamento.md) |
| Simulação de operações | [Arquitetura operacional](arquitetura_operacoes.md) |
| Registro e decisões | [Procedimento](registro_de_experimentos.md), [ADRs](adr/README.md) |
| Transporte e reprodução | [Política de preservação](armazenamento_e_reproducao.md) |

## Ciclo vigente

[Generalização para ETH, BNB e XRP](protocolo_generalizacao_moedas.md): receita diária padronizada concluída nas três moedas, modelos e dados separados por instrumento. [Comparação com BTC](../registros/generalizacao_moedas/comparacao_quatro_moedas.json). [Estado real](../registros/generalizacao_moedas/estado.json). Rodada sem penalização encerrada e demais comparações na [cronologia](andamento.md).

## Estudos encerrados e anexos

| Conjunto | Método e evidência |
|---|---|
| Estudos preliminares | [Arquivo acadêmico](../arquivo/estudos_preliminares_2026-10-28/README.md), [catálogo](../registros/catalogo_estudos.json) |
| Entradas e treinamento modular OHLCV | [Dados](arquitetura_dados.md), [treinamento](arquitetura_treinamento.md), [desenho](desenho_ohlcv24.md) |
| Estados, taxa e otimizador | [Estados](resultados_estados32_64.md), [taxa](resultados_taxa_aprendizado.md), [otimizador](resultados_otimizador_cryptomamba.md) |
| Perda e representação | [Huber](resultados_huber_blocos.md), [entradas](resultados_entradas_niveis.md), [combinação](resultados_crua_huber.md) |
| Exploração assistida por IA | [Síntese e mapa de evidências](exploracao_ia.md) |
| Políticas de futuros | [Arquitetura](arquitetura_operacoes.md), [revisão operacional](resultados_revisao_operacional.md), [busca operacional](resultados_operacional_futuros.md) |
| Receita diária e ablações | [Reprodução](protocolo_cryptomamba_reproducivel.md), [alvo](protocolo_alvo_retorno_diario.md), [padronização](protocolo_padronizacao_diaria.md), [penalização](protocolo_sem_penalizacao_diaria.md) |
| Código de análises posteriores | [Leitores por etapa](../analises/README.md) |
| Executores e ferramentas encerrados | [Pacote e recuperação verificada](../arquivo/desenvolvimento_encerrado/README.md) |

Os anexos da fase Astra estão indexados ao final da [síntese](exploracao_ia.md#8-onde-as-evidências-ficaram). Para localizar hipóteses anteriores de estados, taxa, otimizador, Huber e entradas, usar o [catálogo de estudos](../registros/catalogo_estudos.json) e o [panorama](../dataview/README.md). Os [estudos preliminares](../arquivo/estudos_preliminares_2026-10-28/README.md) preservam os desenhos antigos de retorno escalar e barreiras.

Os arquivos `protocolo_*.md`, `resultados_*.md`, `desenho_operacional_futuros.md` e `diagnostico_operacional.md` documentam identidades específicas. Sua presença nesta pasta não os torna desenhos atuais. Permanecem nos caminhos originais porque fontes, fechamentos, testes e leitores podem depender deles. Não criar um novo índice ou relatório por conversa; acrescentar informação à função documental pertinente.

As referências de [retorno diário](../registros/retomada_alvo_diario/estado.json) e de preço reproduzível estão concluídas e preservadas. Os respectivos protocolos são históricos; não instruem uma nova execução.
