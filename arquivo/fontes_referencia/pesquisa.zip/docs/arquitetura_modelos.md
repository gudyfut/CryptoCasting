# Consumo dos dados por Mamba, LSTM, Naive e ARIMA

Extensão ADR0031: `modelos/cryptomamba_diario.py` consome `[B,6,14]` e retorna preço emUSDT. Reutiliza somente o núcleo público conferido de `experimento_cryptomamba/modelo.py`, sem o adapter temporal histórico e sem modificar aquela fonte. Entradas em `entradas_modelo/cryptomamba_diario.py`; protocolo em `docs/protocolo_cryptomamba_diario.md`.

Referência de manutenção do módulo `modelos/`, implementado em 29/10/2026. Complementa a [arquitetura dos dados](arquitetura_dados.md), sem redefinir o [desenho científico](desenho_ohlcv24.md). Evidências em [registros/modelos/estado.json](../registros/modelos/estado.json). Esta etapa verifica contratos e inferência; não treina modelos nem seleciona parâmetros.

## 1. O contrato comum e as diferenças entre famílias

Todos recebem pedidos com as mesmas origens, mesmo destino de 24h e mesmo preço corrente. O pedido não contém o alvo observado nem o preço futuro. O alvo é acessado separadamente pelo futuro treinamento/avaliador.

| Família | Informação utilizada | Forma | Saída pública |
|---|---|---|---|
| Mamba | Mesmos canais OHLCV transformados/padronizados da LSTM | `[lote, contexto, canais]`; atualmente `[B,168,5]` | Um log-retorno terminal por origem |
| LSTM | Mesmas janelas e canais do Mamba | `[B,168,5]`, ordem temporal crescente | Um log-retorno terminal por origem |
| Naive | Origem/preço atual para identificar a previsão; não estima parâmetros | Pedido de origens | Zero de log-retorno, equivalente a preço terminal igual ao atual |
| ARIMA | Série regular de log-fechamentos, com lacunas explícitas | Vetor univariado até a origem; parâmetros recebidos externamente | Preço logarítmico terminal projetado menos log-preço corrente |

**Comparabilidade não significa entradas idênticas entre todas as famílias.** Mamba e LSTM têm igualdade de informação por janela. ARIMA é referência univariada e utiliza seu histórico filtrado, não uma janela OHLCV de 168×5. O limite de contexto de 168h é das redes; não apresentar o ARIMA como se ele usasse apenas essa semana. Acrescentar variáveis exógenas ou restringir sua memória seria outra decisão científica. A modularização conserva a definição anterior.

## 2. Organização dos arquivos

```text
mercado_binance/       dados de mercado auditados
entradas_modelo/       receita, alvo, populações e scalers
modelos/
  contratos.py        tipos, dimensões, identidade e formato de previsão
  consumo.py          ponte do conjunto preparado para cada família
  mamba.py            arquitetura Mamba-1 temporal oficial
  lstm.py             arquitetura LSTM temporal
  neurais.py          fábrica, inferência, conversão e recarga de pesos
  naive.py            persistência explícita
  arima.py            sistema ARIMA e previsão com parâmetros fornecidos
  conferencia.py     auditoria de todas as janelas reais, sem ajustes
tests_modelos/        contratos, causalidade, baselines e forward CUDA
run_modelos.py        comando exclusivo de conferência
```

Nenhum módulo novo importa executores históricos. Apenas o teste de equivalência lê a rede preservada para comparar o forward com os mesmos pesos. Dados de mercado e entradas não importam o módulo de modelos. Nenhuma dessas camadas contém seleção de época, otimizador ou loop de treinamento.

## 3. Como o consumidor recebe os dados

`carregar_consumo(pasta)` abre o conjunto publicado, verifica sua cadeia de hashes e cria uma cópia defensiva. Confere:

- nomes, ordem e número dos canais em contrato, matriz e escalas;
- matriz `float32`, índice posicional, timestamps regulares com fuso e horizonte;
- alvo `ln(C[t+24h]/C[t])` alinhado ao fechamento terminal correto;
- partições, contextos completos, origens causais e purga;
- consistência de cada linha de partição com o calendário completo.

`solicitar(particao, posicoes)` produz um pedido sem futuro observado. As posições são linhas daquela partição, não índices arbitrários de candles. Repetições, índices negativos, pedido de outro conjunto e metadados modificados são rejeitados. A identidade inclui dados, canais, contexto e escalas, evitando combinar pesos e entradas incompatíveis apenas porque ambos têm cinco colunas.

`lote_neural(pedido)` extrai exatamente os índices `i−W+1 ... i`, inclusive o candle encerrado na origem. Mantém a ordem temporal e dos canais. Nenhuma troca de eixos ocorre. Não materializa de uma vez todas as janelas do histórico: o consumidor pode pedir lotes pequenos.

`alvos_supervisionados(pedido)` é separado e recusa a população operacional, que pode conter destinos ainda indisponíveis. O futuro módulo de treinamento deverá utilizar esse método somente nos conjuntos apropriados. A política de ajustar exclusivamente no treino ainda precisa ser aplicada pelo executor: expor um alvo de validação ao avaliador não autoriza usá-lo no gradiente.

## 4. Redes e unidades da saída

```mermaid
flowchart LR
    A[Janela B × W × C] --> B[Projeção Mamba C → 32]
    B --> D[Blocos temporais Mamba e pré-LayerNorm]
    D --> F[Último instante e saída escalar]
    A --> E[LSTM temporal: C entradas, largura 32]
    E --> F
    F --> G[Saída normalizada z]
    G --> H[Retorno: z × escala do alvo + média do alvo]
```

O Mamba percorre o eixo do tempo. A LSTM usa `batch_first=True`, é unidirecional e reinicia o estado por janela; não transporta estado oculto entre lotes. Ambas usam o último instante para produzir um escalar. O Mamba conserva projeção, duas camadas, estado16, convolução4, expansão2, pré-LayerNorm e dropout da referência; a LSTM conserva duas camadas/largura32/dropout. A quantidade de canais passa a vir do contrato. Os parâmetros de arquitetura estão em [modelos_ohlcv24_001.json](../configuracoes/modelos_ohlcv24_001.json); seeds/otimização pertencem à futura orquestração, não à coleta ou ao forward.

Para as redes, `z=(y−média_treino)/escala_treino`; `inferir_normalizado` devolve z, e `prever_neural` devolve y em log-retorno, após uma única inversão. A saída pública tem forma `[B]`, nunca `[B,1]` misturada implicitamente com `[B]`, o que poderia produzir uma matriz de erros por broadcasting. Não converter Naive/ARIMA por essa escala: eles já produzem log-retorno real. Zero normalizado de uma rede significa a média do alvo de treino; **Naive significa zero real**.

Exemplo de interpretação: y=ln(1,02) equivale a +2%; a transformação para apresentação é `100×expm1(y)`, e o preço correspondente é `C[t]×exp(y)`. O alvo continua sendo o retorno terminal; isso não descreve o caminho intradiário nem garante execução de uma operação.

`criar_rede` exige CUDA. Mamba exige a classe oficial `mamba_ssm.modules.mamba_simple.Mamba` e as extensões compiladas; não há substituição silenciosa. Inferência exige `eval()` e desativa gradientes. A recarga confere família, configuração, identidade dos dados, canais e escalas antes de carregar os pesos. O pacote de pesos, sozinho, não comprova treinamento: a futura execução deverá vinculá-lo a tentativas, épocas e recibos.

Referências técnicas: [Mamba-1 oficial na versão instalada](https://github.com/state-spaces/mamba/blob/v2.2.6.post3/mamba_ssm/modules/mamba_simple.py), [LSTM no PyTorch](https://docs.pytorch.org/docs/2.6/generated/torch.nn.LSTM.html).

## 5. ARIMA: passado permitido, filtro e horizonte

O ARIMA recebe log-fechamentos brutos, sem a padronização multivariada da rede. A transformação numérica preservada é `(log(C)−base)×100`, com base no primeiro fechamento observado. A grade mantém NaNs nos candles ausentes: remover essas linhas encurtaria artificialmente o tempo.

`dados_ajuste_arima()` entrega somente o prefixo permitido para um ajuste futuro; não chama `fit`. O último índice permitido é a última origem de treino mais os24 passos do alvo, ainda anterior à fronteira de validação. Assim, pode usar fechamentos que já constituem os destinos dos alvos de treino. Isso conserva o critério da referência. Na base atual, o índice é26.278, correspondente a31/12/2023 às23hUTC como origem do fechamento disponível; nenhuma observação de2024 entra nesse prefixo.

`ParametrosARIMA` exige ordem, nomes/valores, base, identidade dos dados e último índice utilizado no ajuste. A previsão recusa parâmetros declarados como ajustados além do treino ou da origem solicitada. Essa proteção verifica metadados; os futuros recibos de ajuste deverão comprovar sua proveniência. Não pode demonstrar sozinha onde um vetor externo foi estimado.

`prever_arima` usa `filter` com parâmetros fixos e estados filtrados, nunca estados suavizados com futuro. Mesmo em um lote com diversas origens, a projeção de cada origem usa seu estado causal. O avanço é de24 passos horários, não um passo. Há conferência contra `get_forecast(24)` em prefixos sintéticos, para as nove ordens permitidas, incluindo lacuna. ARIMA(0,1,0) retorna zero exatamente, evitando criar direção por erro numérico.

Filtrar atualiza a estimativa do estado à medida que chegam observações; não reestima os parâmetros. Nenhum `fit`, busca entre ordens ou seleção por validação foi executado nesta revisão. A seleção futura continuará limitada aos nove candidatos previstos. Referência: [API de filtragem do statsmodels](https://www.statsmodels.org/stable/generated/statsmodels.tsa.arima.model.ARIMA.filter.html); versão instalada registrada na evidência.

## 6. Uso e verificações

```text
python run_modelos.py conferir --entradas dados/entradas/0420879c2afc454c7754
python -m unittest discover -s tests_modelos -v
```

O primeiro comando confere todas as janelas/partições, preparação do prefixo ARIMA e persistência, sem criar redes ou ajustar parâmetros. Gera recibo próprio em `registros/modelos/conferencias/`; falhas ficam na mesma tentativa. Os testes neurais exigem WSL/CUDA e registram skip quando indisponível; skip não vale como aprovação neural. Os testes atuais completos foram executados no ambiente CUDA, sem skips.

Verificações desta revisão:21 testes; igualdade exata de forward com as redes preservadas sob pesos idênticos; recarga exata; formatos com1/2/5 canais e contextos24/168 em fixtures; pesos inalterados e gradientes ausentes após inferência; proteção contra eixo/canal/tipo errado, alvo deslocado, futuro e parâmetros incompatíveis. Os parâmetros continuam20.257 no Mamba e13.473 na LSTM para cinco canais. As marcas de isenção de weight decay do Mamba foram preservadas; aplicar o otimizador corretamente será responsabilidade do módulo de treinamento.

No conjunto real foram conferidas24.751 janelas de treino,8.760 de validação,8.736 de teste e8.760 operacionais. As duas últimas populações se sobrepõem: esses números não representam observações independentes. Nenhuma previsão neural de mercado ou métrica comparativa foi produzida.

## 7. O que permanece pendente

O executor `estudo_ohlcv/` e a preparação `92e3eb82e3f6adf99994` continuam intactos. Na revisão seguinte de29/10, a [camada de treinamento e avaliação](arquitetura_treinamento.md) foi integrada por identidade própria. Seus ensaios sintéticos são evidências distintas dos testes de forward descritos aqui. A execução de mercado continua dependente de autorização explícita; nenhuma dessas qualificações comprova desempenho no mercado.
