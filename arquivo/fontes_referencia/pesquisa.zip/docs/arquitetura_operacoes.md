# Arquitetura das simulações de operação

Custos vigentes: `configuracoes/custos_vigentes_001.json`, slippage provisório de0,01% por lado. `analises/etapas/custos_vigentes/` reavalia somente execução, reproduz resultados originais antes de recalcular e publica em `dados/reavaliacoes/`, com índice separado. O leitor web valida o novo manifesto e os pais históricos; uma divergência bloqueia a apresentação como vigente. A seleção, os filtros e os alvos antigos continuam os do estudo original; reduzir slippage de execução não retroage ao treinamento.

Os identificadores legados dos cenários permanecem vínculos de proveniência; seus números no nome não definem o custo atual. A configuração vigente e o fator0,2 definem a execução revisada, com estresses proporcionais e zero inalterado. Leituras encerradas, inclusive seus gráficos/documentos vinculados, permanecem históricas; a interface usa as médias recompostas e as fontes vigentes separadas. [Publicação conferida](../registros/custos_vigentes/vigente.json).

Extensão ADR0031: `simulacao_operacoes/diaria_24h.py` recebe somente origens/previsões/preço conhecido para decidir. O mercado observado pertence à contabilidade. Uma posição diária é encerrada24h após entrada, com funding,comissões,slippage e envelope intraminuto. `experimentos/cryptomamba_diario/avaliacao.py` publica70carteiras e médias sem escolher política pelo teste. Protocolo: `docs/protocolo_cryptomamba_diario.md`.

## Auditoria posterior de custos — 10/11/2026

A receita diária histórica de0,05% de comissão e0,05% de slippage por lado não foi alterada. A [auditoria posterior](../registros/generalizacao_moedas/custos/ultima.json) separa comissão taker compatível com referência pública de slippage não calibrado. Livros atuais não certificam2024–2025. Sensibilidade mantém previsões/política e registra144carteiras; cenários não são escolhidos pelo lucro. A contabilidade não duplicou comissão/funding.

A divisãofloat do arredondador pode acrescentar um tick em preços exatamente na grade quando slippage adicional é zero; os casos positivos0,5–5bp examinados concordaram comDecimal em ticks inteiros. Não alterar o motor congelado para corrigir recibos antigos; qualquer versão futura de execução deve usar precisão robusta, qualificação e identidade novas. Tick/lot e descontos históricos precisam de proveniência própria. Ver [cronologia](andamento.md).

## Revisão F03

`simulacao_operacoes/revisada/` separa `regras.py` (lotes, filtros e redução), `conta.py` (comissão recebida e colateral), `politica.py` (decisão causal), `simulador.py` (tempo, funding e execução) e `auditoria.py` (fórmulas independentes). O coordenador é `python -B -m experimentos.revisao_operacional preparar|executar`; ações distintas, autorização/identidade próprias e bloqueio de repetição. Consultar [protocolo](protocolo_revisao_operacional.md) e [estado](../registros/revisao_operacional/estado.json). Fontes F01/F02 abaixo são históricas imutáveis. A conferência posterior `python -B -m analises.revisao_operacional` lê ledgers e recalcula risco, sem repetir carteiras.

Nenhum simulador promete reproduzir integralmente uma conta Binance. Custos, filtros conservadores, preço de execução aproximado e envelope prudencial são identificados. Não chamar melhoria de fidelidade de melhoria garantida da previsão ou do lucro.

As avaliações de previsão e de operação são camadas diferentes. MSE/MAE usam alvo observado na avaliação estatística. Uma política de operação recebe somente a previsão e informações disponíveis na origem. Os módulos operacionais não importam modelos nem iniciam treinamento.

```text
publicações de previsões já encerradas
                 ↓ leitura e checksum
simulacao_operacoes/previsoes.py  → contrato sem alvo/preço futuro
                 ↓
simulacao_operacoes/politicas.py  → direção decidida causalmente
                 ↓
simulacao_operacoes/futuros/     ← mercado_futuros/ (negócios, mark, funding)
  contabilidade + simulador + auditoria separada
                 ↓
experimentos/futuros/            → grade, identidade, lock e publicação
                 ↓
dados/experimentos/futuros_<id>/  + registros/futuros/
```

| Responsabilidade | Local | Contrato |
|---|---|---|
| Coleta pública de perpétuos | `mercado_futuros/pipeline.py` | Arquivos/checksums/API; não calcula sinais ou lucro |
| Contexto anterior à primeira origem | `mercado_futuros/contexto.py` | Complemento identificado; não altera pai publicado |
| Previsões para operação | `simulacao_operacoes/previsoes.py` | UTC, horizonte24h, origens únicas, sem coluna de alvo |
| Política | `simulacao_operacoes/politicas.py` | Previsão/configuração → −1/0/+1; sem acesso ao mercado futuro observado |
| Contabilidade | `simulacao_operacoes/futuros/contabilidade.py` | Quantidade assinada, PnL, funding, custos |
| Mercado carregado | `simulacao_operacoes/futuros/mercado.py` | Cobertura contínua e arrays de observações; não contém previsões |
| Simulação | `simulacao_operacoes/futuros/simulador.py` | Operações, curva, funding e resumo; buffer de margem bloqueante |
| Conferência | `simulacao_operacoes/futuros/auditoria.py` | Recalcula saldo e ledger sem chamar simulador |
| Rodada identificada | `experimentos/futuros/` | Grade fixa, preservação, snapshot, autorização e execução exclusiva |
| Qualificação | `tests_simulacao_operacoes/` | Cenários sintéticos causais, não otimização em mercado |

Os executores Spot históricos (`backtest_carteira/`, módulos de ciclos e avaliações congeladas) permanecem intactos. Não movê-los para criar aparência de unificação: seus hashes e caminhos fazem parte da evidência. Novas políticas/mercados poderão usar contratos semelhantes, mas exigem novo protocolo e identidade; resultados de uma identidade nunca são sobrescritos.

Método: [protocolo F01](protocolo_futuros.md). Estado real: [registros](../registros/futuros/estado.json). Dados públicos têm [estado próprio](../registros/mercado_futuros/estado.json). Textos/recibos podem ser versionados; ZIPs, curvas e checkpoints continuam sujeitos à [política de armazenamento](armazenamento_e_reproducao.md).


Análise posterior: `python -B -m analises.futuros` verifica fechamento e ledgers publicados, grava recibo novo em `registros/futuros/conferencias/` e recompõe o relatório editorial. Não chama treinamento ou execução. A conferência já entregue fica preservada; não repetir para obter outro resultado. Interpretações editoriais adicionais devem permanecer no relatório canônico, sem alterar publicações congeladas.


## Smart retida compartilhada — F02

`simulacao_operacoes/smart/` acrescenta política de ajuste líquido, conta Spot/colateral de futuros, leitor dos dois mercados, simulador retido e auditor por caixa equivalente. O teste de preços idênticos/funding zero exige equivalência entre contas. `experimentos/smart_mercados/` congela e executa a grade autorizada; `tests_smart_mercados/` qualifica. [Protocolo](protocolo_smart_mercados.md), [estado](../registros/smart_mercados/estado.json). Fontes deF01 permanecem inalteradas. Nova política/gestão comum não substitui a Smart histórica e não exige novos checkpoints.
