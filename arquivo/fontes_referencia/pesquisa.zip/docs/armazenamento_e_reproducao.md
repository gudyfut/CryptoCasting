# Preservação, organização e reprodução

O catálogo em `registros/catalogo_estudos.json` identifica os ciclos, suas heranças e as evidências. Um índice ou manifesto não substitui os arquivos descritos. Organização local e presença no Git não comprovam backup externo.

## Separação dos materiais

| Material | Local |
|---|---|
| Núcleo reutilizável | Módulos de mercado, entradas, modelos, treinamento, avaliação, simulação e infraestrutura |
| Receitas e decisões | `configuracoes/`, `docs/adr/` e protocolos identificados |
| Modelos, previsões e resultados | `dados/experimentos/<identidade>/`, com os layouts originais de cada ciclo |
| Recibos, controles, logs e incidentes | `registros/` e as próprias execuções |
| Leitores posteriores úteis | `analises/`, agrupados em `analises/etapas/` |
| Executores e ferramentas encerrados, testes específicos antigos e versões editoriais anteriores | `arquivo/desenvolvimento_encerrado/fontes.zip`, com índice de caminhos e hashes |
| Redação futura | `escrita_tcc/`, com a área de narrativa ainda reservada |

Os snapshots em `dados/**/fontes/` fazem parte da evidência científica. Checkpoints, dados, controles e tentativas malsucedidas não são caches. As fontes e a preservação exigidas pela rodada ativa permanecem nos caminhos reais; o fechamento pode consultá-las novamente.

## Fontes históricas e verificação

A reorganização física não altera identidades científicas. O índice em `arquivo/desenvolvimento_encerrado/indice.json` conserva o caminho e SHA-256 de cada original retirado da área de trabalho. O ZIP contém os bytes originais, incluindo finais de linha. Os guias anteriores editados nesta organização estão em `editoriais_antes/` dentro do pacote.

Usar `python -m manutencao.auditar_repositorio --integridade --exigir-completo` para conferir o catálogo organizado. Ele reutiliza os critérios do auditor original e acrescenta a localização explícita das fontes históricas. Um arquivo local divergente continua sendo divergência; o pacote não encobre alterações. O recibo distingue arquivos locais e originais localizados no arquivo histórico.

Usar `python -m manutencao.arquivo_fontes conferir` para conferir o pacote, seus membros e os leitores realocados. Para recuperar fontes, `python -m manutencao.arquivo_fontes extrair --destino <pasta_nova>`. O destino precisa ser novo; não há sobrescrita nem execução automática. Para reproduzir um executor encerrado, preparar uma área isolada com os caminhos originais, as fontes congeladas, o ambiente e os dados daquele ciclo, conforme seu protocolo. Não usar a extração como autorização para retreinar.

## Transporte e backup

1. Identificar a execução e distinguir materiais estáveis de arquivos ainda sendo escritos. Conferir processo, locks e logs antes de qualquer retomada.
2. Verificar os manifestos e congelamentos existentes. Não regenerar hashes para aceitar divergências.
3. Preparar pacotes por ciclo com fontes, ambiente, configurações, dados preparados, escalas, todos os modelos/seeds, previsões, logs, controles, incidentes e publicações necessários à reprodução.
4. Registrar commit de distribuição, identidade científica, caminhos, tamanhos, SHA-256 e escopo parcial ou completo. O código versionado e os pacotes de artefatos são materiais complementares.
5. Transferir para armazenamento externo e registrar URLs reais quando existirem. Um commit local, `git push` de código ou arquivo ignorado pelo Git não demonstra preservação dos binários.
6. Baixar ou restaurar em área separada e comparar os hashes antes de declarar o backup externo conferido. Um `git pull` não baixa automaticamente anexos de Releases.

A política de distribuição por ciclo foi definida na [ADR0003](adr/0003-preservacao-e-organizacao.md). Nenhuma publicação externa é presumida nesta organização. As observações antigas de disponibilidade entre desktop e notebook estão preservadas na versão anterior deste guia, dentro do pacote histórico; não representam o estado atual.

## Finais de linha e ambiente

Os hashes científicos conferem bytes. LF e CRLF podem representar texto visível equivalente e ainda assim produzir hashes diferentes. Preservar `.gitattributes`, fontes congeladas, configurações, protocolos e recibos. Não fazer renormalização em massa nem checkout que substitua fontes durante uma execução ativa.

Restaurar dados e checkpoints não qualifica automaticamente CUDA, bibliotecas ou hardware. Qualificação, reprodução numérica e recuperação de artefatos são verificações distintas. As auditorias locais não recalculam todas as métricas nem certificam toda fonte bruta ou execução real de mercado; seus recibos delimitam o escopo.
