'use client';
import { createContext, useContext, useState, type ReactNode } from 'react';
import { compararFichas, prioridadesDiferencas, resumoFicha, valorResumido } from '@/lib/fichas';
import type { CatalogoFichas } from '@/lib/panorama-tipos';

type ModoComparacao = 'anterior' | 'referencia';
const ContextoFicha = createContext<{
  comparacao: ModoComparacao; setComparacao: (modo: ModoComparacao) => void;
  soMudancas: boolean; setSoMudancas: (ativo: boolean) => void;
} | null>(null);

export function PreferenciasFicha({ children }: { children: ReactNode }) {
  const [comparacao, setComparacao] = useState<ModoComparacao>('anterior');
  const [soMudancas, setSoMudancas] = useState(false);
  return <ContextoFicha.Provider value={{ comparacao, setComparacao, soMudancas, setSoMudancas }}>{children}</ContextoFicha.Provider>;
}

export default function FichaTecnica({ pagina, catalogo }: { pagina: string; catalogo: CatalogoFichas }) {
  const opcoes = (catalogo.paginas[pagina] ?? []).map(id => catalogo.fichas[id]).filter(Boolean);
  const [escolhida, setEscolhida] = useState(catalogo.padroes[pagina]);
  const [consultaAberta, setConsultaAberta] = useState(false);
  const preferencias = useContext(ContextoFicha);
  if (!preferencias) throw new Error('Ficha fora do contexto de preferências');
  const { comparacao, setComparacao, soMudancas, setSoMudancas } = preferencias;
  const ficha = catalogo.fichas[escolhida] ?? opcoes[0];
  if (!ficha) return <section className="ficha-tecnica"><h2>Configuração da fase</h2><p className="aviso">Configuração indisponível nesta máquina.</p></section>;

  const anteriorId = comparacao === 'anterior' ? catalogo.anteriores[pagina] : ficha.referencia;
  const base = anteriorId ? catalogo.fichas[anteriorId] : null;
  const referencia = ficha.referencia ? catalogo.fichas[ficha.referencia] : null;
  const podeComparar = Boolean(base?.integridade === 'conferida');
  const grupos = compararFichas(ficha, podeComparar ? base : null);
  const diferencas = grupos.flatMap(g => g.campos).filter(c => c.alteracao !== 'mantido');
  const chavesAlteradas = new Set(podeComparar ? diferencas.map(c => c.id) : []);
  const principais = prioridadesDiferencas.flatMap(id => {
    const campo = diferencas.find(c => c.id === id);
    if (!campo) return [];
    const antes = campo.antes === undefined ? 'Não havia' : valorResumido(id, campo.antes);
    const depois = campo.valor === undefined ? 'Retirado' : valorResumido(id, campo.valor);
    return antes === depois ? [] : [{ ...campo, antesCurto: antes, depoisCurto: depois }];
  }).slice(0, 3);
  const gruposOpcoes = [...new Set(opcoes.map(f => f.grupo))];

  function consultarAlteracoes() { setSoMudancas(true); setConsultaAberta(true); }

  return <section className="ficha-tecnica" aria-labelledby={`titulo-ficha-${pagina}`}>
    <header className="cabecalho-ficha">
      <h2 id={`titulo-ficha-${pagina}`}>Configuração da fase</h2>
      <span>Amarelo indica mudança</span>
    </header>
    {opcoes.length > 1 && <label className="receita-ficha">Receita ou etapa
      <select value={ficha.id} onChange={e => setEscolhida(e.target.value)}>
        {gruposOpcoes.map(g => <optgroup key={g} label={g}>{opcoes.filter(f => f.grupo === g).map(f => <option key={f.id} value={f.id}>{f.nome}</option>)}</optgroup>)}
      </select>
    </label>}
    {ficha.integridade !== 'conferida' ? <p className="aviso" role="status">{ficha.integridade === 'ausente' ? 'Uma fonte está ausente.' : 'Uma fonte precisa ser reconferida.'} Os parâmetros não são presumidos.</p> : <>
      <dl className="receita-resumo" aria-label="Resumo da configuração">
        {resumoFicha(ficha).map(linha => {
          const mudou = [...linha.itens, linha.apoio].some(i => chavesAlteradas.has(i.id));
          return <div key={linha.id}>
            <dt>{linha.nome}{mudou && <span className="marcador-mudanca" aria-label="Contém alteração" />}</dt>
            <dd><div>{linha.itens.map(i => <span key={i.id} className={chavesAlteradas.has(i.id) ? 'valor-mudou' : undefined}>{i.texto}</span>)}</div><p className={chavesAlteradas.has(linha.apoio.id) ? 'apoio-mudou' : undefined}>{linha.apoio.texto}</p></dd>
          </div>;
        })}
      </dl>
      <section className="mudancas-resumo" aria-labelledby={`mudancas-${pagina}`}>
        <div className="cabecalho-mudancas"><h3 id={`mudancas-${pagina}`}>O que mudou</h3>
          <div className="escolha-comparacao" role="group" aria-label="Base da comparação">
            <button aria-pressed={comparacao === 'anterior'} onClick={() => setComparacao('anterior')}>Fase anterior</button>
            <button aria-pressed={comparacao === 'referencia'} onClick={() => setComparacao('referencia')}>Referência do teste</button>
          </div>
        </div>
        <p className="base-comparacao">{base ? <>Em relação a <strong>{base.nome}</strong>.</> : anteriorId ? 'Comparação anterior indisponível.' : 'Ponto de partida: ainda não há configuração anterior.'}</p>
        {referencia && referencia.id !== base?.id && <p className="referencia-real">Receita baseada em <strong>{referencia.nome}</strong>. <button onClick={() => setComparacao('referencia')}>Comparar com ela →</button></p>}
        {podeComparar ? <>
          {principais.length ? <ul className="lista-mudancas">{principais.map(c => <li key={c.id}><span>{c.nome}</span><div><span className="valor-anterior">{c.antesCurto}</span><span className="seta-mudanca" aria-label="passou a">→</span><strong>{c.depoisCurto}</strong></div></li>)}</ul> : <p className="sem-mudancas">{diferencas.length ? 'As diferenças estão nos detalhes do procedimento.' : 'Mesma configuração nos parâmetros comparados.'}</p>}
          {diferencas.length > principais.length && <button className="link-discreto ver-diferencas" onClick={consultarAlteracoes}>Ver todas as {diferencas.length} diferenças →</button>}
        </> : base ? <p className="nota">A fonte anterior não está conferida; os destaques de diferença ficam desativados.</p> : null}
      </section>
    </>}
    <details className="consulta-ficha" open={consultaAberta} onToggle={e => setConsultaAberta(e.currentTarget.open)}>
      <summary>Consultar configuração completa <span>Parâmetros e fontes</span></summary>
      <div className="consulta-introducao"><strong>{ficha.nome}</strong>{ficha.nota && <p>{ficha.nota}</p>}
        <label className="alternar-mudancas"><input type="checkbox" checked={soMudancas} onChange={e => setSoMudancas(e.target.checked)} />Mostrar somente alterações</label>
      </div>
      {ficha.integridade === 'conferida' && <div className="grupos-ficha">{grupos.map(grupo => {
        const campos = grupo.campos.filter(c => !soMudancas || c.alteracao !== 'mantido');
        if (!campos.length) return null;
        const alteracoes = podeComparar ? grupo.campos.filter(c => c.alteracao !== 'mantido').length : 0;
        return <details className="grupo-ficha" key={grupo.id}>
          <summary><h3>{grupo.nome}</h3><small>{campos.length} {campos.length === 1 ? 'item' : 'itens'}{alteracoes ? ` · ${alteracoes} ${alteracoes === 1 ? 'mudança' : 'mudanças'}` : ''}</small></summary>
          <dl>{campos.map(c => <div className={`campo-ficha ${podeComparar && c.alteracao !== 'mantido' ? 'campo-alterado' : ''}`} key={c.id}>
            <dt>{c.nome}</dt><dd>{c.valor ?? 'Não faz parte desta configuração.'}{podeComparar && c.antes !== undefined && c.alteracao !== 'mantido' && <small>Antes: {c.antes}</small>}</dd>
          </div>)}</dl>
        </details>;
      })}</div>}
      {soMudancas && podeComparar && !diferencas.length && <p className="nota">Nenhuma alteração nesta comparação.</p>}
      <details className="fontes-ficha"><summary>Arquivos originais</summary><p>Fontes conferidas por SHA-256. Épocas selecionadas, pesos e resultados permanecem nos artefatos de cada ajuste.</p><ul>{ficha.fontes.map(f => <li key={f}><a target="_blank" rel="noreferrer" href={`/api/panorama/fonte?caminho=${encodeURIComponent(f)}`}>{f}</a></li>)}</ul></details>
    </details>
  </section>;
}
