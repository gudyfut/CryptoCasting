# CryptoCasting — investigação de previsão com Mamba e OHLCV

TCC sobre decisões controladas de entrada e configuração do Mamba, com LSTM, Naive e ARIMA como referências. O objetivo é compreender precisão, estabilidade e utilidade operacional; resultados negativos também são válidos.

## Trabalho atual

A referência de continuidade é **Mamba16/AdamW**, BTCUSDT, candles de1h, contexto de168h e previsão do log-retorno em24h, com cinco canais OHLCV transformados causalmente. Os estudos anteriores estão encerrados e preservados.

A rodada **MSE versus2×Huber(delta1 no alvo padronizado)** foi concluída e conferida nas seis seeds, mantendo AdamW/taxa constante0,0002. [Método](docs/protocolo_perda_huber.md), [estado/publicação](registros/perda_huber/estado.json), [comparação completa e revisão independente](docs/resultados_perda_huber.md). A melhora média foi pequena e não satisfez o critério de incerteza; a referência MSE foi mantida. Nenhuma nova rodada é iniciada por esse fechamento. A taxa dinâmica e os demais estudos permanecem preservados.

Antes da rodada, foi feito um [diagnóstico das previsões existentes](docs/diagnostico_previsoes.md), incluindo erros extremos, frequência de vitória frente ao Naive, correlações, faixas de previsão e trimestres. Não altera resultados anteriores nem seleciona uma seed favorável.

## Como navegar

- [Índice documental](docs/README.md): método, arquitetura e estudos encerrados.
- [Desenho OHLCV](docs/desenho_ohlcv24.md): decisões de dados/alvo/treinamento.
- [Plano](plano.md): próximos estágios; [andamento](docs/andamento.md): cronologia factual única.
- [Catálogo](registros/catalogo_estudos.json): identidades, tentativas, resultados e relação entre ciclos.
- [Roteiro do TCC](docs/roteiro_redacao_tcc.md) e [PDF acadêmico original](docs/TCC_1_MuriloRFM.pdf).

## Estrutura

| Camada | Responsabilidade |
|---|---|
| `mercado_binance/` | Coleta, proveniência, validação e candles completos |
| `entradas_modelo/` | Canais, alvos, janelas, divisões, purga e escalas de treino |
| `modelos/` | Contratos e consumo por Mamba, LSTM, Naive e ARIMA |
| `treinamento/` e `avaliacao/` | Referência modular congelada: ajuste, seleção, checkpoints e avaliação |
| `analises/` | Diagnósticos reutilizáveis de previsões preservadas |
| `experimentos/` | Novas hipóteses com código e orçamento próprios; Huber: `python -m experimentos.perda_huber`, preservando lançadores congelados |
| `configuracoes/`, `registros/`, `dados/experimentos/` | Receitas, evidências e artefatos por tentativa |
| `arquivo/` | Estudos preliminares preservados; não são evidência de rede OHLCV |

Os pacotes históricos `experimento_*/` e seus lançadores permanecem onde foram executados, pois seus caminhos/fontes integram os recibos. Não são lixo ou autorização para reexecutar. Novas rodadas usam o namespace comum para evitar proliferação na raiz. A referência preparada `estudo_ohlcv/` é histórica; o treino modular efetivo possui outra identidade.

## Resultados encerrados

| Estudo | Consulta |
|---|---|
| Estados8/16/32/64, seis seeds | [Comparação](docs/resultados_estados32_64.md) |
| Taxa constante0,0002→0,0001 | [Comparação](docs/resultados_taxa_aprendizado.md) |
| Taxa dinâmica Mamba16 | [Comparação e conferência posterior](docs/resultados_taxa_dinamica.md) |
| Perda Huber Mamba16, seis seeds | [Comparação e conferência posterior](docs/resultados_perda_huber.md) |
| Carteiras retidas e controles,369simulações | [Backtest](docs/resultados_backtest_carteira.md) |
| CryptoMamba adaptado e Adam→AdamW | [Adaptação](docs/resultados_cryptomamba_adaptado.md), [otimizador](docs/resultados_otimizador_cryptomamba.md); linha encerrada |
| Retornos escalares, penalização, normalização e barreiras | [Arquivo preliminar](arquivo/estudos_preliminares_2026-10-28/README.md) |

2024/2025 já foram consultados: os novos contrastes são retrospectivos, sem alegação de holdout intocado ou walk-forward. Futuras hipóteses exigem delimitação e qualificação próprias; não há busca automática até lucrar.

## Execução e preservação

Consultar [regras de registro](docs/registro_de_experimentos.md) e [preservação entre máquinas](docs/armazenamento_e_reproducao.md). Fontes/configurações/publicações congeladas são imutáveis. Preparar, autorizar, treinar e auditar são fases distintas. Não duplicar processo vivo nem repetir executor encerrado para gerar relatório.

O portal em `dataview/` mostra o estudo preliminar; não representa os novos resultados OHLCV. Dados grandes e checkpoints permanecem fora do Git comum; hashes e disponibilidade local não certificam backup externo.
