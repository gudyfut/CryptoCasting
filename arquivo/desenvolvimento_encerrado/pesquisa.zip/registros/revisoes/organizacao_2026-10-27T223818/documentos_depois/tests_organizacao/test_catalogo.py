import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from manutencao.auditar_catalogo import Auditor, auditar, comparar_cobertura, validar_relacoes


class TesteRastreabilidade(unittest.TestCase):
    def test_duplicidade_nao_compensa_celula_faltante(self):
        a, b = ('BTC', 'B1', 24, 17, 'mamba'), ('ETH', 'B1', 24, 17, 'mamba')
        resultado = comparar_cobertura({a, b}, [a, a])
        self.assertEqual(resultado['faltantes'], [b])
        self.assertEqual(resultado['duplicadas'], [a])

    def test_heranca_errada_e_ciclo_sao_rejeitados(self):
        with self.assertRaises(ValueError):
            validar_relacoes({'estudos': [
                {'chave': 'a', 'execucao': '1', 'antecessor': 'b'},
                {'chave': 'b', 'execucao': '2', 'antecessor': 'a'}]})
        with self.assertRaises(ValueError):
            validar_relacoes({'estudos': [{'chave': 'a', 'execucao': '1'},
                {'chave': 'b', 'execucao': '2', 'antecessor': 'a', 'heranca': {'execucao': '3'}}]})

    def test_ids_duplicados_rejeitados(self):
        with self.assertRaises(ValueError):
            validar_relacoes({'estudos': [{'chave': 'a', 'execucao': '1'},
                                         {'chave': 'b', 'execucao': '1'}]})

    def test_caminhos_fora_do_projeto_rejeitados(self):
        with tempfile.TemporaryDirectory() as pasta:
            auditor = Auditor(pasta)
            for caminho in ('../fora.json', 'C:/fora.json', '/tmp/fora.json'):
                with self.assertRaises(ValueError):
                    auditor.caminho(caminho)

    def test_ausencia_nao_e_zero_treinamentos(self):
        with tempfile.TemporaryDirectory() as pasta:
            auditor = Auditor(pasta)
            resultado = auditor.tentativas('ausente', {('BTC', 'B1', 24, 17, 'mamba')})
            self.assertIsNone(resultado['auditadas'])
            self.assertTrue(auditor.ausentes)
            self.assertFalse(auditor.erros)

    def test_conversao_crlf_e_corrupcao_falham_no_hash(self):
        with tempfile.TemporaryDirectory() as pasta:
            esperado = hashlib.sha256(b'original\n').hexdigest()
            for conteudo in (b'original\r\n', b'alterado\n'):
                Path(pasta, 'fonte.py').write_bytes(conteudo)
                auditor = Auditor(pasta)
                auditor.conferir('fonte.py', esperado)
                self.assertEqual(len(auditor.erros), 1)

    def test_catalogo_parcial_nao_e_aprovado_integral(self):
        with tempfile.TemporaryDirectory() as pasta:
            Path(pasta, 'catalogo.json').write_text(json.dumps({
                'cronologia': 'ausente.md', 'procedimento': 'ausente.md',
                'estudos': [{'chave': 'a', 'execucao': '1', 'tipo': 'referencia',
                            'situacao_historica': 'concluido_auditado',
                            'fontes': {'execucao': 'ausente.json'}}]}))
            _, resultado = auditar(pasta, 'catalogo.json')
            self.assertEqual(resultado['status'], 'parcial')
            self.assertIsNone(resultado['estudos'][0]['auditadas'])


if __name__ == '__main__':
    unittest.main()
