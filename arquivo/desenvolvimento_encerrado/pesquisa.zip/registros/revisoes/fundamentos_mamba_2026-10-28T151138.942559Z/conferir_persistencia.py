"""Baseline posterior em dados públicos; não reproduz checkpoints/artigo."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

pasta = Path(__file__).resolve().parent
dados = pd.read_csv(pasta / 'fontes/data/2018-09-17_2024-09-16_86400/test.csv')
assert dados['Timestamp'].is_unique
assert (np.diff(dados['Timestamp']) == 86400).all()
precos = dados['Close'].to_numpy(dtype=np.float64)
assert np.isfinite(precos).all() and (precos > 0).all()
resultados = []
for nome, indices in [('indices_codigo_publicado', np.arange(14, len(dados)-1)),
                      ('todos_pares_diarios', np.arange(1, len(dados)))]:
    for precisao in [np.float32, np.float64]:
        alvo = precos[indices].astype(precisao).astype(np.float64)
        previsao = precos[indices-1].astype(precisao).astype(np.float64)
        erros = previsao-alvo
        resultados.append({'populacao':nome,'precisao':precisao.__name__,'n':len(indices),
                           'mse':float(np.mean(erros**2)),
                           'rmse':float(np.sqrt(np.mean(erros**2))),
                           'mae':float(np.mean(abs(erros))),
                           'mape_percentual':float(np.mean(abs(erros)/alvo)*100),
                           'primeiro_timestamp_alvo':int(dados.iloc[indices[0]]['Timestamp']),
                           'ultimo_timestamp_alvo':int(dados.iloc[indices[-1]]['Timestamp'])})
        if nome == 'indices_codigo_publicado' and precisao == np.float32:
            pd.DataFrame({'timestamp_alvo':dados['Timestamp'].iloc[indices].to_numpy(),
                          'preco_real':alvo,'previsao_persistencia':previsao,
                          'erro_quadrado':erros**2}).to_csv(pasta/'persistencia_por_origem.csv',index=False)
resumo = {'natureza':'Conferencia independente posterior; apenas Naive, sem inferencia neural.',
          'linhas_test_csv':len(dados),'resultados':resultados,
          'reducoes_rmse_tabela_artigo_percentual':{
              'cmamba_vs_lstm_sem_volume':100*(1-1713.0/2672.7),
              'cmamba_vs_lstm_com_volume':100*(1-1598.1/2202.1),
              'cmamba_com_vs_sem_volume':100*(1-1598.1/1713.0)},
          'limites':['Populacao reconstruida do codigo/dados publicados, nao de predicoes dos autores.',
                     'Metricas neurais citadas sao da tabela do artigo, nao recalculadas.',
                     'Nao demonstra reproducao nem significancia estatistica do contraste.',
                     'Timestamps preservados; diferenca constante de fuso nao foi corrigida.']}
(pasta/'persistencia.json').write_text(json.dumps(resumo,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(resumo,ensure_ascii=False,indent=2))
