# Plano de trabalho

Atualizado em 28/10/2026. O [TCC1](docs/TCC_1_MuriloRFM.pdf) orienta a investigação iterativa do Mamba com OHLCV e avaliação temporal. O método concreto está apenas no [desenho OHLCV](docs/desenho_ohlcv24.md), para evitar versões concorrentes.

## Etapas

1. **Preservar e separar a fase preliminar:** ciclos de retornos e extensões concluídos, indexados no [arquivo](arquivo/estudos_preliminares_2026-10-28/README.md); fontes, artefatos e recibos intactos. Relatórios/diagnósticos editoriais arquivados, com navegação atualizada.
2. **Definir R0 e preparar o fluxo:** BTC/1h/168h→24h, cinco canais, uma divisão temporal, seis ajustes principais e dois controles; implementação separada, testes sintéticos e conferência independente dos dados. Situação factual e recibos na [cronologia](docs/andamento.md).
3. **Revisar módulos antes de treinar:** prioridade posterior solicitada pelo pesquisador. Dados Binance e entradas separados conforme a [arquitetura](docs/arquitetura_dados.md) e ADR 0007; seguir pela superfície dos modelos, treinamento e avaliação. Preservar R0 preparada; integração nova precisa de identidade e qualificação próprias. Não iniciar treinamento durante essa revisão.
4. **Executar a referência após a revisão:** Mamba/LSTM nas três seeds, Naive e ARIMA. Sem ablações simultâneas. Conferir controles, checkpoints, origens, métricas e custos antes de interpretar. Ainda sem treino de mercado desta referência.
5. **Evoluir uma variável por ciclo:** hipótese, antecedente, única diferença, orçamento e critérios antes dos ajustes; examinar desempenho e estabilidade na validação. Publicar fracassos; não escolher a seed vencedora. Nenhuma busca automática autorizada.
6. **Avaliação temporal ampliada:** R0 e no máximo uma candidata; walk-forward com reestimação em cada bloco. Os períodos conhecidos permanecem retrospectivos, mesmo após nova divisão; confirmação independente requer dados/condições apropriados.
7. **Redação e análise acadêmica:** escrever método, evolução, resultados e limites a partir das evidências. Alinhar delimitação BTC/24h com o orientador; não presumir aceite. Não exigir vitória do Mamba ou lucro para concluir o TCC.

A implementação/qualificação não é resultado de mercado. Os estados atuais são verificáveis em `registros/ohlcv/`; a preparação não inicia o executor de treinamento. O portal existente ainda mostra o estudo preliminar.

## Relação com o histórico

O plano anterior de 20/10 estudou quatro moedas/contextos com entrada de retornos do fechamento. A referência foi concluída em21/10; a extensão da penalização em27/10; a pré-normalização em28/10. Cada uma tem protocolo e identidade preservados. A cronologia detalhada, contagens, resultados e incidentes ficam em [andamento](docs/andamento.md) e no arquivo preliminar, sem repeti-los neste plano.

A passagem a R0 altera mais de um fator e não mede isoladamente o efeito de OHLCV. As comparações controladas começam a partir da nova referência. A [ADR0006](docs/adr/0006-reorganizacao-e-desenho-ohlcv.md) explica a transição; o [procedimento de registro](docs/registro_de_experimentos.md) rege os próximos ciclos.
