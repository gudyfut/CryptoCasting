"""Somente leitura de implementação instalada; não instancia nem ajusta modelo."""
from pathlib import Path
import sys
import inspect
import importlib
import importlib.metadata
import platform
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
import torch
from mamba_ssm import Mamba
from infraestrutura.artefatos import RAIZ, salvar_json, ler_json, sha256, agora

referencia = ler_json(RAIZ / 'registros/ohlcv/qualificacoes/2026-10-28T213745.525127_0000/qualificacao.json')['ambiente']
arquivos = {'mamba': Path(inspect.getfile(Mamba))}
for nome in ('mamba_ssm.ops.selective_scan_interface', 'selective_scan_cuda', 'causal_conv1d_cuda'):
    arquivos[nome] = Path(importlib.import_module(nome).__file__)
conferencia = {k: {'arquivo': str(p), 'sha256': sha256(p),
                   'igual_referencia': sha256(p) == referencia['implementacao_instalada'][k]['sha256']}
               for k, p in arquivos.items()}
assert all(v['igual_referencia'] for v in conferencia.values())
salvar_json(Path(__file__).with_name('ambiente.json'), {
    'utc': agora(), 'sistema': platform.platform(), 'python': platform.python_version(),
    'cuda': torch.version.cuda, 'gpu': torch.cuda.get_device_name(),
    'pacotes': {k: importlib.metadata.version(k) for k in ('torch', 'mamba_ssm', 'causal_conv1d', 'numpy', 'pandas', 'statsmodels')},
    'implementacoes': conferencia, 'treinamento': False})
print('Implementações instaladas conferem com a referência qualificada.')
