import unittest
import numpy as np
from manutencao.diagnosticar_frequencia import intervalo, resumir
from manutencao.consolidar_resultados import intervalo_blocos


class FrequenciaTeste(unittest.TestCase):
    def test_blocos_com_dias_ausentes_equivalem_somas_contagens(self):
        valores=[np.linspace(-.02,.04,35),np.linspace(.01,.03,21)]
        valores[0][5:8]=np.nan
        referencia=[(np.nan_to_num(v),np.isfinite(v).astype(int)) for v in valores]
        for tamanho in (7,14,28):
            observado=intervalo(valores,tamanho,200,17)
            esperado=intervalo_blocos(referencia,tamanho,200,17)
            np.testing.assert_allclose([observado['inferior'],observado['superior']],
                                       [esperado['inferior'],esperado['superior']],rtol=0,atol=1e-15)

    def test_constante_preserva_intervalo_e_peso_igual_entre_folds(self):
        observado=intervalo([np.full(90,.01),np.full(180,.03)],14,200,42)
        self.assertAlmostEqual(observado['inferior'],.02)
        self.assertAlmostEqual(observado['superior'],.02)

    def test_decomposicao_do_erro_nao_confunde_amplitude_com_acerto(self):
        y=np.array([-.02,.01,.03,-.01])
        p=np.array([.01,-.01,.005,.02])
        r=resumir(y,p)
        self.assertAlmostEqual(r['mse']-r['mse_naive'],r['energia_previsao']-r['alinhamento_duplo'])
        self.assertGreater(r['mse'],r['mse_naive'])
        self.assertEqual(resumir(y,np.zeros_like(y))['mse'],r['mse_naive'])


if __name__=='__main__':
    unittest.main()
