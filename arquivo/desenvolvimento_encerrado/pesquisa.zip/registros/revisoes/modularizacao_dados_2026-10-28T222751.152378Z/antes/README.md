# CryptoCasting — TCC sobre previsão com Mamba e OHLCV

Investigação controlada de decisões de entrada e configuração do Mamba, com LSTM, Naive e ARIMA como referências. O objetivo é compreender o desempenho preditivo e sua relação com uma política operacional fixa. Uma conclusão negativa é válida.

**Etapa atual: referência OHLCV implementada, qualificada e congelada; nenhum treinamento de mercado iniciado nesta etapa.** A situação verificável fica nos ponteiros de `registros/ohlcv/` e na [cronologia](docs/andamento.md). A definição acadêmica original está no [TCC1](docs/TCC_1_MuriloRFM.pdf); a delimitação atual não implica aceite do orientador.

## Comece aqui

- [Índice documental](docs/README.md): documentos atuais e histórico.
- [Desenho OHLCV](docs/desenho_ohlcv24.md): decisões, fórmulas, modelos, datas, avaliação e próximos ciclos.
- [Plano de trabalho](plano.md) e [andamento](docs/andamento.md).
- [Estudos preliminares preservados](arquivo/estudos_preliminares_2026-10-28/README.md): resultados anteriores, que usaram somente retornos do fechamento.
- [Catálogo de estudos](registros/catalogo_estudos.json), [mapa de registros](registros/README.md) e [roteiro de redação](docs/roteiro_redacao_tcc.md).

## Referência inicial

| Item | Definição |
|---|---|
| Mercado e dados | BTCUSDT, Binance Spot, OHLCV de candles completos de 1h |
| Contexto e horizonte | Últimas 168h → retorno terminal das próximas 24h |
| Entradas | ln(O/C anterior), ln(H/C anterior), ln(L/C anterior), ln(C/C anterior), ln(1+volume BTC); padronização só no treino |
| Divisão exploratória | Treino 2021–2023, validação 2024, teste retrospectivo 2025; purga24h |
| Redes | Mamba-1 oficial CUDA e LSTM; seeds17/42/2026 |
| Referências | Naive zero; ARIMA(p,1,q), p/q0..2, sem deriva, selecionado na validação |
| Orçamento inicial | 6 ajustes neurais principais + 2 controles de reprodução; nenhuma ablação nesta rodada |
| Avaliação | MSE primário, RMSE/MAE/direção secundários; simulação diária Spot com custos, separada |

OHLCV não garante melhora. Esta divisão fixa é exploração, não walk-forward. Períodos já consultados continuam retrospectivos. A avaliação ampliada por reestimações temporais será outra etapa, após delimitar a candidata.

## Código e execução

`estudo_ohlcv/` contém preparação multivariada, redes, treino, controle de execução e publicação. `configuracoes/ohlcv24_001.json` define a referência. O comando é executado **na raiz**, no Linux/WSL com ambiente CUDA qualificado:

```text
python run_ohlcv.py preparar
python run_ohlcv.py qualificar
python run_ohlcv.py congelar
```

Esses comandos preparam dados, executam verificações sintéticas e congelam uma identidade; não treinam modelos com dados de mercado. A etapa real é `python run_ohlcv.py executar`, somente quando iniciada explicitamente dentro do escopo definido. Para retomada, conferir processo/lock/logs/fontes primeiro e usar `--retomar`; nunca duplicar processo vivo. O executor recusa reexecutar ciclo concluído. Cada tentativa fica preservada.

Conferência independente da preparação, sem treino: `python manutencao/conferir_preparacao_ohlcv.py`. Verificação dos estudos preliminares: `python manutencao/auditar_catalogo.py --integridade --exigir-completo` no computador que contém todos os artefatos. O auditor histórico não substitui a conferência OHLCV.

Dependências gerais em `requirements.txt`. Qualificação registra versões, hardware, implementação instalada, testes, recarga e reprodução. Não há fallback silencioso do Mamba. A integração do novo ciclo no portal será feita quando houver resultados reais.

## Organização e preservação

| Local | Função |
|---|---|
| `docs/` | Desenho atual, cronologia, redação e regras de registro; três protocolos históricos mantidos por integridade |
| `docs/adr/` | Decisões materiais e suas razões |
| `registros/` | Catálogo, ponteiros, auditorias, incidentes e recibos |
| `dados/experimentos/` | Execuções separadas; fontes congeladas, tentativas, checkpoints, previsões e publicações |
| `arquivo/estudos_preliminares_2026-10-28/` | Índice, documentação e snapshots da fase anterior |
| `previsao24/`, `experimento_penalizacao/`, `experimento_normalizacao/` | Fontes preservadas dos três ciclos encerrados; não editar sob suas identidades |
| `dataview/` | Portal Next.js do estudo preliminar; executar npm dentro desta pasta |

Não criar documentos para cada pergunta. Refinar o desenho existente, registrar fatos na cronologia e guardar evidências técnicas no ciclo correspondente. Não eliminar falhas ou resultados desfavoráveis. Os binários grandes são preservados localmente/pacotes, conforme a [política de armazenamento](docs/armazenamento_e_reproducao.md); arquivos locais não equivalem a backup remoto verificado.

Licença: [MIT](LICENSE).
