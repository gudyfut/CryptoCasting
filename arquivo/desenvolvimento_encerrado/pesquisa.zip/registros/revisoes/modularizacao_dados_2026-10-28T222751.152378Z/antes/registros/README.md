# Mapa dos registros científicos

Em28/10, os ciclos anteriores foram agrupados no [arquivo preliminar](../arquivo/estudos_preliminares_2026-10-28/README.md), com relatórios em `documentacao/` e artefatos científicos nos caminhos originais. A referência atual está no [desenho OHLCV](../docs/desenho_ohlcv24.md). Preparação/qualificação/congelamento são separados de treino de mercado. Perguntas explicativas não criam novas pastas de revisão automaticamente; esta reorganização material tem recibos em `revisoes/limpeza_preparacao_ohlcv_2026-10-28T211713.614472Z/`.

Esta pasta já concentra evidências do trabalho. Não criar outra timeline concorrente nem mover recibos congelados. O histórico factual legível está em [docs/andamento.md](../docs/andamento.md); motivos e decisões estão em [docs/adr/](../docs/adr/README.md).

| Local | Conteúdo |
|---|---|
| `catalogo_estudos.json` | Índice retrospectivo: barreiras arquivadas, retorno24 de referência, extensão e propostas não executadas; liga decisões, dados, configurações e publicações |
| `dataset_atual.json` | Identidade e caminho do dataset; não contém os dados |
| `execucao_atual.json` | Ponteiro do estudo de referência |
| `penalizacao/execucao.json` | Ponteiro separado da extensão corrigida |
| `normalizacao/` | Autorização, preparação/qualificação e ponteiro próprio do ciclo de pré-normalização; somente Mamba novo |
| `../dados/experimentos/normalizacao_<execucao>/analises/<fase>/` | Publicações da pré-normalização, com referências herdadas identificadas |
| `qualificacao/` | Ambiente e evidências dos testes prévios |
| `penalizacao/preparacao_*/` | Preparação, qualificação e preservação da extensão |
| `analises/<execucao>/<fase>/` | Publicações, tabelas, operações e respectivas auditorias |
| `../dados/experimentos/penalizacao_<execucao>/analises/<fase>/` | Publicações próprias da extensão de penalização, separadas das análises da referência |
| `auditorias/` | Recibos de integridade e fechamento |
| `revisoes/` | Verificações posteriores, pareceres e diagnósticos |
| `incidentes/` | Falhas, interrupções, snapshots e decisões de retomada |
| `interface/` | Verificações e aceite da interface |
| `exposicao_previa.json` | Declaração histórica sobre exposição aos períodos de avaliação |

## Onde estão os modelos e cada tentativa?

O [procedimento de registro](../docs/registro_de_experimentos.md) define como manter essa cadeia ao mudar entradas, dados ou parâmetros. O [modelo de proposta](../docs/modelos/proposta_experimento.md) deve ser preenchido antes de um novo ciclo; resultados conhecidos e autorização precisam ficar explícitos.

Na pasta indicada pelo ponteiro, em `dados/experimentos/<ciclo>/celulas/<id>/tentativa_*/`. Conforme o modelo, os arquivos incluem `tentativa.json`, `resultado.json`, `auditoria.json`, `checkpoint.pt`, `epocas.json`, previsões Parquet e log. Na extensão há também `otimizador.json`; controles reexecutados ficam em `controles/` com organização equivalente.

Esses arquivos devem permitir identificar moeda, contexto, bloco, seed, configuração, escalas, origens avaliadas, seleção de época e resultado da auditoria. Não inferir informações ausentes pelo nome da pasta. Preservar tentativas interrompidas e falhas, inclusive quando outra tentativa termina corretamente.

## Como ler o progresso

1. Resolver o ponteiro do ciclo correto e verificar se a pasta existe localmente.
2. Consultar progresso e tentativas, conferindo data, host e recibos. Para atividade em tempo real, conferir PID/lock/logs no executor.
3. Se houver apenas registros copiados, relatar a data do snapshot. Ausência de pasta não demonstra que o treinamento nunca aconteceu.
4. Diferenciar resultados novos, controles e referências herdadas; não somar revalidação ou recarga como novo treinamento.

Novos recibos devem identificar ciclo, data UTC, ambiente/host quando relevante, escopo, status e caminhos/hashes das evidências. Um manifesto descreve arquivos e permite conferi-los; não substitui seu armazenamento. Seguir a [política de preservação](../docs/armazenamento_e_reproducao.md).

## Conferir o acervo disponível

Na raiz, `python manutencao/auditar_catalogo.py` confere navegação, identidades, fontes, cobertura das duas execuções atuais e publicações. `--integridade` acrescenta hashes dos arquivos manifestados por tentativa e do dataset; `--exigir-completo` falha também por ausência, adequado ao notebook executor. O modo sem essa exigência registra um clone parcial como parcial, nunca como zero treinamentos ou integridade completa. O legado de barreiras tem seus links conferidos; não é reauditado integralmente por essa ferramenta.

Cada uso gera recibo próprio em `revisoes/catalogo_*/`, acompanhado do verificador e catálogo usados. Não modifica os recibos congelados e não repete métricas ou inferência. A conferência científica da extensão continua vinculada ao seu fechamento e à revisão independente de resultados.

A pré-normalização `9e03af2150cbb7b1068d` está concluída e conferida: 384 novos ajustes e dois controles. As publicações estão na pasta própria do ciclo e o fechamento em `auditorias/9e03af2150cbb7b1068d/fechamento_normalizacao.json`. A conferência independente posterior está em `revisoes/normalizacao_2026-10-28T200441.557811_0000/`, com métricas, intervalos, operação e preservação. A auditoria do catálogo com `--integridade --exigir-completo` pode verificar a disponibilidade dos três ciclos concluídos; uma ausência em outra máquina continua sendo indisponibilidade local, não zero treinamentos. Os snapshots preservam o estado anterior em andamento.

Antes desta reorganização, os oito documentos vinculados por hash ao fechamento da extensão foram copiados para `revisoes/organizacao_2026-10-27T223818/documentos_antes/`, com conferência em `inicio.json`. Os hashes do fechamento descrevem essas versões históricas; páginas posteriores têm revisão própria. Arquivos locais não rastreados e binários ignorados continuam exigindo preservação externa verificada.

## OHLCV: preparação e próxima execução

- `ohlcv/dataset.json`: preparação multivariada atual; não reutiliza as máscaras de336h/quatro moedas.
- `ohlcv/qualificacao.json`: recibo de testes sintéticos/ambiente e treinamento curto de verificação; não resultados de mercado.
- `ohlcv/conferencias/`: reconstrução independente dos dados e escalas.
- `ohlcv/execucao.json`: ponteiro para congelamento; consultar `progresso.json` na pasta indicada para distinguir preparado de executando/concluído.
- `ohlcv/qualificacoes/`: conservar também ensaios falhos e superados; apenas o ponteiro identifica a qualificação compatível com as fontes atuais.

O novo fluxo preserva tentativas em `dados/experimentos/ohlcv24_<id>/`; nunca agrega controles de reprodução às três seeds. O auditor do catálogo histórico não afirma ter auditado essa nova grade. Não chamar o executor de ciclo concluído para refazer relatório.
