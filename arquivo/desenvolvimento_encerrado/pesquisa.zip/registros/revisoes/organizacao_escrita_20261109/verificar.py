"""Inventário de navegação para preparar a escrita; não executa experimentos."""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[3]
DESTINO = Path(__file__).resolve().parent


def resumo():
    catalogo_bytes = (RAIZ / 'registros/catalogo_estudos.json').read_bytes()
    catalogo = json.loads(catalogo_bytes)
    caminhos = set()

    def percorrer(valor):
        if isinstance(valor, dict):
            for item in valor.values():
                percorrer(item)
        elif isinstance(valor, list):
            for item in valor:
                percorrer(item)
        elif isinstance(valor, str) and re.fullmatch(
            r'(?:docs|registros|dados|arquivo|configuracoes|experimentos|analises)/[^\s;]+', valor
        ) and not any(c in valor for c in '*<>'):
            caminhos.add(valor.split('#', 1)[0])

    percorrer(catalogo)
    pastas = []
    for pasta in sorted((RAIZ / 'dados/experimentos').iterdir()):
        if pasta.is_dir():
            identificador = pasta.name.rsplit('_', 1)[-1]
            pastas.append({
                'pasta': pasta.relative_to(RAIZ).as_posix(),
                'identidade': identificador,
                'indexada': identificador in catalogo_bytes.decode('utf-8'),
                'congelamento': (pasta / 'congelamento.json').is_file(),
            })
    documentos = [RAIZ / 'README.md', RAIZ / 'plano.md', RAIZ / 'AGENTS.md']
    documentos += list((RAIZ / 'docs').rglob('*.md'))
    documentos += [RAIZ / 'registros/README.md', RAIZ / 'manutencao/README.md']
    documentos += list((RAIZ / 'escrita_tcc').rglob('*.md')) if (RAIZ / 'escrita_tcc').exists() else []
    quebrados = []
    links = 0
    for documento in documentos:
        for destino in re.findall(r'\]\(([^)]+)\)', documento.read_text(encoding='utf-8-sig')):
            destino = destino.split('#', 1)[0]
            if not destino or re.match(r'^[a-z]+:', destino):
                continue
            links += 1
            if not (documento.parent / destino).exists():
                quebrados.append({'documento': documento.relative_to(RAIZ).as_posix(), 'destino': destino})
    return {
        'utc': datetime.now(timezone.utc).isoformat(),
        'catalogo_sha256': hashlib.sha256(catalogo_bytes).hexdigest(),
        'caminhos_catalogo': len(caminhos),
        'caminhos_ausentes': sorted(p for p in caminhos if not (RAIZ / p).exists()),
        'pastas_experimentos': pastas,
        'documentos_verificados': len(documentos),
        'links_locais_verificados': links,
        'links_quebrados': quebrados,
        'limites': 'Inventário local e navegação. Integridade científica no recibo do auditor oficial; não verifica backup externo ou processo Linux.',
    }


if __name__ == '__main__':
    dados = resumo()
    (DESTINO / 'estrutura.json').write_text(json.dumps(dados, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in dados.items() if k != 'pastas_experimentos'}, ensure_ascii=False))
    print('Pastas:', len(dados['pastas_experimentos']), 'Não indexadas:', [p['pasta'] for p in dados['pastas_experimentos'] if not p['indexada']])
