# Mapa dos registros científicos

O [catálogo](catalogo_estudos.json) é o índice estruturado das execuções; [andamento](../docs/andamento.md) é a cronologia única. Para entender a fase posterior à interface, ler a [síntese da exploração com IA](../docs/exploracao_ia.md).

## Como ler um ciclo

- `execucao.json`: identidade, pasta de artefatos e vínculo ao congelamento.
- `estado.json`: situação observada; conferir host/PID/logs se houver execução ativa.
- Autorizações, qualificação e preparação: distinguem o que foi proposto do que foi executado.
- Fechamento, publicação e conferências: resultados e integridade, com leitores posteriores identificados.
- Incidentes: falhas e suas resoluções; não apagar por parecerem arquivos temporários.

Os layouts históricos variam. O catálogo aponta as fontes corretas; ausência local não equivale a zero treinamentos. Heranças não são ajustes novos. Ciclos encerrados não devem ser reexecutados para gerar relatório.

## Fase de exploração com IA consolidada

Etapa posterior autorizada: [historico_treino](historico_treino/estado.json), acumulado versus12meses. Seu ponteiro, qualificação, autorização e artefatos são independentes dos ciclos encerrados abaixo.

| Registro | Função |
|---|---|
| [busca_astra](busca_astra/estado.json) | Primeira busca e candidata final |
| [comparacao_astra_crua](comparacao_astra_crua/estado.json) | Comparação no mesmo executor |
| [futuros](futuros/estado.json) | F01: primeira simulação de futuros |
| [smart_mercados](smart_mercados/estado.json) | F02: política comum Spot/futuros |
| [revisao_operacional](revisao_operacional/estado.json) | F03: contabilidade e hipóteses de política |
| [busca_astra_002](busca_astra_002/estado.json) | Segunda busca, sem finalista |
| [operacional_futuros](operacional_futuros/estado.json) | Busca conjunta modelo/política |
| [diagnostico_operacional](diagnostico_operacional/estado.json) | Diagnóstico de leitura posterior |
| `organizacao_exploracao_ia_001/` | Consolidação, inventário, limpeza e duas verificações |

Modelos, previsões e carteiras estão em `dados/experimentos/`; tabelas diagnósticas em `dados/diagnosticos/`. Os registros acima não duplicam todos esses arquivos. As investigações anteriores, dados, módulos e referências continuam indexados no catálogo em seus próprios diretórios.

## Regras de manutenção

Não guardar explicações de chat como novos relatórios aqui. Recibos e snapshots só quando necessários para uma execução, incidente, transferência ou preservação de versão vinculada. Não mover arquivos congelados, reescrever hashes ou selecionar seeds favoráveis.

Arquivos locais ignorados pelo Git não estão protegidos remotamente. A transferência entre máquinas deve incluir os pacotes e a [verificação de integridade](../docs/armazenamento_e_reproducao.md). Ferramenta do catálogo: `python manutencao/auditar_catalogo.py --integridade --exigir-completo` no computador executor.
