"""Conferência posterior somente de leitura dos bytes preservados antes da escrita."""
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(RAIZ))
from manutencao.auditar_catalogo import Auditor


def main():
    instante = datetime.now(timezone.utc)
    destino = Path(__file__).parent / instante.strftime('integridade_%Y%m%dT%H%M%SZ')
    destino.mkdir(exist_ok=False)
    ponteiro = json.loads((RAIZ / 'registros/generalizacao_moedas/execucao.json').read_bytes())
    congelamento = RAIZ / ponteiro['pasta'] / 'congelamento.json'
    congelado = json.loads(congelamento.read_bytes())
    auditor = Auditor(RAIZ, integridade=True)
    auditor.conferir(congelamento.relative_to(RAIZ).as_posix(), ponteiro['congelamento_sha256'])
    for i, (caminho, esperado) in enumerate(congelado['preservacao'].items(), 1):
        auditor.conferir(caminho, esperado)
        if i % 1000 == 0:
            print(f'PRESERVACAO {i}/{len(congelado["preservacao"])}', flush=True)
    for caminho, esperado in congelado['fontes'].items():
        auditor.conferir(caminho, esperado)
        auditor.conferir((Path(ponteiro['pasta']) / 'fontes' / caminho).as_posix(), esperado)
    manutencao = json.loads((Path(__file__).parent / 'manutencao.json').read_bytes())
    for editorial in manutencao['editoriais']:
        auditor.conferir(editorial['caminho'], editorial['depois'])
    reservada = RAIZ / 'escrita_tcc/cronologia_narrativa'
    narrativa_vazia = sorted(p.name for p in reservada.iterdir()) == ['.gitkeep'] and (reservada / '.gitkeep').stat().st_size == 0
    if not narrativa_vazia:
        auditor.erros.append('Area de narrativa deixou de estar vazia')
    resultado = {
        'utc': instante.isoformat(), 'execucao_referencia': ponteiro['id'],
        'status': 'divergente' if auditor.erros else 'parcial' if auditor.ausentes else 'conferido',
        'hashes_verificados': len(auditor.hashes), 'preservacao_prevista': len(congelado['preservacao']),
        'fontes_previstas': len(congelado['fontes']), 'erros': auditor.erros,
        'ausentes': sorted(auditor.ausentes), 'narrativa_vazia': narrativa_vazia,
        'limites': 'Conferencia dos bytes vinculados ao congelamento mais recente e dos editoriais apos manutencao; nao recalcula metricas nem verifica arquivos mutaveis do treino ativo, backup externo ou todo arquivo fora dos manifestos.',
        'verificador_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    (destino / 'verificador.py').write_bytes(Path(__file__).read_bytes())
    (destino / 'resumo.json').write_text(json.dumps(resultado, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'recibo': str(destino / 'resumo.json'), **resultado}, ensure_ascii=False), flush=True)
    return int(bool(auditor.erros or auditor.ausentes))


if __name__ == '__main__':
    raise SystemExit(main())
