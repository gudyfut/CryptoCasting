"""Inspeção sem treino; não importa nem executa código externo do CryptoMamba."""
from pathlib import Path
import datetime
import hashlib
import inspect
import json
import sys
import urllib.request
import importlib.metadata

RAIZ = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(RAIZ))
import torch
from mamba_ssm import Mamba
import selective_scan_cuda
import causal_conv1d_cuda
from previsao24.redes import RedeMamba, RedeLSTM

pasta = Path(__file__).resolve().parent
configuracao = json.loads((RAIZ / 'configuracoes/retorno24_001.json').read_text())
modelo = RedeMamba(configuracao['mamba'])
fonte = Path(inspect.getfile(Mamba))
sha = lambda b: hashlib.sha256(b).hexdigest()
oficial_url = 'https://raw.githubusercontent.com/state-spaces/mamba/v2.2.6.post3/mamba_ssm/modules/mamba_simple.py'
oficial = urllib.request.urlopen(oficial_url, timeout=30).read()
(pasta / 'mamba_simple_oficial.py').write_bytes(oficial)
(pasta / 'mamba_simple_instalado.py').write_bytes(fonte.read_bytes())
qualificacao = json.loads((RAIZ / 'registros/penalizacao/preparacao_2026-10-26T233400.168859_0000/qualificacao.json').read_text())
resultado = {
    'consultado_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'escopo': 'Instanciação CPU para inspecionar atributos; sem forward, treino ou inferência de mercado.',
    'classe': Mamba.__module__ + '.' + Mamba.__name__,
    'assinatura': str(inspect.signature(Mamba)),
    'pacote': importlib.metadata.version('mamba-ssm'),
    'torch': torch.__version__, 'cuda_torch': torch.version.cuda,
    'cuda_disponivel': torch.cuda.is_available(),
    'fonte_instalada': str(fonte), 'fonte_sha256': sha(fonte.read_bytes()),
    'url_oficial': oficial_url, 'oficial_sha256': sha(oficial),
    'instalado_identico_fonte_oficial': fonte.read_bytes() == oficial,
    'extensoes': {m.__name__: {'arquivo': m.__file__, 'sha256': sha(Path(m.__file__).read_bytes())}
                  for m in [selective_scan_cuda, causal_conv1d_cuda]},
    'blocos': [{k: getattr(b, k) for k in ['d_model', 'd_state', 'd_conv', 'expand', 'd_inner', 'dt_rank', 'use_fast_path']}
               for b in modelo.blocos],
    'parametros_mamba': sum(p.numel() for p in modelo.parameters()),
    'parametros_lstm': sum(p.numel() for p in RedeLSTM(configuracao['lstm']).parameters()),
    'marcados_sem_penalizacao': {n: p.numel() for n,p in modelo.named_parameters() if getattr(p, '_no_weight_decay', False)},
    'marcados_sem_reinicializacao': [n for n,p in modelo.named_parameters() if getattr(p, '_no_reinit', False)],
    'qualificacao_chaves': list(qualificacao),
}
assert resultado['instalado_identico_fonte_oficial']
assert resultado['parametros_mamba'] == 20129
assert resultado['parametros_lstm'] == 12961
assert sum(resultado['marcados_sem_penalizacao'].values()) == 2176
(pasta / 'instalacao.json').write_text(json.dumps(resultado, indent=2, ensure_ascii=False), encoding='utf-8')
print(json.dumps(resultado, indent=2, ensure_ascii=False))
