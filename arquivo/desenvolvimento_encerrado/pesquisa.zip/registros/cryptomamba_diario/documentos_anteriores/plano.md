# Plano de trabalho

Atualizado em 05/11/2026. **Primeira averiguação concluída: acumulado versus12meses**, conforme [protocolo](docs/protocolo_historico_treino.md) e [estado verificável](registros/historico_treino/estado.json). Foram18principais+2controles e456carteiras, preservando C06/calendário anteriores. A janela móvel piorou o MSE médio em0,94% e reduziu a perda operacional média em1,20pp, com incerteza incluindo zero; nenhuma versão foi promovida. [Análise e conferência](docs/andamento.md). Não iniciar6meses, V/C mensais ou outras hipóteses automaticamente. A busca ampla abaixo permanece proposta, não autorização de216/280ajustes ou de novos limites pessoais de risco.

A fase anterior permanece consolidada em [Exploração com IA](docs/exploracao_ia.md). Este é o planejamento vigente, separado dos protocolos encerrados e sem criar uma coleção de documentos por interação.

## 1. Objetivo e liberdade de alteração

Investigar **informação disponível + Mamba + tarefa + treinamento + política de futuros**, buscando crescimento líquido positivo com risco e estabilidade explícitos. A unidade de seleção é o sistema inteiro, inclusive reestimação e dimensionamento; não apenas um checkpoint.

Todas as dimensões científicas podem mudar: canais, representação, candles, contexto, histórico de treino, horizonte, arquitetura, perda, otimizador, seleção, entrada/saída e tamanho. Uma receita pode mudar vários fatores, mas não atribuímos seu resultado a um fator isolado. Liberdade não implica testar o produto cartesiano de todos os parâmetros.

Causalidade, contabilidade, custos e preenchimentos precisam representar o mercado. Corrigir o motor é permitido antes de congelá-lo; não escolher uma convenção irreal porque aumenta o lucro. Correção posterior exige revisão identificada e comparação comum das receitas afetadas.

## 2. Lições que orientam a prioridade

O [diagnóstico anterior](docs/diagnostico_operacional.md) encontrou mudança de regime:94,88% de S no tercil inferior de volatilidade definido em T; preferência histórica por venda; ordenação fraca das oportunidades; validação piorando enquanto treino melhorava; e operações que acertaram direção terminal, mas perderam com saída/custos. Isso orienta hipóteses, sem provar suas causas.

A última rodada **já usou futuros e payoff por lado**. Não anunciar isso como solução nova. Priorizar histórico de treino/regime → informação/representação → alinhamento alvo/saída → horizonte/frequência/contexto → capacidade/otimização. A ordem pode ser revista com evidência dentro do orçamento; aumentar estados/épocas/alavancagem não é a primeira hipótese recomendada.

## 3. Receita de partida e alternativas

| Elemento | Recomendação inicial |
|---|---|
| Mercado | BTCUSDT perpétuo linear USD-M; compra, venda ou caixa |
| Dados | Candles completos1h do próprio futuro; execução e marcação1min |
| Contexto | 168h; alternativa72h, preservando tempo físico ao mudar candles |
| Histórico de treino | Acumulado e12meses comparados, sem vencedor confirmado;6meses permanece hipótese não executada |
| Reestimação | Trimestral, do zero; escalas próprias de T |
| Rede | Mamba oficial CUDA, estado16, largura32, dois blocos, pré-LayerNorm; AdamW0,0002 como referência |
| Entradas | OHLC relativos/retornos e log-volume/volume relativo; amplitude, posição do fechamento, momentum e volatilidade como grupos identificados |
| Tarefa | Payoff líquido unitário esperado de compra e venda sob saída explícita |
| Prazo inicial | Máximo24h, distinto da frequência de decisão |
| Carteira | Uma posição líquida, sem ordens reais, pirâmide ou martingale |
| Risco central | Orçamento nominal0,5% do patrimônio até stop; nocional inicial limitado a95% do patrimônio |

A escolha de volume deriva de uma pista fraca de C06, não de receita vencedora. Fórmulas/canais exatos serão fechados antes da execução. Mais entradas não asseguram melhoria.

Informação nova prioritária: volume comprador agressor relativo, quantidade de negócios e atividade relativa; depois funding já publicado e diferença futuro/índice ou futuro/Spot, se houver cobertura e disponibilidade temporal verificável. Klines oficiais de futuros contêm campos além de OHLCV. Conferir os brutos antes de recolher; não reconstruir order book/open interest históricos inexistentes com dados atuais.

Domínios inicialmente recomendados, sem grade cartesiana: candles1h/4h; contexto72/168h; histórico6/12/24meses ou acumulado; horizonte8/24/72h; informações de OHLCV/fluxo/funding causal; payoff médio/distribuição; saída com/sem take. Arquitetura, perda, otimizador e scheduler também podem mudar com justificativa. Candles15min, outros ativos e aprendizado por reforço permanecem possíveis, mas exigem orçamento e qualificação antes de ampliar esta leva. BTC não sustenta generalização às quatro moedas da proposta original.

## 4. Alvo, treinamento e decisão

**Família principal:** dois resultados hipotéticos líquidos por unidade de nocional, compra/venda, calculados com entrada posterior ao sinal, saída definida, custos e funding. O modelo estima médias condicionais. Previsão+0,30% é estimativa de resultado médio, não probabilidade de acerto nem ganho garantido.

MSE é referência para aprender a média. Huber pode ser candidata, mas sua saída não coincide em geral com a esperança do payoff. Não presumir que robustez significa retorno esperado calibrado. Escalas só em T; normalização causal por volatilidade exige inversão por origem, avaliação em unidades reais e registro da ponderação implícita da perda.

**Alternativa probabilística:** média e quantis de payoff por lado, para avaliar retorno e risco previsto. Quantis10/50/90 usam perda e cobertura próprias; não permitem reconstruir exatamente a média ou a cauda inteira. Dispersão entre seeds não equivale a intervalo probabilístico calibrado. Combinação de perdas e seleção de checkpoint precisam ser definidas/qualificadas antes dessa receita.

**Controle terminal:** receita de retorno24h reestimada no mesmo executor/calendário. Classificação ou primeiro limite também são alternativas, mas probabilidade de ganhar não contém magnitude de ganhos/perdas; expiração não tem retorno automaticamente zero. Exigir calibração/Brier/log-loss quando houver probabilidades e conversão explícita para utilidade econômica. Não comparar valores numéricos de MSE entre tarefas diferentes.

Checkpoint escolhido em V pela métrica preditiva previamente definida para a tarefa. A seleção da receita completa usa desempenho econômico no desenvolvimento. Treinar diretamente por recompensa de carteira é uma hipótese posterior: exige posições/custos/caminho causal e testes de exploração do simulador; não significa usar lucro do teste como perda.

## 5. Saídas, filtro e risco por operação

Investigar duas famílias: stop/take/prazo e stop/prazo sem take fixo. A segunda verifica se realizar cedo limita ganhos, sem pressupor que retirar proteção resolveria perdas. Referência: volatilidade horária168h escalada ao horizonte; stop em distância logarítmica max(volatilidade,0,5%); take1,5×stop. Cada mudança de stop/take/horizonte altera o payoff, exige outra identidade de alvo e retreino. Não aplicar previsões de payoff antigo a outra saída como se estimassem a mesma coisa.

Flat: abrir o lado com maior previsão líquida acima da margem; empate não abre. Em posição: seguir a saída da receita, sem operações sobrepostas. Quatro políticas internas iniciais: margem extra0/10bps × decisão1h/4h. Não descontar custos duas vezes. Previsão menos frequente pode reduzir giro, mas não cria informação preditiva.

Tamanho nominal = orçamento de perda dividido por distância de stop mais custos previstos, limitado por nocional, filtros e margem. Stop não garante perda máxima em gaps. Teto95% é na entrada; monitorar depois, especialmente no short. Alterar limiar/tamanho pode reutilizar a mesma tarefa, respeitando custo de tamanho; trailing, saída por sinal ou parcial precisam de tarefa/política próprias.

## 6. Como escolher lucro com risco aceitável

Recomendação: **crescimento logarítmico líquido com restrições de risco**, acompanhado da fronteira retorno–risco. g=log(E_final/E_inicial)/dias. Mostrar também retorno efetivo; anualização não é promessa. g não mede sozinho o caminho. Calmar é complementar: razão alta com drawdown minúsculo pode valorizar lucro pequeno demais.

Perfil central proposto: risco nominal0,5% por entrada; drawdown máximo25% no cenário base e35% no estresse. São escolhas de engenharia para discussão, não tolerância pessoal já aprovada ou garantia de limitar perdas. Mostrar alternativas fora desses limites, mas não elegê-las para esse perfil.

Após selecionar a receita, simular sensibilidades de tamanho0,25%/0,5%/1%, sem escolher pelo teste. Mesmo teto de nocional; não multiplicar retornos por uma constante. A fronteira mostra se risco maior compensou em crescimento. Não usar Kelly alimentado por probabilidades não calibradas.

Painel obrigatório: retorno/g; drawdown e recuperação; média de perda nos5% piores dias (ES95 empírico e tamanho da amostra); Sharpe/Sortino/Calmar complementares; dias ativos/operações/exposição/giro; compra/venda; comissão/slippage/funding; estabilidade temporal e entre seeds. Métricas sem suporte/denominador ficam não estimáveis, não infinito favorável.

Seleção de desenvolvimento: entre elegíveis, maior mediana de g dos três recortes da carteira ensemble; empate por menor giro, depois menor drawdown. Elegibilidade proposta: crescimento agregado positivo em base e estresse principal, pelo menos2/3recortes positivos, limites de risco respeitados e ao menos100operações distintas distribuídas por seis meses de período avaliado. Esse suporte é escolha operacional, não100amostras independentes ou garantia estatística. Não exigir trades dos dois lados em cada trimestre; declarar evidência insuficiente por lado quando necessário.

Política reprovada não esconde o sinal: manter diagnósticos e simulações diagnósticas previamente orçadas, marcadas inelegíveis. Pode orientar hipótese posterior, não virar finalista por falta de opção. Não afrouxar critérios após o placar.

Na avaliação final, distinguir resultado negativo/reprovado; positivo promissor porém incerto; evidência retrospectiva favorável com custos/risco/intervalos compatíveis. Intervalo incluindo zero impede alegar lucro demonstrado. Nenhuma categoria certifica lucro futuro.

## 7. Divisão temporal e confirmação

T aprende pesos/escalas; V seleciona época; C calibra política; S compara receitas e alimenta Astra. **S é desenvolvimento adaptativo**, não teste independente. Uma política conjunta usa somente C/seeds disponíveis no próprio recorte, nunca calibração futura.

Para aproximar a informação do período avaliado, propor V/C de um mês cada. Exemplo: S=abril–junho2023; T12m=[01/02/2022,01/02/2023); V=fevereiro2023; C=março2023. Deslocar três meses para S julho–setembro e outubro–dezembro. Comparar acumulado/12m/6m nesse mesmo calendário. O calendário também difere do ciclo antigo; não atribuir todo ganho só à janela móvel.

Um mês de C escolhe apenas quatro políticas predefinidas. Se suporte estrutural for insuficiente na revisão pré-execução, rever calendário para todas antes de novos resultados; não prolongar C porque o lucro foi ruim. Purga pelo instante de realização do alvo, incluindo latência/prazo; população comum compatível com horizonte máximo72h. Contexto pode usar passado anterior à fronteira, mas rótulo de T não invade V. Mesmas origens admissíveis, escalas só em T, datas exclusivas e sem interpolação.

Depois de congelar candidata e procedimento, comparar com referência nos **oito trimestres de2024–2025**, reestimando trimestralmente com T/V/C causais. Políticas podem ser recalibradas pelo procedimento congelado, sem revisão humana/Astra após consultar o final. Resultados anteriores podem entrar no treino seguinte quando sua realização já pertence ao passado permitido.

2023 foi consultado adaptativamente;2024–2025 já foram consultados em outros estudos. É avaliação retrospectiva, não holdout intocado. Auditar exposição antes de reservar2026. Confirmação realmente nova requer período não consultado ou registro prospectivo de previsões após congelamento, sem ordens reais; poucas semanas não estabelecem longo prazo.

Relatar carteiras independentes por trimestre e uma sequência operacional contínua adicional, com patrimônio carregado, fechamento no rebalanceamento trimestral e custos. Simular a sequência de verdade: filtros/tamanhos dependem do capital. Não somar retornos independentes ou concatenar médias de seeds como uma carteira.

## 8. Busca Astra e orçamento proposto

Até12receitas incluindo duas âncoras. Priorizar contraste acumulado/12m/6m; reservar os demais lugares para entradas, alvo, política, horizonte/candles/contexto ou rede motivados pelo feedback. Não precisamos alterar todas as dimensões nem consumir o teto.

Proponente recebe diferenças frente ao pai, desempenho por lado/regime/magnitude, ordenação/calibração, curvas treino/V, suporte, estabilidade e custos. Toda proposta registra mecanismo, alteração, critério de fracasso e custo esperado. Avaliador não pode ser editado pelo proponente. Não enviar final à busca; isolamento não apaga a exposição histórica já presente na conversa.

| Etapa | Teto de ajustes Mamba |
|---|---:|
| 12receitas×2seeds×3recortes | 72 |
| Reforçar âncora + até1candidata para4seeds nos3recortes | 12 adicionais |
| Referência + finalista,8seeds×8trimestres | 128 |
| Controles reais identificados, fora das médias | Até4 |
| Total | **Até216** |

Controles precedem dependentes; não são médias. Lista/ordem das oito seeds vêm do conjunto histórico e precisam constar da configuração. Promoção exige coortes completas. Sem candidata sustentada após reforço, não gastar automaticamente os128ajustes finais. As quatro políticas e três cenários de custo por receita, ensembles, riscos e diagnósticos exigem contagem exata de carteiras no manifesto antes de executar; não abrir grades escondidas como análise.

Antes de iniciar, medir tempo/memória, fechar prazo de parede e reserva de auditoria. Não prometer216ajustes numa noite. Se necessário, reduzir receitas ainda não iniciadas; não esconder células ausentes ou eliminar controles. Este orçamento é proposta, não autorização de execução.

## 9. Ensemble, referências e incerteza

Produto operacional recomendado: **média das previsões de oito redes**, com política calibrada para esse ensemble em C. Não confundir com média do retorno de oito carteiras. Publicar a carteira ensemble e resultados individuais. Nas coortes2/4seeds, usar somente aquelas redes; expandir implica nova calibração em C, preservando avaliação anterior.

Referências econômicas: caixa, média de payoff aprendida só em T, regra de tendência causal predefinida e exposição comprada/passiva com funding/custos. Mostrar exposição e risco comparável, com escalas definidas só no passado. Naive de retorno zero continua referência preditiva pertinente; vencer caixa não basta para atribuir valor à rede.

LSTM é recomendada no fechamento acadêmico com mesma tarefa/dados/política, sem ocupar toda a busca: até64ajustes adicionais (8seeds×8trimestres), total até280 se incluída na execução. ARIMA permanece controle terminal univariado; não fingir duas cabeças de payoff. Inclusão final precisa caber no prazo e no escopo acadêmico. BTC e objetivo operacional ampliado devem ser explicitados frente à proposta original; PDF não alterado.

Usar contrastes pareados e bootstrap temporal de retornos diários, blocos14dias e sensibilidades7/28. Preservar seeds como unidades quando aplicável; oito seeds não são oito mercados e um ensemble não tem oito repetições independentes. Intervalos simples da vencedora não corrigem toda a seleção adaptativa. Registrar todas as tentativas, inclusive políticas, mostrar concentração dos lucros, meses/trimestres/lados e não fabricar probabilidade exata de sucesso futuro.

## 10. Motor, custos e prontidão

As bases preservadas cobrem2021–2025; parte do mark exato no funding está ausente e tem aproximação adversa documentada. Reutilizar somente após conferir hashes/contratos/cobertura. Não anunciar dados novos ou simulador certificado sem evidência.

Hipóteses iniciais comparáveis: comissão taker0,05% por lado, slippage0,05% por preenchimento e funding histórico. Estresse principal slippage0,10%; secundário0,15%. São premissas de pesquisa, não tarifa comprovada de conta. Confirmar fontes e premissas históricas antes de congelar; não escolher custo pelo lucro ou preencher ausências com zero.

Qualificar: candle disponível; perturbação do futuro não muda sinais passados; rótulo unitário equivale à operação isolada; compra/venda; stop/take/prazo/gaps; comissão/funding/reversões; precisão/filtros; patrimônio/margem; CUDA, atualização, repetição e recarga; auditoria contábil independente. Preços negociáveis para preenchimento, mark para margem/patrimônio. Fonte de gatilho declarada. Latência mínima1min; ambiguidade intraminuto com stop primeiro; nenhuma liquidez maker presumida. Limites de dados/execução permanecem explícitos.

Buffer prudencial não é liquidação completa Binance. Ausência de tabelas históricas exige envelope conservador e limitações, nunca ignorar perdas. Não usar alavancagem elevada enquanto o risco de margem não estiver adequadamente modelado.

Próxima ação após discutir este desenho: fechar fórmulas, receitas iniciais, seeds, calendários, perda/seleção, políticas e contagens; implementar/qualificar versão isolada; congelar identidade e vincular autorização. Modelos antigos não são modificados. Até lá, nenhum treinamento/backtest novo.

## Fontes e navegação

- [Busseti, Ryu e Boyd — Risk-Constrained Kelly Gambling](https://www.web.stanford.edu/~boyd/papers/kelly.html): crescimento e risco exigem tratamento distinto; não aplicamos suas garantias teóricas ao nosso backtest empírico.
- [Gneiting e Raftery — Strictly Proper Scoring Rules](https://stat.uw.edu/research/tech-reports/strictly-proper-scoring-rules-prediction-and-estimation): probabilidades/distribuições exigem avaliação adequada; não equivalem a rentabilidade.
- [Binance — dados públicos](https://github.com/binance/binance-public-data), [dados de futuros](https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data) e [liquidação](https://www.binance.com/en/support/faq/detail/360033525271): campos, proveniência, funding e diferença entre negociação/mark; regra atual não certifica regra histórica.
- [Síntese encerrada](docs/exploracao_ia.md), [diagnóstico](docs/diagnostico_operacional.md), [cronologia](docs/andamento.md), [catálogo](registros/catalogo_estudos.json), [arquitetura](docs/README.md) e [TCC1](docs/TCC_1_MuriloRFM.pdf).
