# Arquitetura das simulações de operação

## Revisão F03

`simulacao_operacoes/revisada/` separa `regras.py` (lotes, filtros e redução), `conta.py` (comissão recebida e colateral), `politica.py` (decisão causal), `simulador.py` (tempo, funding e execução) e `auditoria.py` (fórmulas independentes). O coordenador é `python -B -m experimentos.revisao_operacional preparar|executar`; ações distintas, autorização/identidade próprias e bloqueio de repetição. Consultar [protocolo](protocolo_revisao_operacional.md) e [estado](../registros/revisao_operacional/estado.json). Fontes F01/F02 abaixo são históricas imutáveis. A conferência posterior `python -B -m analises.revisao_operacional` lê ledgers e recalcula risco, sem repetir carteiras.

Nenhum simulador promete reproduzir integralmente uma conta Binance. Custos, filtros conservadores, preço de execução aproximado e envelope prudencial são identificados. Não chamar melhoria de fidelidade de melhoria garantida da previsão ou do lucro.

As avaliações de previsão e de operação são camadas diferentes. MSE/MAE usam alvo observado na avaliação estatística. Uma política de operação recebe somente a previsão e informações disponíveis na origem. Os módulos operacionais não importam modelos nem iniciam treinamento.

```text
publicações de previsões já encerradas
                 ↓ leitura e checksum
simulacao_operacoes/previsoes.py  → contrato sem alvo/preço futuro
                 ↓
simulacao_operacoes/politicas.py  → direção decidida causalmente
                 ↓
simulacao_operacoes/futuros/     ← mercado_futuros/ (negócios, mark, funding)
  contabilidade + simulador + auditoria separada
                 ↓
experimentos/futuros/            → grade, identidade, lock e publicação
                 ↓
dados/experimentos/futuros_<id>/  + registros/futuros/
```

| Responsabilidade | Local | Contrato |
|---|---|---|
| Coleta pública de perpétuos | `mercado_futuros/pipeline.py` | Arquivos/checksums/API; não calcula sinais ou lucro |
| Contexto anterior à primeira origem | `mercado_futuros/contexto.py` | Complemento identificado; não altera pai publicado |
| Previsões para operação | `simulacao_operacoes/previsoes.py` | UTC, horizonte24h, origens únicas, sem coluna de alvo |
| Política | `simulacao_operacoes/politicas.py` | Previsão/configuração → −1/0/+1; sem acesso ao mercado futuro observado |
| Contabilidade | `simulacao_operacoes/futuros/contabilidade.py` | Quantidade assinada, PnL, funding, custos |
| Mercado carregado | `simulacao_operacoes/futuros/mercado.py` | Cobertura contínua e arrays de observações; não contém previsões |
| Simulação | `simulacao_operacoes/futuros/simulador.py` | Operações, curva, funding e resumo; buffer de margem bloqueante |
| Conferência | `simulacao_operacoes/futuros/auditoria.py` | Recalcula saldo e ledger sem chamar simulador |
| Rodada identificada | `experimentos/futuros/` | Grade fixa, preservação, snapshot, autorização e execução exclusiva |
| Qualificação | `tests_simulacao_operacoes/` | Cenários sintéticos causais, não otimização em mercado |

Os executores Spot históricos (`backtest_carteira/`, módulos de ciclos e avaliações congeladas) permanecem intactos. Não movê-los para criar aparência de unificação: seus hashes e caminhos fazem parte da evidência. Novas políticas/mercados poderão usar contratos semelhantes, mas exigem novo protocolo e identidade; resultados de uma identidade nunca são sobrescritos.

Método: [protocolo F01](protocolo_futuros.md). Estado real: [registros](../registros/futuros/estado.json). Dados públicos têm [estado próprio](../registros/mercado_futuros/estado.json). Textos/recibos podem ser versionados; ZIPs, curvas e checkpoints continuam sujeitos à [política de armazenamento](armazenamento_e_reproducao.md).


Análise posterior: `python -B -m analises.futuros` verifica fechamento e ledgers publicados, grava recibo novo em `registros/futuros/conferencias/` e recompõe o relatório editorial. Não chama treinamento ou execução. A conferência já entregue fica preservada; não repetir para obter outro resultado. Interpretações editoriais adicionais devem permanecer no relatório canônico, sem alterar publicações congeladas.


## Smart retida compartilhada — F02

`simulacao_operacoes/smart/` acrescenta política de ajuste líquido, conta Spot/colateral de futuros, leitor dos dois mercados, simulador retido e auditor por caixa equivalente. O teste de preços idênticos/funding zero exige equivalência entre contas. `experimentos/smart_mercados/` congela e executa a grade autorizada; `tests_smart_mercados/` qualifica. [Protocolo](protocolo_smart_mercados.md), [estado](../registros/smart_mercados/estado.json). Fontes deF01 permanecem inalteradas. Nova política/gestão comum não substitui a Smart histórica e não exige novos checkpoints.
