import ast,json
from collections import Counter
from pathlib import Path
R=Path(__file__).resolve().parents[3];D=Path(__file__).parent
v=json.loads((D/'inventario_antes.json').read_bytes()); fontes=v['python']; todos=set(fontes)
f=json.loads((R/'dados/experimentos/generalizacao_moedas_1f2b005888361d23c111/congelamento.json').read_bytes())
fixos=set(f['fontes'])|set(f['preservacao'])
fixos.update(json.loads((R/'dataview/src/data/panorama.json').read_bytes())['fontes'])
core={'mercado_binance','mercado_futuros','entradas_modelo','modelos','treinamento','avaliacao','simulacao_operacoes','infraestrutura'}
manter={p for p in todos if p.split('/')[0] in core or p in fixos or p.startswith('dataview/')}
manter.update(p for p in todos if p.startswith(('tests_dados/','tests_modelos/','tests_treinamento/','tests_simulacao_operacoes/')))
manter.update(p for p in todos if p in {'run_dados.py','run_modelos.py','run_treinamento.py','manutencao/auditar_catalogo.py','analises/__init__.py','analises/agregacao.py','analises/metricas.py','analises/previsoes.py'} or p.startswith('experimentos/') and p.count('/')==1)
modulos={p.removesuffix('.py').replace('/','.').removesuffix('.__init__'):p for p in todos}
for p in todos:
 if p.endswith('/__init__.py'):modulos[p[:-12].replace('/','.')]=p
def resolver(modulo):
 saida=set()
 while modulo:
  if modulo in modulos:saida.add(modulos[modulo])
  modulo=modulo.rpartition('.')[0]
 return saida
deps={}
for p in todos:
 a=ast.parse((R/p).read_text(encoding='utf-8-sig')); base=p.removesuffix('.py').split('/')[:-1];ds=set()
 for n in ast.walk(a):
  if isinstance(n,ast.Import):
   for z in n.names:ds.update(resolver(z.name))
  elif isinstance(n,ast.ImportFrom):
   partes=base[:len(base)-n.level+1] if n.level else []
   if n.module:partes+=n.module.split('.')
   m='.'.join(partes);ds.update(resolver(m))
   for z in n.names:ds.update(resolver(m+'.'+z.name))
  elif isinstance(n,ast.Constant) and isinstance(n.value,str):
   s=n.value
   if s.startswith(('tests_','manutencao.')):
    raiz=s.split('.')[0].split('/')[0]
    ds.update(q for q in todos if q.startswith(raiz+'/'))
   if s in todos:ds.add(s)
 deps[p]=ds
while True:
 novo=manter|set().union(*(deps[p] for p in manter))
 if novo==manter:break
 manter=novo
# Leituras posteriores uteis ficam agrupadas por etapa, com bytes intactos.
mover={}
for p in sorted(todos-manter):
 if p.startswith('analises/'):
  nome=Path(p).name
  if p.startswith('analises/diagnostico_operacional/'):
   mover[p]=p.replace('analises/diagnostico_operacional/','analises/etapas/diagnostico_operacional/')
   continue
  etapa=('futuros' if any(s in nome for s in ['futuros','smart','revisao_operacional','direcao']) else
         'historico_treino' if 'historico_treino' in nome else
         'padronizacao_diaria' if any(s in nome for s in ['padronizacao','padronizado']) else
         'sem_penalizacao_diaria' if 'sem_penalizacao' in nome else
         'alvo_retorno_diario' if 'alvo_retorno' in nome else
         'cryptomamba_reproducivel' if 'reproducivel' in nome else 'cryptomamba_diario')
  mover[p]=f'analises/etapas/{etapa}/{nome}'
arquivar=sorted(todos-manter-set(mover))
# Scripts avulsos das revisoes ficam no mesmo pacote, mantendo os recibos e logs.
arquivar += [a['caminho'] for a in v['arquivos'] if a['caminho'].startswith('registros/revisoes/') and a['caminho'].endswith('.py') and a['caminho'] not in fixos]
marcadores={'antes','editorial_antes','documentos_antes','documentos_anteriores','documentos_antes_diagnostico','editorial_anterior'}
arquivar += [a['caminho'] for a in v['arquivos'] if a['caminho'].startswith('registros/') and a['caminho'].endswith('.md') and any(x in marcadores for x in Path(a['caminho']).parts) and a['caminho'] not in fixos]
# Somente arquivos de codigo auxiliares que acompanham pacotes encerrados.
for a in v['arquivos']:
 p=a['caminho']
 if p.endswith(('.ps1','.sh')) and p not in fixos and p.split('/')[0] not in {'dados','registros','arquivo','dataview'}:
  if p.startswith('manutencao/') or p.split('/')[0].startswith('experimento_') or p.startswith('experimentos/') and not any(q.startswith(str(Path(p).parent).replace('\\','/')+'/') for q in manter):arquivar.append(p)
assert not set(arquivar)&fixos
assert not set(mover)&fixos
# Documentos vinculados ao treino vivo ou a interface e seus links ficam fixos.
import re
from urllib.parse import unquote
docs=set(v['documentos']); docs_fixos=docs&fixos
while True:
 novos=set(docs_fixos)
 for p in docs_fixos:
  for href in re.findall(r'\]\(([^)]+)\)',(R/p).read_text(encoding='utf-8-sig')):
   href=unquote(href.split('#',1)[0])
   if not href or ':' in href:continue
   alvo=(R/p).parent/href
   try:rel=alvo.resolve().relative_to(R).as_posix()
   except ValueError:continue
   if rel in docs:novos.add(rel)
 if novos==docs_fixos:break
 docs_fixos=novos
editoriais={'docs/README.md','docs/andamento.md','docs/exploracao_ia.md','docs/roteiro_redacao_tcc.md','docs/armazenamento_e_reproducao.md','docs/registro_de_experimentos.md','docs/adr/README.md'}
editoriais.update(p for p in docs if p.startswith(('docs/arquitetura_','docs/modelos/')))
for p in sorted(docs-docs_fixos-editoriais):
 nome=Path(p).name
 if p.startswith('docs/adr/'):
  etapa=nome.removesuffix('.md')[5:]
 else:etapa=re.sub(r'^(protocolo|resultados|desenho|diagnostico)_','',nome.removesuffix('.md'))
 mover[p]=f'docs/etapas/{etapa}/{nome}'
plano={'manter_python':sorted(manter),'arquivar':sorted(set(arquivar)),'mover':mover,'fixos_execucao_interface':sorted(fixos),'dependencias':{p:sorted(ds) for p,ds in deps.items() if p in manter},'classificacao_python':{p:'core_dependencia_ou_fonte_ativa' if p in manter else 'leitura_posterior_por_etapa' if p in mover else 'codigo_encerrado_preservar_em_pacote' for p in todos}}
(D/'plano.json').write_text(json.dumps(plano,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('MANTER',len(manter),'ARQUIVAR',len(plano['arquivar']),'MOVER',len(mover))
print('ARQUIVAR_POR_RAIZ',dict(Counter(p.split('/')[0] for p in plano['arquivar'])))
print('MOVER',mover)
print('MANUTENCAO_MANTIDA',[p for p in manter if p.startswith('manutencao/')])
print('DIRETORIOS_ESVAZIADOS',[p for p in v['grupos'] if any(q.startswith(p+'/') for q in arquivar) and not any(q.startswith(p+'/') for q in manter) and p not in {'experimentos','manutencao'}])
