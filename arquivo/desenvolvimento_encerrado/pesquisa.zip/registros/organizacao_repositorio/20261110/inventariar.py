import ast, collections, json, os, re
from pathlib import Path
from datetime import datetime, timezone

R=Path(__file__).resolve().parents[3]
D=Path(__file__).parent
IGN={'.git','.venv','.venv_wsl','node_modules','.next','__pycache__','.pytest_cache','.mypy_cache','.ruff_cache'}
arquivos=[]; grupos=collections.defaultdict(lambda:[0,0]); py={}; textos={}; protegidos=collections.defaultdict(set)
for base, dirs, files in os.walk(R):
    dirs[:]=[d for d in dirs if d not in IGN]
    for nome in files:
        p=Path(base)/nome; rel=p.relative_to(R).as_posix()
        if rel.startswith('registros/organizacao_repositorio/'): continue
        n=p.stat().st_size; arquivos.append({'caminho':rel,'bytes':n}); g=rel.split('/')[0]; grupos[g][0]+=1;grupos[g][1]+=n
        if p.suffix.lower() in {'.json','.md','.py','.ps1','.sh','.ts','.tsx','.mjs','.toml','.yaml','.yml'} and n<15_000_000:
            try: textos[rel]=p.read_text(encoding='utf-8-sig')
            except (UnicodeError,OSError):pass
        if len(arquivos)%10000==0: print('ARQUIVOS',len(arquivos),flush=True)
print('INVENTARIO',len(arquivos),'TEXTOS',len(textos),flush=True)
existentes={a['caminho'] for a in arquivos}
def registrar(valor,fonte):
    if isinstance(valor,dict):
        for k,v in valor.items():
            if isinstance(v,str) and re.fullmatch('[a-fA-F0-9]{64}',v):
                for c in [k.replace('\\','/'),(Path(fonte).parent/k).as_posix()]:
                    if c in existentes:protegidos[c].add(fonte)
            registrar(v,fonte)
    elif isinstance(valor,list):
        for v in valor:registrar(v,fonte)
for rel,t in textos.items():
    if rel.endswith('.json'):
        try:registrar(json.loads(t),rel)
        except (ValueError,RecursionError):pass
print('HASHES_REFERENCIADOS',len(protegidos),flush=True)
for rel,t in textos.items():
    if rel.endswith('.py') and rel.split('/')[0] not in {'arquivo','dados','registros'}:
        try:
            arv=ast.parse(t); imports=[]
            for n in ast.walk(arv):
                if isinstance(n,ast.Import):imports.extend(a.name for a in n.names)
                elif isinstance(n,ast.ImportFrom) and n.module:imports.append(n.module)
            py[rel]={'linhas':len(t.splitlines()),'imports':imports,'doc':ast.get_docstring(arv),'protegido':rel in protegidos}
        except SyntaxError:py[rel]={'erro_ast':True}
for rel,info in py.items():
    modulo=rel.removesuffix('.py').replace('/','.')
    if modulo.endswith('.__init__'):modulo=modulo.removesuffix('.__init__')
    info['importado_por']=[p for p,i in py.items() if p!=rel and modulo in i.get('imports',[])]
    info['referencias_textuais']=[p for p,t in textos.items() if p!=rel and rel in t][:25]
docs={rel:{'protegido':rel in protegidos,'referencias':[p for p,t in textos.items() if p!=rel and rel in t][:15]} for rel in textos if rel.startswith('docs/') and rel.endswith('.md')}
resultado={'utc':datetime.now(timezone.utc).isoformat(),'arquivos':arquivos,'grupos':dict(grupos),'protegidos':{p:sorted(v) for p,v in protegidos.items()},'python':py,'documentos':docs}
(D/'inventario_antes.json').write_text(json.dumps(resultado,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('GRUPOS',json.dumps(dict(grupos)),flush=True)
print('PYTHON_NAO_PROTEGIDO',json.dumps({p:i for p,i in py.items() if not i.get('protegido')},ensure_ascii=False),flush=True)
print('DOCS_NAO_PROTEGIDOS',json.dumps({p:i for p,i in docs.items() if not i['protegido']},ensure_ascii=False),flush=True)
