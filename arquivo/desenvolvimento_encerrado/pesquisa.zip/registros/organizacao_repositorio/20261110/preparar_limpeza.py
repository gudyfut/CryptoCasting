import hashlib,json,os,subprocess
from pathlib import Path
from datetime import datetime,timezone
from zipfile import ZipFile,ZIP_DEFLATED
R=Path(__file__).resolve().parents[3];D=Path(__file__).parent
plano=json.loads((D/'plano.json').read_bytes()); inv=json.loads((D/'inventario_antes.json').read_bytes())
fixos=set(plano['fixos_execucao_interface']); protegidos=set(inv['protegidos'])
A=R/'arquivo/desenvolvimento_encerrado';A.mkdir(parents=True,exist_ok=True)
assert not (A/'indice.json').exists(), 'Nao sobrescrever migracao anterior'
h=lambda b:hashlib.sha256(b).hexdigest()
editoriais=['README.md','AGENTS.md','docs/README.md','manutencao/README.md','docs/armazenamento_e_reproducao.md','registros/README.md']
assert not set(editoriais)&fixos
arquivar=set(plano['arquivar'])
arquivar.update(p.relative_to(R).as_posix() for p in D.glob('*.py'))
originais=arquivar|set(plano['mover'])
assert not originais&fixos
entradas={}; acoes=[]
with ZipFile(A/'fontes.zip','x',compression=ZIP_DEFLATED,compresslevel=9) as z:
 for nome in sorted(originais):
  p=(R/nome).resolve(); assert p.is_relative_to(R) and p.is_file()
  dados=p.read_bytes();z.writestr(nome,dados)
  e={'sha256':h(dados),'bytes':len(dados),'membro':nome,'tipo':'zip'}
  if nome in plano['mover']:
   e.update(tipo='movido',destino=plano['mover'][nome])
  entradas[nome]=e
  acoes.append({'origem':nome,'sha256':e['sha256'],'acao':'mover' if nome in plano['mover'] else 'arquivar','destino':plano['mover'].get(nome)})
 for nome in editoriais:z.writestr('editoriais_antes/'+nome,(R/nome).read_bytes())
with ZipFile(A/'fontes.zip') as z:
 assert z.testzip() is None
 for nome,e in entradas.items():assert h(z.read(nome))==e['sha256']
indice={'versao':1,'utc':datetime.now(timezone.utc).isoformat(),'natureza':'Fontes encerradas e versoes editoriais anteriores; resultados, modelos, dados e logs permanecem nos caminhos cientificos. Hashes originais nao foram reescritos.',
 'pacote':'arquivo/desenvolvimento_encerrado/fontes.zip','pacote_sha256':h((A/'fontes.zip').read_bytes()),'entradas':entradas,
 'editoriais_antes':{p:{'membro':'editoriais_antes/'+p,'sha256':h((R/p).read_bytes())} for p in editoriais}}
(A/'indice.json').write_text(json.dumps(indice,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rastreado=set(subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0'))
caches=[];pastas=[]
ignorar={'.git','.venv','.venv_wsl','node_modules'}
for base,dirs,files in os.walk(R):
 dirs[:]=[d for d in dirs if d not in ignorar]
 b=Path(base);rel=b.relative_to(R).as_posix()
 regeneravel='__pycache__' in b.parts or rel=='dataview/.next' or rel.startswith('dataview/.next/') or any(n in b.parts for n in ['.pytest_cache','.mypy_cache','.ruff_cache'])
 if not regeneravel:continue
 if not b.resolve().is_relative_to(R):continue
 pastas.append(rel)
 for n in files:
  p=b/n;q=p.relative_to(R).as_posix()
  if q in protegidos or q in fixos or q in rastreado:continue
  if p.resolve().is_relative_to(R):caches.append({'origem':q,'bytes':p.stat().st_size,'sha256':h(p.read_bytes())})
saida={'raiz':str(R),'pacote':indice['pacote'],'pacote_sha256':indice['pacote_sha256'],'acoes':acoes,'caches':caches,'pastas_caches':sorted(pastas,key=len,reverse=True),'fixos':sorted(fixos),'protegidos_caches':sorted(protegidos)}
(D/'acoes.json').write_text(json.dumps(saida,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'arquivados':len(arquivar),'movidos':len(plano['mover']),'pacote_bytes':(A/'fontes.zip').stat().st_size,'caches':len(caches),'bytes_caches':sum(x['bytes'] for x in caches)},ensure_ascii=False),flush=True)
