# Panorama interativo do TCC

Interface de apresentação da trajetória experimental, com 14 etapas do estudo OHLCV com alvo de 24h, até 03/11/2026. A página inicial organiza perguntas, alterações, controles, resultados e limites; cada etapa abre gráficos, exemplos reais e suas fontes. O modo **Apresentar** usa as setas ←/→ para percorrer as etapas e Esc para sair. **Método de avaliação** explica o método; **Síntese dos resultados** reúne a síntese e permite imprimir/salvar em PDF.

## Executar

Executar npm neste diretório:

```sh
npm run dev -- --hostname 127.0.0.1
```

Abrir http://127.0.0.1:3000. Para a versão de produção: `npm run build` e `npm start -- --hostname 127.0.0.1`. A interface requer o repositório e os artefatos locais; não foi publicada em serviço externo.

## Dados e rastreabilidade

`scripts/exportar_panorama.py` exporta resultados existentes. Executado a partir da raiz do repositório, requer Python, pandas, NumPy e o leitor Parquet já disponíveis no ambiente científico:

```sh
python dataview/scripts/exportar_panorama.py
```

Ele confere manifestos, hashes das previsões e históricos de épocas, alinhamento de 24h, preço/alvo e o MSE de todas as origens horárias. Não importa treinadores e não inicia treinamento, inferência ou backtest. Escreve apenas o snapshot da apresentação (`src/data/panorama.json`), as séries em `dados/portal_panorama/series/` e o recibo em `registros/interface/panorama_20261103/exportacao.json`.

O snapshot atual reúne 205 séries de previsões salvas. O explorador mostra uma origem diária às 00h UTC para facilitar a leitura; as métricas publicadas usam a população horária completa. O gráfico liga previsões terminais independentes, sem representar uma trajetória prevista dentro do dia. O CSV contém os exemplos diários da série selecionada. O primeiro exemplo usa a seed 42 por convenção, sem seleção por resultado.

O servidor confere a disponibilidade e a integridade das fontes originais. Os endpoints `/api/panorama/serie` e `/api/panorama/fonte` aceitam somente identidades e caminhos da exportação e verificam SHA-256 antes da entrega. Ausência local recebe aviso explícito; nunca gera resultado artificial. Para usar em outra máquina, preservar/restaurar as fontes e as séries conforme a política de armazenamento do projeto.

A fase exploratória aparece apenas em uma nota de contexto: não integra a navegação, a contagem ou o cronograma. A reprodução de checkpoints públicos do CryptoMamba, com outro desenho de avaliação, também fica fora dessa sequência. Os artefatos históricos permanecem preservados. Resultados de quatro blocos têm peso igual entre blocos e seeds; os controles reais não entram nas médias. Carteiras são independentes por bloco. A interface apresenta as incertezas e correções publicadas, distingue validação/teste e não promove variantes por lucro ou por um exemplo favorável.

## Verificação

```sh
npm test
node --test tests/panorama.integration.mjs
npm run build
```

O teste de integração exige o servidor ativo em `http://127.0.0.1:3000`. Os testes do panorama verificam as 205 séries, pareamento de oito seeds e quatro blocos, agregação das médias, incerteza, custos, integridade e entrega pela API. A revisão visual inclui desktop/celular, filtros, datas, gráficos, exportação CSV e apresentação.

A interface anterior foi substituída na navegação. Os componentes e endpoints históricos permanecem sem uso pela página nova, preservando os artefatos e testes anteriores. O aceite antigo está em `registros/interface/aceite_final.json`; a evidência desta entrega fica em `registros/interface/panorama_20261103/`.
