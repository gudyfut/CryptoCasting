# Ferramentas de manutenção e histórico

Esta pasta reúne utilitários de auditoria, análise posterior e operações históricas. **Não é uma fila de comandos para executar todos.** Os lançadores ativos ficam na raiz ou em `experimentos/`; consultar o protocolo/estado correspondente antes de qualquer execução.

| Grupo | Exemplos | Uso e cuidado |
|---|---|---|
| Inventário e integridade | `auditar_catalogo.py`, `verificar_inventario.py`, `verificar_contratos.py` | Leitura/conferência; falta local não significa treino inexistente |
| Publicações e fechamentos | `auditar_publicacao.py`, `verificar_fechamento.py`, `conferir_fechamento_*` | Evidências de ciclos específicos; não repetir executor para reconstruir recibos |
| Consolidações e diagnósticos | `consolidar_*`, `analisar_*_concluido.py`, `diagnosticar_*`, `conferir_giro_sinais.py` | Métodos posteriores identificados; não sobrescrever publicações encerradas |
| Figuras | `figuras_*` | Apresentação de dados preservados; executar só quando o protocolo permite |
| Manutenção operacional histórica | `retomar_*`, `verificar_retomada_penalizacao.py`, `registrar_aceite.py`, `arquivar_estudo.ps1` | Procedimentos ligados a incidentes/autorização; **não são retomada genérica nem autorização atual** |
| Portal | `exportar_portal.py` | Exportação de leitura; verificar a geração de estudo exibida |

Scripts aparentemente temporários podem integrar checksums ou explicar incidentes no TCC. Permanecem nos caminhos originais. Antes de remover qualquer arquivo, conferir vínculos em `registros/`, fontes congeladas e histórico; arquivos não rastreados pelo Git também podem ser trabalho científico válido.

O recibo da limpeza de 04/11/2026 está em `registros/organizacao_futuros_001/limpeza.json`: somente caches Python regeneráveis foram removidos. A nova simulação usa `simulacao_operacoes/` e `experimentos/futuros/`; não acrescentar aqui um executor concorrente ou um script avulso para contornar a grade.
