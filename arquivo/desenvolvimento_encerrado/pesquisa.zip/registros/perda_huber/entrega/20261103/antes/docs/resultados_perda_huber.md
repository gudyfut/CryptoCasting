# Mamba16: MSE versus perda Huber

Execução `ed8e55ff978b2742c200`: seis novos ajustes,53referências herdadas e54carteiras Smart secundárias. [Protocolo](protocolo_perda_huber.md), [estado](../registros/perda_huber/estado.json).

## Comparação preditiva

Médias aritméticas de métricas de modelos individuais, não ensemble. A referência é Mamba16/AdamW/MSE com taxa constante0,0002. Dados, arquitetura, otimizador, taxa e critério de parada iguais; somente a perda de treinamento mudou para 2×Huber(delta1 padronizado). Seleção de checkpoint e primário continuam MSE global de validação em retorno real.

| Parte | Modelo | Seeds | MSE | RMSE×100 | MAE×100 | Habilidade Naive |
|---|---|---:|---:|---:|---:|---:|
| validacao | huber_seis | 6 | 0.0007163599 | 2.6765 | 1.9430 | +0.762% |
| validacao | mamba16_seis | 6 | 0.0007198378 | 2.6830 | 1.9493 | +0.280% |
| validacao | huber_tres | 3 | 0.0007168863 | 2.6775 | 1.9442 | +0.689% |
| validacao | mamba16_tres | 3 | 0.0007191640 | 2.6817 | 1.9477 | +0.374% |
| validacao | lstm_tres | 3 | 0.0007194461 | 2.6822 | 1.9477 | +0.335% |
| validacao | naive | 1 | 0.0007218625 | 2.6867 | 1.9523 | +0.000% |
| validacao | arima | 1 | 0.0007215880 | 2.6862 | 1.9515 | +0.038% |
| teste | huber_seis | 6 | 0.0004962804 | 2.2277 | 1.5877 | -0.214% |
| teste | mamba16_seis | 6 | 0.0004965701 | 2.2284 | 1.5894 | -0.272% |
| teste | huber_tres | 3 | 0.0004978543 | 2.2313 | 1.5900 | -0.532% |
| teste | mamba16_tres | 3 | 0.0004958901 | 2.2268 | 1.5889 | -0.135% |
| teste | lstm_tres | 3 | 0.0004980096 | 2.2316 | 1.5931 | -0.563% |
| teste | naive | 1 | 0.0004952210 | 2.2254 | 1.5864 | +0.000% |
| teste | arima | 1 | 0.0004946217 | 2.2240 | 1.5854 | +0.121% |

## Critério primário e incerteza

| Parte | Diferença MSE huber−constante | IC95%14dias |
|---|---:|---|
| validacao | -3.477886442e-06 | [-7.220174278099466e-06, 2.932450502246494e-08] |
| teste | -2.896994945e-07 | [-2.112910415560167e-06, 1.7580494209874611e-06] |

O critério primário não foi atendido: não há evidência suficiente pelo critério fixado para substituir a referência.
Não selecionar variante/seed/época pelo teste ou pelo lucro. A taxa permaneceu constante. Huber muda a estimativa favorecida pela perda e a dinâmica de gradientes; melhorar MAE ou lucro e piorar MSE é um compromisso, não vitória no critério principal.

## Todas as seeds e diagnóstico diário

| Seed | MSE validação | MSE teste | P95 erro×100 | Vitórias vs Naive | Spearman00UTC | Smart base teste |
|---|---:|---:|---:|---:|---:|---:|
| 17 | 0.0007161683 | 0.0004953111 | 4.3719 | 48.35% | 0.0308 | -8.40% |
| 42 | 0.0007168363 | 0.0004982363 | 4.4755 | 47.25% | 0.0605 | -9.05% |
| 2026 | 0.0007176542 | 0.0005000157 | 4.5206 | 46.15% | 0.0835 | -8.94% |
| 7 | 0.0007155621 | 0.0004967239 | 4.4422 | 47.80% | 0.0129 | -9.48% |
| 123 | 0.0007161640 | 0.0004951513 | 4.3968 | 46.70% | 0.1115 | -7.26% |
| 31415 | 0.0007157743 | 0.0004922439 | 4.3875 | 49.45% | 0.0364 | -8.77% |

## Carteira Smart: média de seis modelos

| Parte | Custos | Política | Retorno | Queda máxima média | Exposição |
|---|---|---|---:|---:|
| validacao | ideal | smart | +97.85% | 31.64% | 89.48% |
| validacao | base | smart | +96.37% | 31.68% | 89.48% |
| validacao | agravado | smart | +94.92% | 31.71% | 89.48% |
| teste | ideal | smart | -8.27% | 35.80% | 96.44% |
| teste | ideal | smart_constante | -9.20% | 35.81% | 96.26% |
| teste | base | smart | -8.65% | 35.80% | 96.44% |
| teste | base | smart_constante | -9.47% | 35.81% | 96.26% |
| teste | agravado | smart | -9.02% | 35.81% | 96.44% |
| teste | agravado | smart_constante | -9.74% | 35.82% | 96.26% |

Comparar com o [backtest anterior](resultados_backtest_carteira.md), no mesmo calendário e regras. Smart2% não é stop. Os resultados SpotR0, com contabilidade histórica própria, estão na publicação estruturada e não substituem as carteiras retidas.

## Evidências e limitações

Taxa constante, contrato da perda e seleção/parada por MSE foram conferidos, assim como métricas e lançamentos das54carteiras. Recarga exata e capacidade20.257 verificadas; nenhum resultado anterior foi sobrescrito. MSE de todas as origens horárias não é o MSE do subconjunto00UTC. Vitórias contra Naive são de erro absoluto, não acerto direcional. Os diagnósticos descritivos não alteram o primário: [diagnóstico das previsões anteriores](diagnostico_previsoes.md). Resultados por trimestre, faixas causais de previsão, correlações e erros estão na publicação.

2024 participou da seleção de checkpoints;2025 já foi consultado. Estudo exploratório retrospectivo, sem novo holdout ou walk-forward. Mais seeds não eliminam seleção adaptativa. Sem garantia de lucro/fills reais/backup externo; nenhuma promoção ou hipótese seguinte é automática. [Registros e publicação](../registros/perda_huber/estado.json).
