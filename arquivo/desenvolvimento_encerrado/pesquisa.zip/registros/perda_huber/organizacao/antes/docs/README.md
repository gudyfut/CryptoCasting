# Documentação do CryptoCasting

## Comece aqui

1. [TCC1](TCC_1_MuriloRFM.pdf): objetivo e fundamentação originais; PDF preservado.
2. [Desenho OHLCV](desenho_ohlcv24.md): método de dados, alvo e referência; as preparações históricas não substituem os estados das rodadas executadas.
3. [Plano](../plano.md), [cronologia única](andamento.md) e [catálogo](../registros/catalogo_estudos.json).
4. [Roteiro de redação](roteiro_redacao_tcc.md): como transformar decisões e evidências no artigo.

## Rodada atual

**Mamba16: taxa constante versus redução automática, encerrada e conferida**, seis seeds: [protocolo](protocolo_taxa_dinamica.md), [ADR0017](adr/0017-taxa-dinamica-mamba16.md), [estado](../registros/taxa_dinamica/estado.json), [resultados](resultados_taxa_dinamica.md). A referência constante 0,0002 foi mantida. O arquivo de estado liga identidade, qualificação, autorização, progresso, processo e publicação. A próxima hipótese recomendada de perda Huber está somente proposta no [plano](../plano.md), sem execução nova.

O [diagnóstico das previsões existentes](diagnostico_previsoes.md) acrescenta distribuição dos erros, associação com retornos e faixas fixadas na validação, sem novos ajustes. Correlação e lucro são avaliações distintas de MSE.

## Arquitetura e manutenção

| Etapa | Documento | Evidências |
|---|---|---|
| Mercado e entradas | [Arquitetura dos dados](arquitetura_dados.md) | [Estado](../registros/dados/estado.json) |
| Consumo pelos modelos | [Arquitetura dos modelos](arquitetura_modelos.md) | [Estado](../registros/modelos/estado.json) |
| Treino, seleção e checkpoints | [Arquitetura de treinamento](arquitetura_treinamento.md) | [Referência executada](../registros/treinamento/estado.json) |
| Novas hipóteses | [Registro de experimentos](registro_de_experimentos.md) | [Mapa de registros](../registros/README.md) |
| Decisões e transporte | [ADRs](adr/README.md), [preservação](armazenamento_e_reproducao.md) | Catálogo e recibos por ciclo |

Novas hipóteses ficam em `experimentos/`; diagnósticos reutilizáveis em `analises/`. As camadas científicas antigas e pacotes `experimento_*/` permanecem congelados nos caminhos originais. Refinamentos do desenho não exigem recoleta automática de mercado.

## Estudos encerrados

| Estudo | Protocolo | Resultado |
|---|---|---|
| Referência modular OHLCV | [Desenho](desenho_ohlcv24.md) | [Estado/publicação](../registros/treinamento/estado.json) |
| Estado16→8 | [Método](protocolo_estado_mamba.md) | [Relatório](resultados_estado_mamba.md) |
| Estados32/64 e complemento16 | [32/64](protocolo_estados32_64.md), [complemento](protocolo_complemento_estado16.md) | [Quatro estados/seis seeds](resultados_estados32_64.md) |
| Taxa constante menor | [Método](protocolo_taxa_aprendizado.md) | [Relatório](resultados_taxa_aprendizado.md) |
| Taxa dinâmica Mamba16 | [Método](protocolo_taxa_dinamica.md) | [Relatório e conferência posterior](resultados_taxa_dinamica.md) |
| Carteira retida | [Método](protocolo_backtest_carteira.md) | [Relatório](resultados_backtest_carteira.md) |
| CryptoMamba adaptado | [Método](protocolo_cryptomamba_adaptado.md) | [Relatório](resultados_cryptomamba_adaptado.md) |
| Adam→AdamW nessa adaptação | [Método](protocolo_otimizador_cryptomamba.md) | [Relatório](resultados_otimizador_cryptomamba.md) |

A linha CryptoMamba foi encerrada após a solicitação de voltar ao Mamba temporal; seus resultados não são apagados ou confundidos com o Mamba16. A preparação `92e3eb82e3f6adf99994` em `estudo_ohlcv/` permanece sem treino; a referência modular e as extensões possuem identidades próprias, já executadas.

## Histórico e disciplina documental

[Estudos preliminares até28/10](../arquivo/estudos_preliminares_2026-10-28/README.md) ligam a fase de retornos escalares, penalização, pré-normalização e barreiras. Os protocolos congelados `protocolo_experimental.md`, `protocolo_penalizacao_mamba.md` e `protocolo_normalizacao_mamba.md` permanecem aqui por integridade; não definem automaticamente o próximo ciclo. O [cronograma acadêmico](../arquivo/estudo_barreiras_2026-10-20/projeto/docs/Cronograma_Atividades_TCC2_Murilo_Monferrari.pdf) não comprova aceite do orientador.

Não produzir explicações avulsas a cada conversa. Método no desenho/protocolo; decisões nas ADRs; fatos em `andamento.md`; evidências técnicas em `registros/`; resultados por tentativa. Preservar versões editoriais vinculadas aos fechamentos antes de consolidá-las. Não mover artefatos congelados para reduzir contagem de pastas. O portal existente ainda pertence ao estudo preliminar.
