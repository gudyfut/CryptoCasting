# Plano de trabalho

Atualizado em06/11/2026. Etapa autorizada: **comparar alvo de retorno simples diário com alvo de preço**, mantendo o restante da receita. [Protocolo](docs/protocolo_alvo_retorno_diario.md), [ADR0033](docs/adr/0033-alvo-retorno-diario.md), [estado verificável](registros/alvo_retorno_diario/estado.json).

## Rodada

- Referência de preço preservada: `ac8183e1ecfb91102b48`. Nenhum novo treinamento dessa versão.
- Mesmo BTCUSDT/BinanceUSD-M, treino2020–2023, validação2024, teste2025 retrospectivo; entradas timestamp+OHLCV,14dias, sem scaler novo.
- Alvo retorno simples decimal; RMSE por lote e seleção global em retorno. Preço equivalente calculado pelo último fechamento conhecido para o mesmo simulador.
- Mesma arquitetura64/3×4 e backend reproduzível, Adam0,01, decay0,001, StepLR100/0,5, lote32,1.000épocas.
- Quatro ajustes:42principal,42controle,17,2026; controle fora das médias. Teste e70carteiras somente após controle/treinos.
- Política24h/custos/funding/cenários idênticos. Comparação pareada nas mesmas seeds/origens, métricas comuns de retorno e preço; ensemble separado.

## Qualificação e leitura posterior

23testes aprovados,60repetições de gradientes/saídas exatas e dois ajustes artificiais de50épocas exatos. Dados reais e preservação conferidos; identidade `1dbfa7ae982c8060367d` congelada e treino real confirmado em06/11 às04:18 de Brasília. Consultar estado/progresso para conclusão; controle real ainda será executado.

Após concluir, conferir cobertura, integridade, contraste e contabilidade. Discutir previsão, viés, estabilidade, retorno/drawdown e custos. Não selecionar seed ou política favorável retrospectivamente. Nenhuma busca de outros hiperparâmetros autorizada.

A rodada anterior concluiu sem lucro robusto; a [cronologia](docs/andamento.md) guarda análise e evidências.2024–2025já consultados; esta comparação não cria novo holdout intocado.
