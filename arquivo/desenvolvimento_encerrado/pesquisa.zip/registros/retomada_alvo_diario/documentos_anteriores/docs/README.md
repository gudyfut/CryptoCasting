# Documentação do CryptoCasting

## Leitura principal

**[Exploração do processo de melhoria de modelos com IA](exploracao_ia.md)** reúne toda a fase Astra posterior ao panorama web de 03/11: propósito, evolução, resultados, limitações e requisitos para a próxima etapa. É a síntese única dessa fase; protocolos e relatórios por ciclo são anexos científicos preservados.

[Plano atual](../plano.md) · [Cronologia única](andamento.md) · [Catálogo](../registros/catalogo_estudos.json) · [Mapa dos registros](../registros/README.md).

## Base acadêmica e arquitetura

| Assunto | Documento |
|---|---|
| Proposta original e redação | [TCC1](TCC_1_MuriloRFM.pdf), [roteiro para o artigo](roteiro_redacao_tcc.md) |
| Referência OHLCV anterior | [Desenho](desenho_ohlcv24.md), [panorama web até 03/11](../dataview/README.md) |
| Dados e entradas | [Arquitetura dos dados](arquitetura_dados.md) |
| Contratos dos modelos | [Arquitetura dos modelos](arquitetura_modelos.md) |
| Treino e seleção | [Arquitetura do treinamento](arquitetura_treinamento.md) |
| Simulação de operações | [Arquitetura operacional](arquitetura_operacoes.md) |
| Registro e decisões | [Procedimento](registro_de_experimentos.md), [ADRs](adr/README.md) |
| Transporte e reprodução | [Política de preservação](armazenamento_e_reproducao.md) |

## Estudos encerrados e anexos

Os anexos da fase Astra estão indexados ao final da [síntese](exploracao_ia.md#8-onde-as-evidências-ficaram). Para localizar hipóteses anteriores de estados, taxa, otimizador, Huber e entradas, usar o [catálogo de estudos](../registros/catalogo_estudos.json) e o [panorama](../dataview/README.md). Os [estudos preliminares](../arquivo/estudos_preliminares_2026-10-28/README.md) preservam os desenhos antigos de retorno escalar e barreiras.

Os arquivos `protocolo_*.md`, `resultados_*.md`, `desenho_operacional_futuros.md` e `diagnostico_operacional.md` documentam identidades específicas. Sua presença nesta pasta não os torna desenhos atuais. Permanecem nos caminhos originais porque fontes, fechamentos, testes e leitores podem depender deles. Não criar um novo índice ou relatório por conversa; acrescentar informação à função documental pertinente.

A etapa vigente é [alvo de retorno diário versus preço](protocolo_alvo_retorno_diario.md), com [estado próprio](../registros/alvo_retorno_diario/estado.json). A referência de preço reproduzível está concluída, e todos os estudos anteriores permanecem preservados.
