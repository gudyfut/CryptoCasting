# Orientações para trabalhar no CryptoCasting

## Leitura inicial e estado atual

1. Ler `docs/exploracao_ia.md`: síntese única da fase exploratória com Astra posterior ao panorama web de 03/11/2026.
2. Consultar `plano.md`, `registros/catalogo_estudos.json` e o estado/ponteiro do ciclo pertinente. Documentação não substitui evidência do computador executor.
3. Para implementar, ler a arquitetura da camada afetada em `docs/arquitetura_*.md`; para preservar/transferir, `docs/armazenamento_e_reproducao.md`.
4. Decisões históricas e seus limites estão em `docs/adr/`; protocolos, fontes e orçamentos encerrados não são instruções atuais de execução.

A reexecução `ac8183e1ecfb91102b48` foi concluída e conferida em06/11/2026 (4ajustes, controle exato,70carteiras). A autorização desta rodada terminou. Não repetir o executor; análises posteriores usam recibos próprios. Nova hipótese de alvo diário requer escopo/autorização novos.

A exploração Astra e o contraste acumulado/12meses estão encerrados e preservados. A referência vigente autorizada é a reexecução técnica CryptoMamba diário/futuros24h (ADR0032): `docs/protocolo_cryptomamba_reproducivel.md`, `experimentos/cryptomamba_reproducivel/`, `registros/cryptomamba_reproducivel/estado.json`. A tentativa ADR0031 `6de6464912e674da1540` falhou no controle de reprodução e permanece preservada, sem retomada. A nova autorização inclui reinício das3seeds+1controle,1000épocas cada e70carteiras; sem busca adicional. Mesmos dados/receita e tolerâncias; Mamba-1 oficial com scan de referência oficial em CUDA explicitamente configurado, sem kernel fused, bibliotecas compartilhadas inalteradas. Essa exceção explícita de execução numérica não autoriza fallback silencioso. Verificar identidade/PID/lock antes de agir; falha interrompe. Fontes, dados, protocolo e resultados anteriores são imutáveis. A autorização termina nesta reexecução; novas variações dependem de novo escopo.

## Objetivo e honestidade científica

Prioridade atual do pesquisador: desenvolver Mamba + política operacional de futuros cripto, permitindo compras e vendas, buscando lucro líquido positivo, risco e estabilidade explícitos. Um ciclo negativo informa a próxima hipótese e não encerra automaticamente a pesquisa. Podemos propor alterações de entradas, alvo, candles, contexto, treinamento, arquitetura e política em etapas identificadas. Não garantir lucro, tratar busca finita como exaustiva ou escolher resultados favoráveis descartando os demais.

A proposta acadêmica original está em `docs/TCC_1_MuriloRFM.pdf`: OHLCV/indicadores, investigação iterativa e avaliação temporal. Objetivos e conclusões dos estudos anteriores permanecem históricos; a nova prioridade não os reescreve. Não presumir aprovação acadêmica de mudanças. LSTM, ARIMA e Naive são referências; definir sua participação por ciclo.

## Arquitetura e caminhos

- `mercado_binance/`: coleta, proveniência, validação e candles; `mercado_futuros/`: observações públicas de futuros. Não misturar escolha de entrada com coleta.
- `entradas_modelo/`: canais causais, alvos, contextos, divisões, purga e escalas. Mudar entradas não exige recoleta automaticamente.
- `modelos/`: contratos Mamba/LSTM, Naive e ARIMA. Dimensões das redes derivadas das entradas; ARIMA é univariado com histórico permitido próprio.
- `treinamento/` e `avaliacao/`: seleção, checkpoints e métricas. Consultar arquitetura e identidade antes de usar; versões científicas encerradas podem estar congeladas.
- `simulacao_operacoes/`: sinais, políticas e contabilidade separados; preços futuros/alvos observados nunca entram na decisão.
- `experimentos/`: novos ciclos com namespace próprio; `analises/`: leituras posteriores reutilizáveis, sem reabrir treinamento.
- `configuracoes/`: receitas; `registros/`: índices/evidências; `dados/experimentos/`: tentativas e publicações; `dados/diagnosticos/`: análises posteriores.
- `arquivo/` e pacotes antigos `experimento_*/`, `previsao24/`, `estudo_ohlcv/`: histórico preservado. Não mover ou importar indiscriminadamente para um novo desenho.
- `dataview/`: panorama Next.js do estudo até 03/11. Executar npm nesse diretório; não apresentar resultados exploratórios posteriores como se estivessem na interface.

## Regras permanentes de execução

- Separar proposta, autorização, qualificação, identidade congelada, execução e auditoria. Cada ciclo exige escopo/orçamento identificados; autorização explícita já dada não exige confirmação redundante. Tetos não são metas de consumo.
- Antes de treinar, conferir ambiente/hardware, contratos/dimensões, forward/backward, atualização, reprodução e recarga. Mamba oficial CUDA; nenhum fallback silencioso ou computação paga não autorizada.
- Antes de iniciar/retomar, conferir host, PID Linux/Windows, lock, logs e progresso. Nunca duplicar processo vivo, inferir encerramento por timeout ou treinar para compensar artefatos ausentes em outra máquina.
- Selecionar checkpoints pelo critério definido na validação, não pelo teste. Qualificar controles antes da grade quando exigido; excluir controles das médias. Preservar seeds e pareamentos definidos no ciclo.
- Não chamar executor encerrado para regenerar relatórios. Usar leitura posterior identificada, com recibo próprio. Falhas e retomadas exigem diagnóstico e respeito ao protocolo específico; não repetir automaticamente.
- Fontes, configurações, protocolos, recibos e artefatos congelados são imutáveis sob sua identidade. Não regenerar hashes para aceitar divergências ou normalizar finais de linha em massa.
- Não enviar ordens reais. Autorizações de simulação não autorizam uso de conta, alavancagem real ou gastos.

## Dados, métricas e busca assistida por IA

- Ajustar scalers só no treino. Preservar causalidade, candles completos, unidades temporais, origens comuns, purga compatível com a realização do alvo e proveniência. Não interpolar lacunas ou selecionar exemplos pelo retorno futuro.
- Distinguir OHLCV coletado de canais efetivos, saída normalizada de retorno real, retorno terminal de payoff por lado, score de probabilidade e contexto de previsão de histórico de treino.
- Uma divisão fixa não é walk-forward. Reestimação por bloco usa somente passado permitido. Não aplicar checkpoint treinado no futuro a períodos anteriores.
- 2023 foi desenvolvimento adaptativo; 2024–2025 já foram consultados. Não alegar holdout intocado ao reutilizá-los. Verificar exposição específica de 2026 antes de reservar dados desse ano.
- Manter avaliador e proponente separados. Feedback deve mostrar sinal, suporte, regime, risco, custos e motivos de rejeição, não apenas retorno agregado. Não alimentar confirmação reservada ao processo de seleção.
- Identificar ablação de um fator versus comparação de receitas completas. Comparações exigem população/executor equivalentes ou diferenças declaradas. Histórico herdado não conta como novos treinos.
- Seeds e previsões horárias sobrepostas não são novos mercados independentes. Não somar retornos de carteiras independentes. Não inferir utilidade operacional de MSE isolado.
- Cortes descobertos nos diagnósticos são exploratórios; não promover filtros por lucro posterior. Permitir os dois lados não exige forçar atividade em todo regime.
- Lucro, drawdown, exposição, custos/funding e estabilidade são eixos distintos. Convenções de backtest não certificam execução, liquidação ou tarifas históricas Binance. Corrigir contabilidade e testar política são mudanças diferentes.

## Documentação e limpeza

- **Não criar um documento por interação.** Explicações ficam no chat. Esta fase usa `docs/exploracao_ia.md` como síntese; evoluir o documento pertinente antes de criar outro.
- `docs/README.md` é navegação, `plano.md` é próximo passo, `docs/andamento.md` é a cronologia única, `registros/catalogo_estudos.json` é o índice estruturado. Não repetir placares nesses guias.
- ADR somente para decisão material; protocolo/configuração para execução distinta; registros técnicos/logs/testes nas execuções. Não produzir versões concorrentes de síntese ou cópias de resultados sem função científica.
- Preservar antes de editar documentos vinculados a fechamentos. Não editar o PDF acadêmico compilado. Artefato ignorado pelo Git não está apagado nem protegido remotamente.
- Limpeza pode excluir caches/builds/temporários comprovadamente regeneráveis e conteúdo editorial redundante. Não apagar checkpoints, previsões, dados, incidentes, controles ou fontes porque o resultado foi ruim ou o arquivo foi gerado pelo Codex.
- Conferir dependências/hashes antes de excluir ou mover. Protocolos/relatórios encerrados mantidos por hash são anexos científicos, não desenhos vigentes. Não reescrever o histórico Git.
- Após manutenção, conferir vínculos, catálogo e integridade pertinente; relatar alcance e limitações. Fonte operacional: `python manutencao/auditar_catalogo.py --integridade --exigir-completo` no computador com os artefatos.
- Identificadores novos em português; manter nomes oficiais dos argumentos das APIs.
