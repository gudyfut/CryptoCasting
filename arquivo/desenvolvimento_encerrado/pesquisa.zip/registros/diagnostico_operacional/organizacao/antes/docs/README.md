# Documentação do CryptoCasting

## Comece aqui

1. [TCC1](TCC_1_MuriloRFM.pdf): objetivo e fundamentação originais; PDF preservado.
2. [Desenho OHLCV](desenho_ohlcv24.md): método da linha acadêmica anterior. [Desenho operacional em futuros](desenho_operacional_futuros.md): método da busca conjunta autorizada de modelo/política, com identidade própria e preservação anterior.
3. [Plano](../plano.md), [cronologia única](andamento.md) e [catálogo](../registros/catalogo_estudos.json).
4. [Roteiro de redação](roteiro_redacao_tcc.md): como transformar decisões e evidências no artigo.

## Etapa atual e ciclos encerrados

**Pesquisa operacional em futuros encerrada e auditada, sem finalista (ADR0028).** [Resultados e gráfico](resultados_operacional_futuros.md), [desenho congelado](desenho_operacional_futuros.md), [estado](../registros/operacional_futuros/estado.json), [qualificação integrada](../registros/operacional_futuros/qualificacao_integrada/qualificacao_final.json). Execução `f0dd11f393b5e26edaf8`: oito receitas, 74 ajustes incluindo controles, 1.260 carteiras. C05 perdeu nas três seeds do único recorte ativo; reforço com oito seeds e avaliação final não acionados. Os ciclos anteriores conservam seus próprios critérios.

**Busca Astra002 encerrada sem finalista:**12configurações e100ajustes concluídos/conferidos. Nenhuma candidata cumpriu os critérios após reforço com três seeds. Zero treinos finais e zero novas carteiras; referências anteriores preservadas. [Resultados e evidências](resultados_busca_astra_002.md).

**F03 — Revisão operacional concluída e conferida:** 1.200 carteiras, zero treino. [Resultado da auditoria e comparação](resultados_revisao_operacional.md), [protocolo](protocolo_revisao_operacional.md), [estado](../registros/revisao_operacional/estado.json). Execução mais fiel, hipóteses de saída/filtro explícitas e sensibilidade a custos; não há nova receita promovida por lucro.

**F02 — Smart retida comum Spot/futuros concluída e conferida:** 1.632carteiras, zero treino. [Resultados e interpretação](resultados_smart_mercados.md). Custos iguais, controle de funding, extensão comprada/vendida e filtro fixo. [Protocolo](protocolo_smart_mercados.md), [estado](../registros/smart_mercados/estado.json). F01 permanece encerrada.

**Simulação posterior de futuros concluída e conferida — ADR0024:** zero novos treinamentos; 64 séries preservadas de Astra/crua alimentaram 804 carteiras. [Resultados e interpretação](resultados_futuros.md). [Arquitetura](arquitetura_operacoes.md), [protocolo](protocolo_futuros.md), [estado verificável](../registros/futuros/estado.json). Compras e vendas no BTCUSDT perpétuo com preços, marcação e funding públicos; custos e limites de pesquisa explícitos. O estado distingue preparação, execução e conclusão.

A [comparação Astra versus crua/Huber](resultados_comparacao_astra_crua.md) foi concluída e conferida. Seus modelos, dados e simulações Spot permanecem preservados. O [diagnóstico das previsões](diagnostico_previsoes.md) é uma análise posterior; não substitui critérios primários ou comprova utilidade operacional.

## Arquitetura e manutenção

| Etapa | Documento | Evidências |
|---|---|---|
| Mercado e entradas | [Arquitetura dos dados](arquitetura_dados.md) | [Estado](../registros/dados/estado.json) |
| Consumo pelos modelos | [Arquitetura dos modelos](arquitetura_modelos.md) | [Estado](../registros/modelos/estado.json) |
| Treino, seleção e checkpoints | [Arquitetura de treinamento](arquitetura_treinamento.md) | [Referência executada](../registros/treinamento/estado.json) |
| Simulações e mercado futuro | [Arquitetura operacional](arquitetura_operacoes.md) | [Estado das simulações](../registros/futuros/estado.json), [dados](../registros/mercado_futuros/estado.json) |
| Novas hipóteses | [Registro de experimentos](registro_de_experimentos.md) | [Mapa de registros](../registros/README.md) |
| Decisões e transporte | [ADRs](adr/README.md), [preservação](armazenamento_e_reproducao.md) | Catálogo e recibos por ciclo |

Novas hipóteses ficam em `experimentos/`; diagnósticos reutilizáveis em `analises/`. As camadas científicas antigas e pacotes `experimento_*/` permanecem congelados nos caminhos originais. Refinamentos do desenho não exigem recoleta automática de mercado.

Utilitários históricos estão indexados em [manutenção](../manutencao/README.md); não executar scripts de retomada como uma rotina genérica.

## Estudos encerrados

| Estudo | Protocolo | Resultado |
|---|---|---|
| Astra versus crua/Huber, executor comum | [Método](protocolo_comparacao_astra_crua.md) | [Resultado](resultados_comparacao_astra_crua.md) |
| Busca adaptativa Astra | [Método](protocolo_busca_astra.md) | [Resultado](resultados_busca_astra.md) |
| Crua + Huber, fatorial | [Método](protocolo_crua_huber.md) | [Resultado](resultados_crua_huber.md) |
| Representação das entradas | [Método](protocolo_entradas_niveis.md) | [Resultado](resultados_entradas_niveis.md) |
| MSE/Huber, quatro blocos/oito seeds | [Método](protocolo_huber_blocos.md) | [Resultado](resultados_huber_blocos.md) |
| Referência modular OHLCV | [Desenho](desenho_ohlcv24.md) | [Estado/publicação](../registros/treinamento/estado.json) |
| Estado16→8 | [Método](protocolo_estado_mamba.md) | [Relatório](resultados_estado_mamba.md) |
| Estados32/64 e complemento16 | [32/64](protocolo_estados32_64.md), [complemento](protocolo_complemento_estado16.md) | [Quatro estados/seis seeds](resultados_estados32_64.md) |
| Taxa constante menor | [Método](protocolo_taxa_aprendizado.md) | [Relatório](resultados_taxa_aprendizado.md) |
| Taxa dinâmica Mamba16 | [Método](protocolo_taxa_dinamica.md) | [Relatório e conferência posterior](resultados_taxa_dinamica.md) |
| Perda Huber Mamba16 | [Método](protocolo_perda_huber.md) | [Relatório e conferência posterior](resultados_perda_huber.md) |
| Carteira retida | [Método](protocolo_backtest_carteira.md) | [Relatório](resultados_backtest_carteira.md) |
| CryptoMamba adaptado | [Método](protocolo_cryptomamba_adaptado.md) | [Relatório](resultados_cryptomamba_adaptado.md) |
| Adam→AdamW nessa adaptação | [Método](protocolo_otimizador_cryptomamba.md) | [Relatório](resultados_otimizador_cryptomamba.md) |

A linha CryptoMamba foi encerrada após a solicitação de voltar ao Mamba temporal; seus resultados não são apagados ou confundidos com o Mamba16. A preparação `92e3eb82e3f6adf99994` em `estudo_ohlcv/` permanece sem treino; a referência modular e as extensões possuem identidades próprias, já executadas.

## Histórico e disciplina documental

[Estudos preliminares até28/10](../arquivo/estudos_preliminares_2026-10-28/README.md) ligam a fase de retornos escalares, penalização, pré-normalização e barreiras. Os protocolos congelados `protocolo_experimental.md`, `protocolo_penalizacao_mamba.md` e `protocolo_normalizacao_mamba.md` permanecem aqui por integridade; não definem automaticamente o próximo ciclo. O [cronograma acadêmico](../arquivo/estudo_barreiras_2026-10-20/projeto/docs/Cronograma_Atividades_TCC2_Murilo_Monferrari.pdf) não comprova aceite do orientador.

Não produzir explicações avulsas a cada conversa. Método no desenho/protocolo; decisões nas ADRs; fatos em `andamento.md`; evidências técnicas em `registros/`; resultados por tentativa. Preservar versões editoriais vinculadas aos fechamentos antes de consolidá-las. Não mover artefatos congelados para reduzir contagem de pastas. O [panorama web](../dataview/README.md) apresenta o cronograma da referência OHLCV e de suas extensões com alvo de 24h, até 03/11/2026; a fase exploratória aparece apenas como contexto; lê resultados preservados sem executar novos ajustes.
