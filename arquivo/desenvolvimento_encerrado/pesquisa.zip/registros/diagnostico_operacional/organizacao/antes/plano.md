# Plano de trabalho

Atualizado em 05/11/2026. Etapa atual: **sessão operacional encerrada e auditada, sem finalista**, identidade `f0dd11f393b5e26edaf8`. Oito receitas, 74 ajustes incluindo controles e 1.260 carteiras; nenhum processo de treino pendente. [Resultados](docs/resultados_operacional_futuros.md), [estado](registros/operacional_futuros/estado.json), [desenho congelado](docs/desenho_operacional_futuros.md). Reforço com oito seeds e avaliação final não foram acionados por inelegibilidade.

## Duas linhas identificadas

A investigação acadêmica OHLCV e seus ciclos continuam preservados, com seus objetivos e critérios originais: [desenho OHLCV](docs/desenho_ohlcv24.md), [TCC1](docs/TCC_1_MuriloRFM.pdf). A nova linha atende ao pedido de otimizar conjuntamente Mamba e política de compra/venda no futuro, considerando lucro e drawdown. Não reescrever os resultados passados ou presumir aprovação da ampliação pelo orientador. Uma busca encerrada sem estratégia elegível permanece resultado válido.

## Sequência executada e próximo trabalho

1. **Método congelado e executado.** Retorno terminal e payoff por lado, pesos em T, checkpoint em V, política em C e comparação em S. Calmar acompanhado de crescimento, perdas e estabilidade; nenhum teto arbitrário de 25% foi introduzido.
2. **Dados e integração conferidos.** Mercado 2021–2023 e conjunto preservado 2024–2025 íntegros; 50 testes CUDA e dois controles reais aprovados. A avaliação final não foi aberta nesta rodada por falta de candidata elegível.
3. **Fechamento auditado.** Cobertura exata, métricas, checkpoints, contratos, ledgers, curvas e fontes conferidos. Nenhuma promoção. Os limites condicionais não obrigam consumir todos os 185 ajustes/3.620 backtests.
4. **Prioridade reafirmada após o fechamento:** continuar buscando uma estratégia Mamba economicamente satisfatória, com lucro líquido mesmo modesto. O encerramento sem finalista não significa impossibilidade nem determina encerrar a pesquisa. Preservar as evidências para a redação; objetivo de lucro não é garantia de resultado.
5. **Próxima sequência recomendada, ainda sem nova execução:** diagnosticar o sinal e a política usando previsões existentes; reproduzir o CryptoMamba original, separando reprodução do backtest publicado de avaliação com custos; depois transferir a receita de forma identificada ao mercado futuro e explorar famílias de alvo/política justificadas. A adaptação anterior não reproduziu dados, calendário, alvo e orçamento originais. Antes de novos ajustes, fechar identidade, orçamento e critérios, corrigir o caso de borda de crescimento zero e melhorar o feedback do proponente.

## Direção proposta para a próxima rodada

- **Exploração informativa:** fornecer ao Astra resultados de C, erro e viés por lado, distribuição das previsões, custo por operação, giro, exposição, perdas por saída e motivos de rejeição. Resultados em caixa não podem ser o único feedback de receitas rejeitadas. Não fornecer períodos reservados à confirmação.
- **Diagnóstico antes de mais rede:** verificar se sinais maiores ordenam retornos/payoffs melhores, se comissões/giro ou regras de saída explicam perdas, e comparar com regras simples e sinais de controle. Esses diagnósticos usam desenvolvimento e não são uma nova confirmação independente.
- **Reprodução como controle positivo:** conferir dados, checkpoints/configurações e políticas públicas CryptoMamba na versão identificada. O artigo v2 relata 100→262,78 dólares com Extended Smart, mas a rotina pública examinada não debita explicitamente comissão/slippage/funding. Reproduzir e depois medir o efeito de hipóteses de execução é diferente de assumir lucro transferível ao futuro Binance. Fontes: https://arxiv.org/html/2501.01010v2 e commit público fef42727861a9c3a32241283ab981ef21a49e291, já preservado no projeto.
- **Famílias operacionais:** priorizar uma referência de previsão diária com posição retida/reavaliada, antes de mais variações do payoff com saídas fixas por barreiras. Classificação de oportunidade ou quantis são hipóteses seguintes, caso os diagnósticos as justifiquem. Variações de frequência de decisão e retenção são diferentes da frequência dos candles. Não alterar simultaneamente todas essas dimensões e atribuir causalidade a uma só.
- **Explorar versus confirmar:** registrar resultados graduais e famílias promissoras sem promover receitas apenas porque tiveram algum lucro. Rever prospectivamente a exigência de 20 operações em cada lado/recorte, que pode excluir estratégias seletivas; compensar menor atividade com maior período e incerteza explícita. Não reduzir critérios após ver o teste. Confirmar em dados cuja exposição seja verificada ou acompanhamento prospectivo; repetir 2024–2025 não os torna inéditos.

Estas recomendações não iniciam novos treinos/backtests nem reabrem a execução encerrada. O pedido atual redefine a prioridade e solicita uma proposta de continuidade; o próximo ciclo terá escopo próprio.

## Fechamentos preservados

- [Astra002](docs/resultados_busca_astra_002.md):12receitas,100ajustes conferidos; sem finalista e sem novos backtests.
- [F03](docs/resultados_revisao_operacional.md):1.200carteiras conferidas,zero treino; limites de execução e contribuição dos lados explícitos.
- [F02](docs/resultados_smart_mercados.md):1.632carteiras; [F01](docs/resultados_futuros.md):804carteiras,ambas sem treino.
- [Astra versus crua/Huber](docs/resultados_comparacao_astra_crua.md), demais hipóteses e estudos preliminares: referências próprias no catálogo, sem reexecução ou promoção automática.

A navegação separa as linhas sem mover pacotes/artefatos congelados. [Registro de experimentos](docs/registro_de_experimentos.md) e [preservação](docs/armazenamento_e_reproducao.md) regem novas execuções. O recibo desta organização conserva a versão anterior deste plano e dos demais documentos editoriais em `registros/operacional_futuros/organizacao/`.
