# CryptoCasting — investigação de previsão com Mamba e OHLCV

TCC sobre decisões controladas de entrada e configuração do Mamba, com LSTM, Naive e ARIMA como referências. O objetivo é compreender precisão, estabilidade e utilidade operacional; resultados negativos também são válidos.

## Trabalho atual

**Pesquisa operacional em futuros encerrada e auditada, sem finalista.** Execução `f0dd11f393b5e26edaf8`: oito receitas, 72 ajustes principais + dois controles, três seeds por recorte e 1.260 carteiras. C05 foi a única receita que operou na comparação, em um recorte, com retorno médio de −8,23% nesse trimestre; as demais permaneceram em caixa após reprovação da calibração. Reforço com oito seeds e avaliação final não acionados. [Resultados, gráfico e limitações](docs/resultados_operacional_futuros.md), [desenho congelado](docs/desenho_operacional_futuros.md), [estado verificável](registros/operacional_futuros/estado.json). Estudos anteriores preservados; nenhuma busca adicional automática.

**Busca Astra002 encerrada sem finalista:**12configurações e100ajustes concluídos/conferidos. Nenhuma candidata cumpriu os critérios após reforço com três seeds. Zero treinos finais e zero novas carteiras; referências anteriores preservadas. [Resultados e evidências](docs/resultados_busca_astra_002.md).

**Revisão operacional F03 concluída e conferida:** 1.200 carteiras, zero treinos. Comissão recebida, redução de posições, margem e resíduos revisados; política e custos avaliados separadamente. [Resultados e limites](docs/resultados_revisao_operacional.md), [método](docs/protocolo_revisao_operacional.md), [estado](registros/revisao_operacional/estado.json). A melhoria técnica não produziu superioridade operacional consistente. F01/F02 permanecem preservadas.

**Smart retida comum Spot/futuros (F02) concluída e conferida**, sem novos treinamentos. [Resultados](docs/resultados_smart_mercados.md). Sinais comuns, posições retidas, custos iguais e controle de funding; a extensão bilateral também muda a intensidade das saídas, conforme os limites do relatório. Filtro fixo≈0,30%. [Método](docs/protocolo_smart_mercados.md), [estado](registros/smart_mercados/estado.json).

**Camada de simulação em futuros concluída e conferida**, separada do treino e do Spot. Zero novos ajustes; 804 carteiras compradas/bilaterais com funding histórico. [Resultados](docs/resultados_futuros.md). [Arquitetura](docs/arquitetura_operacoes.md), [protocolo](docs/protocolo_futuros.md), [estado da execução](registros/futuros/estado.json).

Comparação concluída da candidata Astra com **OHLCV cru + Huber**, no mesmo executor, dados e oito seeds/quatro blocos.32modelos Astra reaproveitados;32crus novos e dois controles. [Resultados e interpretação](docs/resultados_comparacao_astra_crua.md). [Protocolo](docs/protocolo_comparacao_astra_crua.md), [estado verificável](registros/comparacao_astra_crua/estado.json). Sem nova busca de configurações.

Busca adaptativa assistida por **Astra** concluída:106ajustes e408simulações. [Resultados e limitações](docs/resultados_busca_astra.md). [Protocolo](docs/protocolo_busca_astra.md), [estado real](registros/busca_astra/estado.json), [ADR0022](docs/adr/0022-busca-adaptativa-astra.md). Ciclos anteriores preservados; nenhuma promessa de lucro ou melhora.

A referência de continuidade é **Mamba16/AdamW**, BTCUSDT, candles de1h, contexto de168h e previsão do log-retorno em24h, com cinco canais OHLCV transformados causalmente. Os estudos anteriores estão encerrados e preservados.

A rodada anterior, concluida e preservada, ampliou **MSE versus2×Huber** para quatro blocos temporais e oito seeds por versão/bloco:64ajustes principais+2controles reais, total66, com quatro Naive e408simulações. [Protocolo](docs/protocolo_huber_blocos.md), [estado verificável](registros/huber_blocos/estado.json). Qualificação/preparação precedem mercado; oito seeds não garantem certeza. A comparação anterior de seis seeds e divisão fixa está [concluída e preservada](docs/resultados_perda_huber.md), sem promoção automática.

Antes da rodada, foi feito um [diagnóstico das previsões existentes](docs/diagnostico_previsoes.md), incluindo erros extremos, frequência de vitória frente ao Naive, correlações, faixas de previsão e trimestres. Não altera resultados anteriores nem seleciona uma seed favorável.

## Como navegar

- [Índice documental](docs/README.md): método, arquitetura e estudos encerrados.
- [Desenho OHLCV](docs/desenho_ohlcv24.md): decisões de dados/alvo/treinamento.
- [Plano](plano.md): próximos estágios; [andamento](docs/andamento.md): cronologia factual única.
- [Catálogo](registros/catalogo_estudos.json): identidades, tentativas, resultados e relação entre ciclos.
- [Roteiro do TCC](docs/roteiro_redacao_tcc.md) e [PDF acadêmico original](docs/TCC_1_MuriloRFM.pdf).

## Estrutura

| Camada | Responsabilidade |
|---|---|
| `mercado_binance/` | Coleta, proveniência, validação e candles completos |
| `entradas_modelo/` | Canais, alvos, janelas, divisões, purga e escalas de treino |
| `modelos/` | Contratos e consumo por Mamba, LSTM, Naive e ARIMA |
| `treinamento/` e `avaliacao/` | Referência modular congelada: ajuste, seleção, checkpoints e avaliação |
| `analises/` | Diagnósticos reutilizáveis de previsões preservadas |
| `experimentos/` | Novas hipóteses com código e orçamento próprios; Huber: `python -m experimentos.perda_huber`, preservando lançadores congelados |
| `configuracoes/`, `registros/`, `dados/experimentos/` | Receitas, evidências e artefatos por tentativa |
| `arquivo/` | Estudos preliminares preservados; não são evidência de rede OHLCV |

Os pacotes históricos `experimento_*/` e seus lançadores permanecem onde foram executados, pois seus caminhos/fontes integram os recibos. Não são lixo ou autorização para reexecutar. Novas rodadas usam o namespace comum para evitar proliferação na raiz. A referência preparada `estudo_ohlcv/` é histórica; o treino modular efetivo possui outra identidade.

## Resultados encerrados

| Estudo | Consulta |
|---|---|
| Estados8/16/32/64, seis seeds | [Comparação](docs/resultados_estados32_64.md) |
| Taxa constante0,0002→0,0001 | [Comparação](docs/resultados_taxa_aprendizado.md) |
| Taxa dinâmica Mamba16 | [Comparação e conferência posterior](docs/resultados_taxa_dinamica.md) |
| Perda Huber Mamba16, seis seeds | [Comparação e conferência posterior](docs/resultados_perda_huber.md) |
| Carteiras retidas e controles,369simulações | [Backtest](docs/resultados_backtest_carteira.md) |
| CryptoMamba adaptado e Adam→AdamW | [Adaptação](docs/resultados_cryptomamba_adaptado.md), [otimizador](docs/resultados_otimizador_cryptomamba.md); linha encerrada |
| Retornos escalares, penalização, normalização e barreiras | [Arquivo preliminar](arquivo/estudos_preliminares_2026-10-28/README.md) |

2024/2025 já foram consultados: os novos contrastes são retrospectivos, sem alegação de holdout intocado ou walk-forward. Futuras hipóteses exigem delimitação e qualificação próprias; não há busca automática até lucrar.

## Execução e preservação

Consultar [regras de registro](docs/registro_de_experimentos.md) e [preservação entre máquinas](docs/armazenamento_e_reproducao.md). Fontes/configurações/publicações congeladas são imutáveis. Preparar, autorizar, treinar e auditar são fases distintas. Não duplicar processo vivo nem repetir executor encerrado para gerar relatório.

O portal em `dataview/` mostra o estudo preliminar; não representa os novos resultados OHLCV. Dados grandes e checkpoints permanecem fora do Git comum; hashes e disponibilidade local não certificam backup externo.

Combinação crua/Huber autorizada: [método](docs/protocolo_crua_huber.md), [estado verificável](registros/crua_huber/estado.json).32treinos principais novos+1controle,96referências herdadas;comparação fatorial retrospectiva sem promessa de ganhos aditivos.
