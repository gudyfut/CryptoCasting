# Pesquisa operacional em futuros — desenho de trabalho

Proposta `operacional_futuros_001`, de 04/11/2026 (Brasília), vinculada à [ADR0028](adr/0028-pesquisa-operacional-futuros.md). **Organização e desenho autorizados; executor novo não implementado, nenhum treinamento ou backtest iniciado nesta linha.** [Estado](../registros/operacional_futuros/estado.json) e [configuração proposta](../configuracoes/operacional_futuros_001_proposta.json). Este é o documento canônico para refinamentos, até o congelamento de um protocolo executivo.

## 1. Pergunta e separação dos estudos anteriores

Queremos encontrar, dentro de um orçamento limitado, uma combinação de **Mamba, informação de entrada, alvo e política operacional** que produza crescimento líquido do patrimônio com uma relação favorável entre retorno e perdas no caminho. Instrumento: BTCUSDT perpétuo USDⓈ-M da Binance; posições compradas, vendidas ou em caixa. A unidade de comparação é a estratégia completa, não somente o checkpoint neural.

Isso muda o critério da busca: o MSE deixa de ser a barreira de promoção econômica. Os estudos OHLCV e Astra001/002 mantêm seus objetivos, métricas, conclusões e caminhos; a F03 mantém seu motor e resultados. Não reescrever o passado como se tivesse sido selecionado por lucro. O [desenho acadêmico anterior](desenho_ohlcv24.md) continua sendo sua referência. A incorporação desta nova linha ao artigo precisa ser explicitada como ampliação de escopo, sem presumir aprovação do orientador ou alterar o PDF.

A busca Astra002 terminou sem finalista segundo seus critérios preditivos. A [F03](resultados_revisao_operacional.md) mostrou que transferir sinais treinados em Spot para uma estratégia bilateral não assegurou ganho; em vários braços, vendas prejudicaram o resultado. Essas evidências motivam a nova pergunta, mas não fornecem uma candidata operacional já comprovada.

## 2. O que significa melhor: patrimônio, crescimento e drawdown

Usar patrimônio marcado a mercado, incluindo lucro/prejuízo das posições abertas, e descontar comissão, deslizamento e funding. Não medir apenas saldo disponível, operações encerradas ou pico de dinheiro. Sem aportes/retiradas; resultados antes de tributos. Saques ou encerramento após atingir um valor seriam políticas próprias, definidas antes do teste.

Para cada carteira, com duração `D` em dias e patrimônio `E`:

- Retorno líquido: `R = E_final / E_inicial - 1`.
- Crescimento logarítmico diário: `g = log(E_final / E_inicial) / D`; equivalente à média dos log-retornos diários do patrimônio.
- Taxa composta anualizada: `CAGR = exp(365 × g) - 1`. É uma transformação para comparação, não previsão de rendimento anual. Sempre exibir o retorno efetivo e a duração; anualizar trimestres pode amplificar resultados transitórios.
- Drawdown máximo: `MDD = max_t(1 - E_t / max_{u≤t} E_u)`.
- **Calmar no período:** `CAGR / MDD`, com ambos em frações. Usa o mesmo período para numerador e denominador. É uma adaptação por bloco, não a alegação de possuir uma janela convencional de 36 meses.

**Recomendação de seleção operacional: Calmar como compromisso principal, acompanhado obrigatoriamente de crescimento composto e estabilidade.** O escore de uma receita será a mediana dos Calmar das carteiras bloco×seed elegíveis, com cobertura balanceada. A mediana reduz o domínio de um único quociente extremo; também publicar médias, medianas, dispersão e cada célula. Calmar indefinido, empate, carteira sem operações ou drawdown nulo não recebe infinito nem vira vencedora; é caso separado. Empates numéricos usam maior crescimento logarítmico médio e depois menor giro. A precisão do empate será congelada no executor.

Calmar permite que uma estratégia mais arriscada vença se o retorno compensar proporcionalmente: no mesmo ano, 120% de retorno/40% de drawdown = 3, contra 30%/15% = 2. Mas não prova que 40% de queda seja aceitável para uma pessoa. Também pode favorecer uma carteira de lucro pequeno e drawdown muito pequeno. Por isso preservar a **fronteira retorno–drawdown**: mostrar as alternativas que não são simultaneamente piores em retorno e risco, incluindo a de maior crescimento. Não esconder o compromisso em uma nota única.

Picos maiores, isoladamente, não constituem vantagem: 100 → 200 → 80 perdeu 20%; 100 → 110 → 121 ganhou 21%. A segunda teve pico menor. Em contrapartida, aceitar maior oscilação pode compensar quando melhora o crescimento sustentado e a sobrevivência. “Quase nunca zera” não basta para estimar a perda rara que pode destruir muitos ganhos.

O crescimento logarítmico tem fundamento na literatura de crescimento de capital, mas **não penaliza sozinho a trajetória**: dois caminhos com início/fim iguais têm o mesmo `g`, mesmo com drawdowns distintos. Não usar uma fórmula de Kelly alimentada por probabilidades não calibradas para dimensionar posições. A literatura explicita o compromisso adicional entre crescimento e risco de drawdown: [Busseti, Ryu e Boyd](https://web.stanford.edu/~boyd/papers/kelly.html). Definição de Calmar: [Morningstar](https://admainnew.morningstar.com/directhelp/Glossary/Custom_Statistics/Calmar_Ratio.htm).

O pesquisador solicitou uma métrica que balanceie risco e retorno, em vez de escolher o limite sugerido de 25%. **Nenhum teto de drawdown de 20%, 25% ou 30% foi aprovado.** A pesquisa mostrará quedas, duração abaixo do pico, perdas extremas e comprometimento de margem. Seleção acadêmica não autoriza colocar a estratégia em uma conta real.

## 3. Mercado, entradas e tarefas a comparar

O conjunto de futuros atualmente registrado em `registros/mercado_futuros/estado.json`, identidade `979c54995465216ea020`, tem contrato de **01/01/2024 até 01/01/2026 exclusivo**. Não cobre o desenvolvimento proposto de 2021–2023. Preparar uma nova coleta identificada, sem substituir esse manifesto. Conferir disponibilidade histórica, integridade, timestamps/unidades, lacunas e candles completos de negociação, marcação e funding. [Dados públicos oficiais](https://github.com/binance/binance-public-data) e [API de futuros](https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/market-data).

Primeira rodada: BTC, candles de 1h completos, prazo máximo de 24h e contexto inicial de 168h. Contextos candidatos de 24/72/168h; população comum com aquecimento de 336h, incluindo indicadores. Dados para execução e marcação em 1min. Escalas ajustadas somente em T; nenhuma normalização pelo período inteiro. Funding só entra como característica quando seu valor já estava publicado; o funding realizado futuro pertence ao alvo/contabilidade, nunca à entrada.

Comparar duas famílias inicialmente, mantendo a mesma base Mamba oficial CUDA, estado16/AdamW/taxa0,0002 e receita de treinamento identificada:

| Receita inicial | O que a rede estima | Treino/seleção de época | Uso operacional |
|---|---|---|---|
| R0 terminal | Log-retorno do contrato futuro nas próximas 24h | Huber de treino; MSE de V, como a referência anterior | Sinal terminal convertido em decisão por regra explícita |
| P0 resultado da operação | Dois valores: resultado líquido por unidade de nocional de abrir uma compra ou uma venda com saída definida | MSE dos dois alvos padronizados; MSE real médio dos dois canais em V | Escolher o lado com maior resultado previsto positivo, acima da margem de entrada |

R0 herda a **receita**, não pesos nem números de Spot. Reestimá-la no mesmo instrumento, datas e executor da candidata. A mudança R0→P0 é uma comparação de abordagem (alvo, cabeça de saída e perda), não ablação causal de um único fator. MSE de tarefas diferentes não pode decidir qual estratégia ganhou.

P0 usa como rótulo o resultado de uma operação hipotética unitária, executada após o sinal, incluindo saída por stop/take/tempo, preços de execução, comissão e funding até a saída. Não é previsão infalível nem garantia de lucro. O resultado de expirar pode ser positivo ou negativo. Guardar também motivo e tempo da saída. Operações hipotéticas sobrepostas servem de exemplos supervisionados; **a carteira real simulada continua com uma posição por vez**, sujeita a capital, margem e filtros. Custos dependentes de tamanho e arredondamento pertencem à carteira, não podem ser tratados como idênticos ao rótulo unitário.

Barreiras iniciais propostas: volatilidade conhecida `σ24 = std(log-retornos horários das últimas 168h, ddof=1) × sqrt(24)`; distância logarítmica do stop `max(σ24, 0,005)` e take `1,5 × distância_stop`, fixadas na entrada. O piso de 0,5% evita distância nula e é uma escolha de pesquisa, não parâmetro ideal demonstrado. Preços das barreiras são exponenciais dessas distâncias em torno do preço preenchido, invertidos para venda. Prazo termina 24h após a entrada. Não ajustar a volatilidade pela trajetória futura.

**Se stop, take ou horizonte do P0 mudar, o alvo muda:** gerar outra identidade e retreinar. Não reutilizar suas previsões para afirmar que estimavam o payoff de outra regra. Já uma mudança apenas de limiar ou tamanho pode reutilizar as previsões, respeitados os custos do tamanho. Testes de custos estressados mantêm o modelo treinado no cenário base e mudam a execução; não corrigem os rótulos depois de observar o teste.

## 4. Política variável e execução fixa

Astra propõe receitas permitidas; o avaliador continua fechado. A estratégia pode alterar informações causais, contexto, parâmetros permitidos, alvo identificado e política. Não pode alterar datas, métricas, custos, resolução de execução ou regras de preenchimento para melhorar artificialmente o placar.

Primeiro ciclo sem busca de alavancagem: capital inicial 10.000 USDT por carteira independente; nocional de entrada limitado a 95% do patrimônio; uma posição líquida comprada/vendida, sem martingale, pirâmide ou simultaneidade de hedge. Nocional inicial inferior ao patrimônio **não elimina risco de margem**, especialmente em uma venda cujo preço sobe. Não simular futuros como uma venda de moedas já possuídas.

Grade interna proposta: margem adicional de entrada de 0/10/20 pontos-base; risco nominal ao stop de 0,5%/1% do patrimônio; decisão a cada 1h/4h UTC, total **12 políticas por receita**. Tamanho aproximado resulta do orçamento de perda dividido pela distância percentual ao stop, limitado pelo nocional/margem/filtros. Acrescentar custos estimados ao risco antes de arredondar para baixo; gaps podem exceder esse orçamento. R0 usa `exp(previsao)-1` para compra e seu oposto para venda, descontando estimativas causais de comissão/deslizamento/funding; é um escore heurístico terminal, não a esperança exata da operação com barreiras. P0 já estima resultado líquido: não descontar comissão duas vezes. Estimador de funding deve usar apenas taxas publicadas no passado e ficar fixado antes do treino.

Sem posição, abrir o lado com maior escore que supere o limiar; empate entre lados não abre. Com posição, aguardar stop, take ou tempo; sinais novos não abrem operações sobrepostas. Saída pelo sinal oposto, trailing stop ou realização parcial exigem receita/política explícitas posteriores. Uma regra sem operações é resultado real, não motivo para reduzir limiar depois do teste.

Motor novo deve qualificar: disponibilidade do candle antes da decisão; latência de pelo menos 1min; ordem executada no primeiro preço posterior permitido; stops com gap e deslizamento; funding pelo lado/nocional/horário; comissão em cada preenchimento; margem, manutenção e liquidação; filtros de quantidade/preço/nocional; fechamento e taxas no fim do bloco. A reserva F03 não equivale à liquidação oficial. Tabelas históricas indisponíveis precisam ser assumidas e testadas conservadoramente, com limitação explícita, sem certificação de fidelidade exata à exchange.

Base proposta: comissão taker de 0,05% por lado, deslizamento de 0,05% por preenchimento e funding histórico. São hipóteses de pesquisa, não tarifa verificada da conta do pesquisador. Sensibilidades com deslizamento de 0,10% e 0,15%; não usar desconto BNB/VIP sem evidência. Comissões/slippage não podem ser escolhidos pela rentabilidade. Custos da execução e unidade do alvo precisam reconciliar para não duplicar cobranças.

Se stop e take ocorrerem no mesmo minuto sem ordem intraminuto conhecida, assumir stop primeiro e registrar ambiguidade. Não usar o close para inventar o caminho; não escolher preenchimento favorável. Take também usa execução conservadora, sem presumir fila maker. Drawdown usa marcação de 1min, extremos adversos e eventos, além da curva diária; revelar a limitação intraminuto. Não apagar perdas, intervalos ruins ou incidentes. Patrimônio não positivo/liquidação reprova a estratégia e permanece no relatório.

## 5. Separar aprender, parar, escolher política e comparar

Quatro papéis em ordem temporal, limites finais exclusivos:

| Recorte | T: pesos/escalas desde 01/01/2021 até | V: seleção de época | C: seleção da política | S: comparação de receitas |
|---|---|---|---|---|
| D1 | 01/10/2022 | 2022 T4 | 2023 T1 | 2023 T2 |
| D2 | 01/01/2023 | 2023 T1 | 2023 T2 | 2023 T3 |
| D3 | 01/04/2023 | 2023 T2 | 2023 T3 | 2023 T4 |

Reestimar do zero por recorte. V escolhe somente checkpoint; C escolhe uma política por receita/recorte a partir do conjunto de seeds disponíveis, antes de S. As seeds não recebem políticas escolhidas individualmente pelo seu lucro. **Não calibrar uma política conjunta com C de recortes posteriores para avaliar S anteriores.** Ao ampliar de três para oito seeds, recalibrar em C e publicar nova versão de avaliação das oito, preservando a etapa de três.

Purga pelo maior instante de realização dos alvos, incluindo entrada/latência e saída máxima; 24h cravadas podem ser insuficientes quando a entrada ocorre depois da origem. Nenhum rótulo de T atravessa V, de V atravessa C ou de C atravessa S. Contexto anterior pode ser usado por ser passado conhecido. Calendário comum, sem interpolação e sem filtrar exemplos por retorno futuro. Não abrir operações que o calendário já informa não caberem no fim do segmento; intervalo com execução desconhecida invalida a cobertura e exige incidente, não exclusão silenciosa.

Astra recebe somente resumos do desenvolvimento e histórico de suas tentativas. Ver S repetidamente torna S parte da busca, não teste independente. Finalista, procedimento de calibração e motor são congelados antes de quatro blocos retrospectivos:

| Bloco final | T até | V | C | Avaliação |
|---|---|---|---|---|
| B1 | 01/07/2023 | 2023 T3 | 2023 T4 | 2024 S1 |
| B2 | 01/01/2024 | 2024 T1 | 2024 T2 | 2024 S2 |
| B3 | 01/07/2024 | 2024 T3 | 2024 T4 | 2025 S1 |
| B4 | 01/01/2025 | 2025 T1 | 2025 T2 | 2025 S2 |

T começa em 2021 em todos os casos. O algoritmo de recalibração em C permanece fixo; ele pode aprender do passado permitido de um bloco anterior, mas não mudar a receita após seus resultados. Carteiras reiniciadas por bloco; não somar ou compor médias como se fossem uma conta contínua. **2023–2025 já foram consultados.** Nem novos alvos nem novas seeds tornam esses anos intocados. Uma confirmação mais forte exigirá período comprovadamente não usado ou acompanhamento prospectivo com decisões registradas antes de cada resultado.

## 6. Busca limitada, métricas e critérios propostos

Até oito receitas: R0/P0 iniciais e seis propostas locais do Astra. Cada proposta identifica a receita-mãe e a alteração: contexto 24/72/168h; canais OHLCV crus/relativos/padronizados e grupos causais de momentum, volatilidade ou volume; estado16/32; taxa0,0001/0,0002; ou par stop/take de uma lista finita. Fórmulas completas e pares permitidos devem ser enumerados **antes da qualificação**, sem gerar novos graus de liberdade após ver S. Candles15min/4h, horizonte6h, saídas adaptativas e alavancagem ficam para outro ciclo, não combinados silenciosamente nesta primeira busca. A ampliação posterior é possível; cada etapa terá orçamento e identidade.

Todos os resultados, inclusive falhas e regras sem operação, ficam registrados. Inicialmente três seeds pareadas:42/17/2026. Até duas candidatas mais R0 recebem as cinco seeds adicionais7/123/31415/271828/161803. Seleção de receita pelo Calmar mediano em S; curvas completas e fronteira de retorno/drawdown permanecem visíveis. O escore não é uma probabilidade de lucro.

Elegibilidade proposta para promoção: cobertura completa; nenhuma insolvência/liquidação; crescimento logarítmico médio positivo no cenário base e no deslizamento2×; crescimento médio positivo em pelo menos dois dos três S; pelo menos20 operações encerradas por carteira S. São limites de pesquisa predefinidos, não teoremas. Atividade insuficiente recebe esse diagnóstico, sem forçar mais operações. O reforço exige crescimento médio por seed positivo em pelo menos seis das oito seeds; nunca apagar as demais. Se não houver candidata elegível melhor que R0 no escore, encerrar sem nova campeã. A referência pode ser negativa; não inventar uma melhoria por comparação de duas perdas.

Em C, aplicar cobertura, não insolvência, pelo menos20 operações e crescimento médio positivo entre seeds; ordenar as políticas pelo Calmar mediano. Se nenhuma passar, a receita permanece em caixa nesse S e não satisfaz a atividade para promoção. Cenários de estresse são aplicados depois, sem recalibrar o limiar no próprio S. O cenário3× é sensibilidade severa, não nova oportunidade de selecionar política. Na final, reportar tudo, inclusive perda dos critérios que justificaram a promoção; não voltar à busca dentro do mesmo ciclo.

Métricas obrigatórias: retorno líquido efetivo, crescimento composto, Calmar, MDD e tempo de recuperação, quantis das perdas diárias/Expected Shortfall95%, pior bloco/seed, exposição, operações e giro, custos/funding, fração de seeds e blocos positivos. Sortino e Sharpe são diagnósticos secundários, com frequência e autocorrelação explícitas. MSE/MAE/correlação permanecem por tarefa; classificação/calibração só quando a saída realmente permitir. Não chamar escore de retorno de probabilidade.

Médias de oito carteiras não são uma carteira que combina oito modelos. Um ensemble precisa de regra anterior ao teste e simulação própria. Intervalos devem parear seeds e datas, com bootstrap de blocos de dias14 e sensibilidades7/28; preservar retornos diários e extremos intradiários associados aos dias para reconstruir drawdowns coerentemente. Relatar incerteza do crescimento/retorno e do contraste, não somente do quociente. Bootstrap condicional e oito seeds não corrigem automaticamente a busca adaptativa, mudanças de regime ou eventos ausentes. A literatura sobre [sobreajuste de backtests](https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf) fundamenta a limitação, não uma garantia de eliminá-la.

## 7. Como distinguir habilidade bilateral de uma aposta na alta

Usar sempre o mesmo contrato futuro. Comparações mínimas: estratégia bilateral, somente comprada e somente vendida com regras correspondentes; baselines em caixa, sempre comprado, sempre vendido e tendência causal simples. Baselines passivas têm exposição própria explícita; não são pareamento de risco perfeito. A regra de tendência e seu tamanho serão congelados e não ajustados por S. Naive de retorno zero é diagnóstico preditivo de R0 e equivale a caixa sob a regra de entrada; não exige treino nem uma simulação duplicada.

Publicar a contribuição em USDT e pontos do patrimônio inicial de compras/vendas: preço bruto, comissão, deslizamento e funding. A soma deve reconciliar com o patrimônio final. A contribuição contábil não basta para atribuição causal: remover shorts muda capital, oportunidades e trajetória. Mostrar também retornos por unidade de exposição e diagnósticos de previsão em todas as origens, inclusive as sem operação.

Avaliar lucro, quantidade, exposição e estabilidade do lado vendido separadamente. Uma estratégia pode ser lucrativa e ainda não demonstrar habilidade em quedas. Não impor operações artificiais ou 50% para cada lado; ausência de vendas é falta de evidência bilateral. Não declarar melhoria bilateral apenas porque o resultado total ou o Calmar cresceu. Regimes de alta/baixa são descrição posterior; uma classificação que usa o futuro não pode decidir operações.

## 8. Orçamento proposto, sem autorização de execução

| Etapa | Máximo de ajustes novos |
|---|---:|
| Oito receitas × três recortes × três seeds | 72 |
| Dois controles reais D1/42, R0 e P0 | 2 |
| Duas candidatas + R0 × três recortes × cinco seeds adicionais | 45 |
| Uma candidata + R0 × quatro blocos × oito seeds | 64 |
| Dois controles reais finais B1/42 | 2 |
| **Teto condicional** | **185** |

Controle não entra nas médias. Não repetir R0 se coincidir com a candidata; sem elegível, etapas condicionais não ocorrem. Até oito chamadas ao proponente: uma qualificação técnica, seis receitas aceitas e uma tentativa técnica adicional; falha/cota esgota a etapa, sem API paga. Teto de24h para exploração/reforço proposto; a final tem orçamento separado e estimativa baseada em benchmark. Não prometer185ajustes em um dia. Só comparar coortes completas ao atingir o prazo, sem favorecer a receita cujo treino acabou primeiro.

Avaliações lógicas máximas: por carteira neural,12 políticas em C e5 avaliações em S/B (bilateral base, bilateral deslizamento2×/3×, somente compra base, somente venda base). Exploração:72×17=1.224; reforço, recalibrando as oito seeds:72×17=1.224; final:64×17=1.088; quatro baselines × sete segmentos × três custos=84. **Total3.620 avaliações lógicas**; reaproveitamento de C idêntico pode reduzir execuções físicas, com herança registrada. Controles verificam reprodução, sem carteiras adicionais. Reamostragens estatísticas não são novas operações de mercado. Grade detalhada, fórmulas restantes, testes e benchmark ainda precisam fechar o protocolo executivo antes de treinamento.

## 9. Organização, contratos e condições para implementar

Separação lógica no catálogo e nos caminhos, sem mover ou copiar os grandes artefatos encerrados:

| Responsabilidade | Base existente | Trabalho necessário para esta linha |
|---|---|---|
| Observações públicas de futuros | `mercado_futuros/` | Coleta2021–2023 e contratos históricos; nova identidade |
| Canais, alvos e divisões | `entradas_modelo/` | Contrato de dois alvos de payoff e disponibilidade temporal |
| Rede | `modelos/` | Adaptador de saída por tarefa, sem editar núcleos congelados |
| Treino/checkpoints | `treinamento/` | Seleção por V, máscaras/purga corretas e recarga |
| Contabilidade/políticas | `simulacao_operacoes/` | Nova versão com barreiras/margem; F03 permanece imutável |
| Coordenação | Futuro `experimentos/operacional_futuros/` | Ainda não implementado; valida receitas, limita orçamento e isola Astra |
| Evidências | `registros/operacional_futuros/` | Estado de proposta, preservação e futura qualificação/autorização |
| Artefatos científicos | Futuro `dados/experimentos/operacional_futuros_<id>/` | Só criar identidade executiva após qualificação/congelamento |

Identificar separadamente `dataset_id`, `entrada_id`, `alvo_id`, `receita_id`, `politica_id`, `motor_id` e `ciclo_id`. Mudança de alvo não pode se esconder sob alteração de política. Astra não recebe acesso a editar o motor, dados finais ou recibos; propostas rejeitadas e mensagens ficam registradas. Pesos são ajustados pelo treinamento, não editados arbitrariamente pelo agente.

Antes de qualquer treino: completar as fórmulas/grade e custo estimado; conferir dados; testar causalidade com perturbação do futuro, purga e disponibilidade; verificar equivalência entre rótulo unitário e operação isolada; testar caminhos conhecidos para compra/venda, stops/gaps/funding, arredondamento e margem; conferir patrimônio independentemente; qualificar CUDA, atualização, repetição e recarga; conferir fontes/PID/locks; congelar identidade e vincular autorização compatível. Não chamar executor encerrado para reutilizar resultados. A autorização atual cobre organizar e desenhar, não iniciar este orçamento.

Esta proposta busca um resultado economicamente melhor entre alternativas examinadas. Pode terminar sem estratégia aprovada. Não transforma retrospectiva em garantia de lucro, não prova risco de ruína baixo pela ausência de quebras observadas e não promete encontrar o melhor modelo possível.
