# Plano de trabalho

Atualizado em04/11/2026 (Brasília). Etapa atual: **organizar e preparar a pesquisa operacional em futuros**, autorizada como elaboração, ainda sem execução. [Desenho canônico](docs/desenho_operacional_futuros.md), [ADR0028](docs/adr/0028-pesquisa-operacional-futuros.md), [estado](registros/operacional_futuros/estado.json).

## Duas linhas identificadas

A investigação acadêmica OHLCV e seus ciclos continuam preservados, com seus objetivos e critérios originais: [desenho OHLCV](docs/desenho_ohlcv24.md), [TCC1](docs/TCC_1_MuriloRFM.pdf). A nova linha atende ao pedido de otimizar conjuntamente Mamba e política de compra/venda no futuro, considerando lucro e drawdown. Não reescrever os resultados passados ou presumir aprovação da ampliação pelo orientador. Uma busca encerrada sem estratégia elegível permanece resultado válido.

## Sequência proposta

1. **Fechar o método operacional.** Comparar retorno terminal e payoff líquido por lado, escolher política em C e comparar em S, após T/V. Calmar por período acompanhado de crescimento composto, fronteira retorno/drawdown e estabilidade. Não houve escolha de teto25%; picos isolados não selecionam estratégia.
2. **Preparar dados e contratos.** O manifesto de futuros disponível cobre2024–2025. Coleta/validação2021–2023, canais/alvos e nova versão de execução com barreiras/margem precisam ser preparados; não substituir dados antigos.
3. **Implementar e qualificar antes de treinar.** Enumerar receitas e fórmulas restantes; conferir causalidade, purga, políticas, preenchimentos, custos, funding, margem, contabilidade, checkpoints e CUDA. Medir tempo real. Configuração proposta não é executável.
4. **Congelar e executar somente com autorização compatível.** Teto proposto de oito receitas,185ajustes condicionais e3.620avaliações lógicas. Todas as tentativas preservadas; nenhuma busca indefinida. Testes2024–2025 são retrospectivos; nova confirmação exige exposição verificada ou acompanhamento prospectivo.
5. **Redigir o artigo usando o que realmente estiver concluído.** [Roteiro](docs/roteiro_redacao_tcc.md), cronologia única em [andamento](docs/andamento.md), identidades no [catálogo](registros/catalogo_estudos.json). O prazo informado em03/11 foi quatro dias para desenvolvimento e duas semanas para redação; não consumir a redação perseguindo um resultado positivo obrigatório.

## Fechamentos preservados

- [Astra002](docs/resultados_busca_astra_002.md):12receitas,100ajustes conferidos; sem finalista e sem novos backtests.
- [F03](docs/resultados_revisao_operacional.md):1.200carteiras conferidas,zero treino; limites de execução e contribuição dos lados explícitos.
- [F02](docs/resultados_smart_mercados.md):1.632carteiras; [F01](docs/resultados_futuros.md):804carteiras,ambas sem treino.
- [Astra versus crua/Huber](docs/resultados_comparacao_astra_crua.md), demais hipóteses e estudos preliminares: referências próprias no catálogo, sem reexecução ou promoção automática.

A navegação separa as linhas sem mover pacotes/artefatos congelados. [Registro de experimentos](docs/registro_de_experimentos.md) e [preservação](docs/armazenamento_e_reproducao.md) regem novas execuções. O recibo desta organização conserva a versão anterior deste plano e dos demais documentos editoriais em `registros/operacional_futuros/organizacao/`.
