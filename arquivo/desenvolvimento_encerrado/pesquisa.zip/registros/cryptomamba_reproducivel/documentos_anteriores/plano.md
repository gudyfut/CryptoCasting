# Plano de trabalho

Atualizado em05/11/2026. A etapa vigente é a **referência CryptoMamba diária adaptada a futuros de24h**, autorizada pelo pesquisador e preparada sob identidade `6de6464912e674da1540`. Consultar o [estado verificável](registros/cryptomamba_diario/estado.json), o [protocolo](docs/protocolo_cryptomamba_diario.md) e a [ADR0031](docs/adr/0031-cryptomamba-diario-futuros.md). **Interrompida em 05/11 às 13:38 de Brasília no controle de reprodução**, após dois ajustes completos; sem teste de 2025 ou carteiras. Ver diagnóstico na [cronologia](docs/andamento.md).

## Rodada atual

- BTCUSDT perpétuoUSD-M,Binance;2020–2023treino,2024validação,2025teste retrospectivo. Divisão fixa4:1:1, não walk-forward.
- Contexto14candles diários, entrada pública timestamp+OHLCV,volume/1e9;sem padronização externa.
- NúcleoCryptoMamba sem adapter:3×4blocos,estado64,larguras14/16/32/1;Adam0,01,StepLR100/0,5,1000épocas,lote32,RMSEdepreço.
- Preço do próximo fechamento convertido em variação prevista para gerar sinal;posição comprada/vendida/caixa,entrada00:01UTC,saída24h depois,sem stop/take nesta referência.
-95%nocional,limiar0,20%fixo,custos/funding/latência e risco intraminuto.70carteiras em cenários predeterminados;sem calibrar política pelo lucro do teste.
- Três seeds42/17/2026+controle42,total4ajustes.Controle antes das outras seeds;checkpoint porRMSEglobal de validação e recarga exata;teste só após todos os ajustes.

## Próximo passo técnico

Isolar a origem da divergência de gradientes e qualificar uma solução de reprodução em versão separada. Preservar a tentativa interrompida e suas tolerâncias; não retomar automaticamente nem interpretar controle como seed independente. A sonda de diagnóstico não atualizou pesos e não treinou novos modelos de mercado.

## Leitura prevista após uma execução válida

1. Conferir cobertura,controle,checkpoints,métricas,ledgers e preservação.
2. Comparar médias individuais das três seeds,ensemble separado,Naive e posições constantes no mesmo executor/calendário;relatar retorno,drawdown,exposição,custos,incerteza e cada lado.
3. Avaliar a utilidade da referência diária, sem comparação causal direta com os payoffs anteriores de2023.
4. Somente após a leitura, propor e autorizar uma mudança identificada. Nenhuma busca automática, seis meses, outras moedas, modelos ou limiares está autorizada nesta rodada.

A investigação anterior de histórico acumulado versus12meses foi encerrada, com previsões ligeiramente piores e perdas menores nos12meses,sem superioridade confirmada. Evidências no [andamento](docs/andamento.md). Estudos e explorações anteriores permanecem preservados. A proposta ampla anterior foi substituída por esta etapa; seu snapshot editorial está em `registros/cryptomamba_diario/documentos_anteriores/plano.md`.
