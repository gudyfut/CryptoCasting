"""Qualifica apenas a continuacao administrativa; nenhum treino ou consulta real."""
import ast
import copy
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from infraestrutura.artefatos import salvar_json
from experimentos.busca_astra.contrato import REFERENCIA,SEEDS,DESENVOLVIMENTO,chave_receita
from manutencao.retomar_busca_astra_001 import Retomada

class TestRetomada(unittest.TestCase):
    def test_sufixo_cientifico_identico(self):
        a=ast.parse(Path('experimentos/busca_astra/ciclo.py').read_text(encoding='utf-8'))
        b=ast.parse(Path('manutencao/retomar_busca_astra_001.py').read_text(encoding='utf-8'))
        def extrair(tree,classe):
            cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==classe)
            fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='executar')
            # Todo o fluxo a partir do ranking/promocao deve ser identico.
            start=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.If) and ast.unparse(n.test)=='not self.candidatas')
            for n in ast.walk(fn):
                if isinstance(n,ast.ImportFrom) and n.module=='publicacao' and n.level==1:
                    n.module='experimentos.busca_astra.publicacao';n.level=0
            return [ast.dump(n,include_attributes=False) for n in fn.body[start:]]
        self.assertEqual(extrair(a,'Coordenador'),extrair(b,'Retomada'))

    def rodar(self,ganho):
        with tempfile.TemporaryDirectory() as tmp:
            c=Retomada.__new__(Retomada);c.p=Path(tmp);c.ptr={}
            c.f={'ambiente_coordenador':{'codex':'fake'},'configuracao':{'selecao':{}}}
            c.inicio=0;c.limite=10**12;c.triagem_fim=10**12;c.jobs=[{}]*19
            receitas=[dict(REFERENCIA,contexto=24,estado=e,dropout=d) for e in [8,16,32,64] for d in [0.,.1,.2]]
            def resultado(r,b,s):return {'bloco':b,'seed':s,'parametros':100,'validacao':{'mse':1. if r==REFERENCIA else ganho,'mse_naive':1.}}
            c.ref=[resultado(REFERENCIA,b,s) for b in DESENVOLVIMENTO for s in SEEDS[:3]]
            c.candidatas=[{'id':f'C{i+1:02}_{chave_receita(r)}','proposta':{'receita':r},'resultados':[resultado(r,b,42) for b in DESENVOLVIMENTO],'score_triagem':(ganho,0.,ganho)} for i,r in enumerate(receitas[:6])]
            anteriores=copy.deepcopy(c.candidatas);novos=[];consultas=[]
            salvar_json(c.p/'diagnostico_desenvolvimento.json',{})
            def ajuste(r,b,s,g,controle=False):
                novos.append((b,s,g,controle));c.jobs.append({})
                self.assertNotEqual(g,'desenvolvimento/referencia')
                self.assertNotEqual(g,'controles/referencia')
                self.assertFalse(any(g=='desenvolvimento/'+a['id'] and s==42 for a in anteriores))
                return resultado(r,b,s)
            def consulta(p,contexto,**kw):
                consultas.append(p.name)
                return {'acao':'experimentar','receita':receitas[6+len(consultas)-1]}
            with patch.object(c,'ajuste',side_effect=ajuste),patch.object(c,'estado'),patch.object(c,'checar'), \
                 patch.object(c,'encerrar',side_effect=lambda s,m:s), \
                 patch('manutencao.retomar_busca_astra_001.consultar',side_effect=consulta), \
                 patch('manutencao.retomar_busca_astra_001.controle_cpu',return_value={}), \
                 patch('experimentos.busca_astra.publicacao.publicar') as pub:
                status=c.executar()
            return c,novos,consultas,status,pub.call_count

    def test_reutiliza19_teto12consultas_e106ajustes(self):
        c,novos,consultas,status,pub=self.rodar(.9)
        self.assertEqual(consultas,['08','09','10','11','12'])
        self.assertEqual(len(c.jobs),106)
        self.assertEqual(len(c.candidatas),11)
        self.assertEqual(pub,1);self.assertEqual(status,'concluido_conferido')
        ctrl=next(i for i,x in enumerate(novos) if x[2]=='controles/finalista')
        self.assertEqual(novos[ctrl-1],('B1',42,'final/candidata',False))
        self.assertEqual(novos[ctrl+1],('B1',17,'final/candidata',False))

    def test_sem_ganho_sem_teste_final(self):
        c,novos,consultas,status,pub=self.rodar(1.1)
        self.assertEqual(len(c.jobs),41);self.assertEqual(pub,0)
        self.assertFalse(any(x[0].startswith('B') for x in novos))
        self.assertEqual(status,'concluido_sem_finalista')

if __name__=='__main__':unittest.main()
