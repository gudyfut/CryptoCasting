"""Atualizar o relatório único a partir da consolidação conferida; sem treino."""
from infraestrutura.artefatos import RAIZ,ler_json,sha256,conferir_arquivos,salvar_json,agora


def numero(v,n=3):return f'{v:.{n}f}'.replace('.',',')
def pct(v,n=3):return f'{v*100:+.{n}f}%'.replace('.',',')


def relatar():
    ponteiro=ler_json(RAIZ/'registros/complemento_estado16/comparacao_atual.json');conferir_arquivos(RAIZ,{ponteiro['arquivo']:ponteiro['sha256']})
    r=ler_json(RAIZ/ponteiro['arquivo']);p=ler_json(RAIZ/'registros/complemento_estado16/execucao.json')
    audit=ler_json(RAIZ/'registros/complemento_estado16/conferencia_conclusao.json');conferir_arquivos(RAIZ,{audit['arquivo']:audit['sha256']})
    assert ler_json(RAIZ/audit['arquivo'])['status']=='aprovado'
    linhas=['# Estados internos8/16/32/64 — comparação em seis seeds',
        '', 'Atualização em29/10/2026 após completar o estado16. Todos os estados agora têm as mesmas seis seeds. O quadro anterior foi preservado em [snapshot documental](../registros/complemento_estado16/documentos_antes/docs/resultados_estados32_64.md) e sua [consolidação original](../registros/estados_ampliados/comparacao_atual.json) permanece intacta. O [relatório estado8](resultados_estado_mamba.md) continua como fechamento específico daquela extensão.',
        '', '## Identidade e desenho', '', '| Estado | Execução | Seeds | Parâmetros |','|---|---|---|---:|',
        '| 8 | `dcf4b0ed9012f7247bce` | 17,42,2026,7,123,31415 | 17.185 |',
        f'| 16 | R0 `ab5baf3eab3a2e66d8b2` + complemento `{p["id"]}` | 17,42,2026 herdadas;7,123,31415 novas | 20.257 |',
        '| 32 | `23c2ba54349bcc1b0ee1` | 17,42,2026,7,123,31415 | 26.401 |',
        '| 64 | `42cb667ea43df563e3ac` | 17,42,2026,7,123,31415 | 38.689 |',
        '', 'Mesmas entradas OHLCV transformadas, dataset/escalas, BTC/1h, contexto168h, alvo log-retorno terminal24h, treino2021–2023/validação2024/teste2025, origens/purga, pré-LayerNorm, largura32/duas camadas, AdamW e seleção por menor MSE de validação. Somente d_state difere entre arquiteturas; também muda o número de parâmetros. A mesma seed não produz tensores idênticos em dimensões diferentes.',
        '', 'As médias são aritméticas das métricas por seed, inclusive RMSE; não ensemble, carteira combinada ou raiz do MSE médio. Cada seed mantém seu próprio checkpoint selecionado exclusivamente na validação. O complemento executou somente três novos ajustes reais, sem refazer as três seeds R0. Nenhum resultado negativo foi descartado.',
        '', 'A sequência32→64 foi congelada antes do primeiro treino32 e encerrada/conferida às19:01:21UTC de29/10. O complemento16 foi decidido depois da consulta a esses resultados, sob [protocolo próprio](protocolo_complemento_estado16.md). Os períodos2024/2025 são retrospectivos; completar seeds não cria confirmação independente.',
        '', '## Como ler', '', 'MSE, RMSE e MAE: menor é melhor. Habilidade =1−MSE_modelo/MSE_Naive: positiva indica menor erro que prever retorno zero; negativa indica erro maior. MAE/RMSE×100 são pontos de log-retorno, aproximadamente pontos percentuais para variações pequenas, não probabilidades. Acerto balanceado dá o mesmo peso às duas direções e50% é referência de discriminação fraca. Precisão do preço terminal e resultado de uma operação são eixos distintos.']
    for grupo,titulo in [('tres_seeds','Média das três seeds originais:17/42/2026'),('seis_seeds','Média das seis seeds:17/42/2026/7/123/31415')]:
        es=r['grupos'][grupo]['estados']
        linhas+=['',f'## {titulo}','','| Estado | MSE validação ↓ | MSE teste ↓ | Habilidade validação | Habilidade teste | MAE teste×100 ↓ | RMSE teste×100 ↓ |', '|---|---:|---:|---:|---:|---:|---:|']
        for n,g in es.items():
            v,t=g['predicao']['validacao'],g['predicao']['teste']
            linhas.append(f'| {n} | {numero(v["mse"],9)} | {numero(t["mse"],9)} | {pct(v["habilidade_mse"])} | {pct(t["habilidade_mse"])} | {numero(t["mae"]*100,4)} | {numero(t["rmse"]*100,4)} |')
        linhas+=['','| Estado | Acerto direção | Acerto balanceado | Desvio MSE entre seeds (×10⁻⁶) | Seeds com MSE menor que Naive |','|---|---:|---:|---:|---:|']
        for n,g in es.items():
            t=g['predicao']['teste'];linhas.append(f'| {n} | {pct(t["acuracia_direcional"],2)} | {pct(t["acerto_balanceado_direcional"],2)} | {numero(t["desvio_padrao_mse_seeds"]*1e6,2)} | {t["seeds_melhores_naive"]}/{g["n_seeds"]} |')
    seis=r['grupos']['seis_seeds']['estados'];tres=r['grupos']['tres_seeds']['estados']
    ordem=sorted(seis,key=lambda n:seis[n]['predicao']['teste']['mse'])
    m16=seis['16']['predicao']['teste'];m16antes=tres['16']['predicao']['teste']
    linhas+=['','## Interpretação da média completa','',
        'Ordem do menor para o maior MSE médio nas seis seeds: **'+', '.join('estado'+n for n in ordem)+'**. Essa é a ordem observada nesta população, não uma escolha confirmatória de configuração ótima.',
        '',f'O estado16 passou de habilidade {pct(m16antes["habilidade_mse"])} nas três seeds originais para {pct(m16["habilidade_mse"])} nas seis. A mudança da média decorre exclusivamente das três seeds acrescentadas; os resultados originais não mudaram. Dispersão MSE do16 nas seis seeds: {numero(m16["desvio_padrao_mse_seeds"]*1e6,2)}×10⁻⁶.']
    for n in ('8','32','64'):
        a,b=sorted((16,int(n)));d=r['contrastes']['seis_seeds']['teste'][f'estado{b}_menos_estado{a}']
        variacao=100*(m16['mse']/seis[n]['predicao']['teste']['mse']-1)
        linhas+=['',f'Estado16 contra{n}: {numero(variacao,3)}% de variação do MSE; '+('o intervalo temporal14 dias inclui zero, portanto a diferença é inconclusiva.' if d['ic14_inclui_zero'] else 'o intervalo temporal14 dias exclui zero; interpretar o sentido observado junto dos limites exploratórios.')]
    naive=r['referencias']['naive']['teste'];arima=r['referencias']['arima']['teste']
    lstm=sum(r['referencias'][f'lstm_{s}']['teste']['mse'] for s in (17,42,2026))/3
    linhas+=['',f'Referências herdadas, sem novo ajuste: Naive MSE={numero(naive["mse"],9)}; ARIMA MSE={numero(arima["mse"],9)}; LSTM média de três seeds MSE={numero(lstm,9)}. LSTM não tem seis seeds e não deve ser apresentada como comparação pareada de seis.',
        '', 'Todas as médias dos quatro estados têm MSE maior que Naive.' if all(g['predicao']['teste']['habilidade_mse']<0 for g in seis.values()) else 'Comparar a habilidade contra Naive e sua incerteza antes de atribuir ganho preditivo às diferenças numéricas.',
        '', 'Todas as médias líquidas Spot permanecem negativas.' if all(g['operacao']['base']['retorno_liquido']<0 for g in seis.values()) else 'Os resultados operacionais devem ser lidos separadamente do ranking de MSE; média líquida positiva por si só não comprova robustez operacional.']
    linhas+=['','## Incerteza pareada','','Todos os pares foram calculados a partir das perdas alinhadas por origem, primeiro fazendo a média nas mesmas seeds. Bootstrap circular em dias7/14/28,2.000 réplicas, principal14. São contrastes exploratórios condicionais aos modelos; sem correção global para multiplicidade/seleção adaptativa. As seeds não são amostras independentes do mercado. Inconclusão não comprova igualdade. Os ICs são de diferença de MSE, não de retorno financeiro.',
        '', '| Grupo | Contraste | Variação do MSE | IC14 da diferença de MSE | Inclui zero? |','|---|---|---:|---|---|']
    for grupo in ('tres_seeds','seis_seeds'):
        for par,d in r['contrastes'][grupo]['teste'].items():
            a,b=d['ic95']['14'];linhas.append(f'| {3 if grupo=="tres_seeds" else 6} | {par.replace("_menos_"," contra ")} | {numero(d["aumento_mse_percentual_observado"],3)}% | [{a:.8g}; {b:.8g}] | {"Sim" if d["ic14_inclui_zero"] else "Não"} |')
    linhas+=['','## Simulação Spot','','Política R0 preservada: comprado/caixa, decisões00UTC, entrada um minuto depois, saída24h depois, capital10.000USDT, taxa0,10%/slippage0,05% por lado. Cenário agravado:0,20%/0,10%. Bruto usa os mesmos sinais da regra base com custos zerados; não busca limiar novo. Não é futuros nem reprodução de uma conta Binance. Sensibilidades posteriores de custos e manutenção de posição ficaram separadas.',
        '', 'Retorno e drawdown são médias dos resultados individuais, não retorno/risco de uma carteira média. Não se estimou IC de retorno nem significância financeira.']
    for grupo in ('tres_seeds','seis_seeds'):
        linhas+=['',f'### {3 if grupo=="tres_seeds" else 6} seeds','','| Estado | Bruto | Líquido base | Agravado | Drawdown médio | Operações médias | Seeds lucrativas |','|---|---:|---:|---:|---:|---:|---:|']
        for n,g in r['grupos'][grupo]['estados'].items():
            op=g['operacao'];b=op['base'];linhas.append(f'| {n} | {pct(op["bruto_mesmos_sinais"]["retorno_liquido"],2)} | {pct(b["retorno_liquido"],2)} | {pct(op["agravado"]["retorno_liquido"],2)} | {numero(b["drawdown"]*100,2)}% | {numero(b["entradas_planejadas"],1)} | {b["seeds_lucrativas"]}/{g["n_seeds"]} |')
    linhas+=['','## Estado16 por seed: rastreabilidade','','| Seed | Origem | MSE validação | MSE teste | Época selecionada | Retorno líquido Spot |','|---|---|---:|---:|---:|---:|']
    pub=ler_json(RAIZ/p['pasta']/'publicacao.json');pr=ler_json(RAIZ/p['pasta']/pub['pasta']/'resultados.json')
    for s in (17,42,2026,7,123,31415):
        k=f'estado16_{s}';d=pr['por_ajuste'][k];a=ler_json(RAIZ/d['tentativa_origem']/'resultado.json')
        linhas.append(f'| {s} | {"R0 preservada" if s in (17,42,2026) else "complemento novo"} | {numero(a["metricas"]["validacao"]["mse"],9)} | {numero(a["metricas"]["teste"]["mse"],9)} | {a["epoca_selecionada"]} | {pct(d["spot"]["base"]["retorno_liquido"],2)} |')
    d=pr['contrastes']['teste']['estado16_seis_menos_naive'];a,b=d['ic95']['14']
    linhas+=['',f'Comparação estado16/seis seeds contra Naive: diferença de MSE={d["diferenca_mse_a_menos_b"]:.8g}, IC14=[{a:.8g}; {b:.8g}]. O intervalo inclui zero; não há ganho preditivo demonstrado contra Naive. As sensibilidades7/28 também incluem zero. A média numericamente pior não comprova inferioridade estatística.']
    linhas+=['','## Complexidade e períodos','','| Estado | Parâmetros | Tempo médio3 seeds | Tempo médio6 seeds | Épocas médias6 seeds |','|---|---:|---:|---:|---:|']
    for n in ('8','16','32','64'):
        t3=r['grupos']['tres_seeds']['estados'][n]['treinamento'];t=r['grupos']['seis_seeds']['estados'][n]['treinamento']
        linhas.append(f'| {n} | {int(t["parametros"])} | {numero(t3["segundos"],0)}s | {numero(t["segundos"],0)}s | {numero(t["epocas_executadas"],1)} |')
    linhas+=['','Tempos incluem quantidades diferentes de épocas e não são benchmark puro por época/kernel. As execuções ocorreram em momentos distintos, no mesmo ambiente qualificado.',
        '', '| Estado / habilidade contra Naive nas seis seeds | Trimestre1 | Trimestre2 | Trimestre3 | Trimestre4 |','|---|---:|---:|---:|---:|']
    for n,g in r['grupos']['seis_seeds']['estados'].items():linhas.append('| '+n+' | '+' | '.join(pct(g['trimestres'][str(t)]['habilidade_naive'],2) for t in range(1,5))+' |')
    linhas+=['','Não selecionar somente trimestres/seed favoráveis.','', '![Médias dos quatro estados em três e seis seeds](figuras/estados_ampliados/medias_estados_seis_completas.png)',
        '', '## Evidências e limites','',f'O complemento `{p["id"]}` contém três ajustes novos e26 heranças. [Autorização](../registros/complemento_estado16/autorizacao.json), [estado](../registros/complemento_estado16/estado.json), [conferência](../{audit["arquivo"]}) e [consolidação verificável](../registros/complemento_estado16/comparacao_atual.json) vinculam fontes, checkpoints, previsões, médias, contrastes e simulação. A falha de integração do verificador, corrigida antes do congelamento/mercado, está em [ocorrências](../registros/complemento_estado16/ocorrencias_preparacao.json); qualificação anterior e nova foram preservadas.',
        '', 'R0 e32/64/8 continuam intactos, incluindo protocolos e publicações originais. Auditoria posterior confere hashes, cobertura, checkpoints/capacidade, seleção e métricas; recarga preditiva e simulação são atestadas pelo executor/publicação. O complemento teve reprodução sintética e recarga exata, sem repetição completa real adicional. Não comprova backup remoto ou aceite acadêmico.',
        '', 'O conjunto continua uma divisão temporal fixa de exploração, não walk-forward. Um teste retrospectivo conhecido e seis seeds não estabelecem configuração ótima universal nem execução economicamente útil. Próxima alteração requer hipótese/orçamento/identidade e autorização próprios.']
    (RAIZ/'docs/resultados_estados32_64.md').write_text('\n'.join(linhas)+'\n',encoding='utf-8')
    salvar_json(RAIZ/'registros/complemento_estado16/relatorio.json',{'utc':agora(),'fonte':ponteiro,'arquivo':'docs/resultados_estados32_64.md','sha256':sha256(RAIZ/'docs/resultados_estados32_64.md'),'gerador_sha256':sha256(__file__)})


if __name__=='__main__':relatar()
