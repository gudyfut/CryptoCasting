"""Figura das médias por seed; dados consolidados, sem inferência ou treinamento."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from infraestrutura.artefatos import RAIZ,ler_json,salvar_json,sha256,agora


if __name__=='__main__':
    ponteiro=ler_json(RAIZ/'registros/complemento_estado16/comparacao_atual.json')
    fonte=RAIZ/ponteiro['arquivo'];r=ler_json(fonte)
    pasta=RAIZ/'docs/figuras/estados_ampliados';pasta.mkdir(parents=True,exist_ok=True)
    if (pasta/'medias_estados_seis_completas.png').exists():raise FileExistsError('Figura já existe; preservar versão.')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    cores={'8':'#417FB1','16':'#1E536F','32':'#D68B32','64':'#AD4F4F'}
    fig,axes=plt.subplots(2,2,figsize=(11.5,7.5))
    for col,(grupo,titulo) in enumerate([('tres_seeds','3 seeds comuns · estados 8 / 16 / 32 / 64'),('seis_seeds','6 seeds comuns · estados 8 / 16 / 32 / 64')]):
        estados=r['grupos'][grupo]['estados'];nomes=list(estados);x=np.arange(len(nomes))
        for linha in (0,1):
            ax=axes[linha,col]
            valores=[100*estados[n]['predicao']['teste']['habilidade_mse'] if linha==0 else 100*estados[n]['operacao']['base']['retorno_liquido'] for n in nomes]
            barras=ax.bar(x,valores,color=[cores[n] for n in nomes],width=.6,zorder=3)
            ax.axhline(0,color='#555',linewidth=.8);ax.grid(axis='y',color='#E2E5EA');ax.set_axisbelow(True)
            ax.set_xticks(x,[f'Estado {n}' for n in nomes])
            for barra,v in zip(barras,valores):
                ax.annotate(f'{v:+.2f}%'.replace('.',','),(barra.get_x()+barra.get_width()/2,v),
                    xytext=(0,-12),textcoords='offset points',ha='center',fontsize=10)
            ax.set_ylim((-3,.1) if linha==0 else (-25,1))
        axes[0,col].set_title(titulo,loc='left',fontsize=11,pad=13)
    axes[0,0].set_ylabel('Redução do MSE contra Naive (%)\nMaior é melhor')
    axes[1,0].set_ylabel('Retorno líquido Spot (%)\nMédia dos resultados individuais')
    fig.suptitle('Tamanho do estado interno: previsão e operação',x=.065,y=.985,ha='left',fontsize=16,fontweight='bold')
    fig.text(.065,.02,'Teste 2025 retrospectivo · mesma política R0 · médias de métricas/resultados, não ensemble ou carteira · barras sem IC',fontsize=9,color='#555')
    fig.subplots_adjust(left=.1,right=.98,top=.87,bottom=.1,wspace=.24,hspace=.38)
    for e in ('png','pdf'):fig.savefig(pasta/f'medias_estados_seis_completas.{e}',dpi=170,facecolor='white',bbox_inches='tight')
    salvar_json(RAIZ/'registros/complemento_estado16/figuras_consolidadas.json',{'utc':agora(),'fonte':ponteiro,
        'verificador':'manutencao/figuras_complemento16.py','verificador_sha256':sha256(__file__),
        'arquivos':{f'docs/figuras/estados_ampliados/medias_estados_seis_completas.{e}':sha256(pasta/f'medias_estados_seis_completas.{e}') for e in ('png','pdf')}})
    print(pasta/'medias_estados_seis_completas.png')
