"""Sensibilidade posterior de giro, preservando dias de exposição e sinais R0."""
from infraestrutura.artefatos import RAIZ,ler_json
from manutencao.auditar_ohlcv_execucao import capital_recebido
import math


def analisar():
    pasta=RAIZ/'dados/experimentos/ohlcv_modular_ab5baf3eab3a2e66d8b2/publicacoes/tentativa_001'
    resultados=ler_json(pasta/'resultados.json');res={}
    for chave,r in resultados['por_ajuste'].items():
        ops=ler_json(pasta/chave/'operacoes_base.json');grupos=[]
        for o in ops:
            if grupos and grupos[-1]['saida_minuto']==o['entrada_minuto']:
                assert grupos[-1]['preco_saida']==o['preco_entrada']
                grupos[-1]['saida_minuto']=o['saida_minuto'];grupos[-1]['preco_saida']=o['preco_saida']
            else:grupos.append(dict(o))
        assert math.isclose(capital_recebido(ops,0,0),capital_recebido(grupos,0,0),rel_tol=1e-12)
        res[chave]={'dias_com_sinal':len(ops),'episodios_contiguos':len(grupos),
            'retorno_base_compra_diaria_publicado':r['spot']['base']['retorno_liquido'],
            'retorno_mesmos_dias_mantendo_posicao_entre_sinais_contiguos':capital_recebido(grupos,.001,.0005)/10000-1,
            'retorno_taxa0075_slippage001_mantendo_posicao':capital_recebido(grupos,.00075,.0001)/10000-1}
    return res


if __name__=='__main__':
    esperado=ler_json(RAIZ/'registros/estado_mamba/sensibilidade_giro_sinais_fixos.json')['por_ajuste']
    atual=analisar()
    assert atual==esperado
    print('Diagnóstico de giro reproduzido; não modifica resultados publicados ou sinais.')
