"""Diagnóstico retrospectivo de origens horárias/diárias; sem treino ou seleção."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import shutil
import sys

import numpy as np
import pandas as pd

RAIZ = Path(__file__).resolve().parents[1]
REFERENCIA = RAIZ / 'dados/experimentos/retorno24_1e7c5ed662fba55ddd25'
CORRIGIDO = RAIZ / 'dados/experimentos/penalizacao_7868a4d847c1410fc681'
DATASET = RAIZ / 'dados/processados/retorno24_d25f6a93a9900725f51e'


def ler(caminho):
    return json.loads(Path(caminho).read_text(encoding='utf-8-sig'))


def sha(caminho):
    return hashlib.sha256(Path(caminho).read_bytes()).hexdigest()


def resumir(y, p):
    erro = p - y
    return {'n': len(y), 'mse': float(np.mean(erro**2)),
            'mse_naive': float(np.mean(y**2)), 'mae': float(np.mean(abs(erro))),
            'energia_previsao': float(np.mean(p**2)),
            'alinhamento_duplo': float(2 * np.mean(y*p)),
            'media_previsao': float(p.mean()), 'desvio_previsao': float(p.std()),
            'desvio_alvo': float(y.std()),
            'acerto_direcional': float(np.mean(np.sign(y) == np.sign(p)))}


def intervalo(diferencas, dias=14, replicas=2000, seed=20261020):
    gerador = np.random.default_rng(seed)
    medias = np.zeros(replicas)
    for valores in diferencas:
        n = len(valores)
        tamanho = min(dias, n)
        inicios = gerador.integers(0, n-tamanho+1, size=(replicas, int(np.ceil(n/tamanho))))
        indices = (inicios[:, :, None] + np.arange(tamanho)).reshape(replicas, -1)[:, :n]
        # NaN preserva dias sem origem comum observável; não comprimir o calendário.
        amostra = valores[indices]
        assert np.isfinite(amostra).any(axis=1).all()
        medias += np.nanmean(amostra, axis=1) / len(diferencas)
    return {'bloco_dias': dias, 'replicas': replicas,
            'inferior': float(np.quantile(medias, .025)),
            'superior': float(np.quantile(medias, .975))}


def executar(destino):
    c = ler(REFERENCIA / 'execucao.json')['assinatura']['configuracao']
    cortes = {
        'DB1': ('2022-10-01', '2023-01-01', '2023-04-01'),
        'DB2': ('2023-01-01', '2023-04-01', '2023-07-01'),
        'DB3': ('2023-04-01', '2023-07-01', '2023-10-01'),
        'DB4': ('2023-07-01', '2023-10-01', '2024-01-01'),
        'B1': ('2023-10-01', '2024-01-01', '2024-07-01'),
        'B2': ('2024-04-01', '2024-07-01', '2025-01-01'),
        'B3': ('2024-10-01', '2025-01-01', '2025-07-01'),
        'B4': ('2025-04-01', '2025-07-01', '2026-01-01')}
    fontes = {}

    def registrar(p):
        relativo = Path(p).relative_to(RAIZ).as_posix()
        fontes.setdefault(relativo, sha(p))

    for base in (REFERENCIA, CORRIGIDO):
        e = ler(base / 'execucao.json')
        registrar(base / 'execucao.json')
        for nome, esperado in e['assinatura']['fontes'].items():
            for p in (RAIZ/nome, base/'fontes'/nome):
                assert sha(p) == esperado, p
                registrar(p)
    observavel = np.load(DATASET / 'observavel_comum.npy')
    registrar(DATASET / 'observavel_comum.npy')
    horas = {}
    particoes, contagens, autocorrelacoes = {}, [], []
    for moeda in c['pares']:
        p = DATASET / moeda / 'horas.parquet'
        q = pd.read_parquet(p); registrar(p); horas[moeda] = q
        assert (q.destino_utc - q.origem_utc).eq(pd.Timedelta(hours=24)).all()
        assert q.origem_utc.diff().dropna().eq(pd.Timedelta(hours=1)).all()
        assert np.array_equal(q.indice_hora.to_numpy(), np.arange(len(q)))
        np.testing.assert_allclose(q.alvo, np.log(q.close.shift(-24)/q.close), rtol=0, atol=1e-14, equal_nan=True)
        np.testing.assert_allclose(q.retorno, np.log(q.close/q.close.shift(1)), rtol=0, atol=1e-14, equal_nan=True)
        causal = q.retorno.notna().rolling(336, min_periods=336).sum().eq(336)
        np.testing.assert_array_equal(causal, q.causal)
        for bloco, datas in cortes.items():
            fronteiras = [pd.Timestamp(x, tz='UTC') for x in ('2021-01-01', *datas)]
            for nome, a, b in zip(('treino', 'validacao', 'teste'), fronteiras[:-1], fronteiras[1:]):
                amostra = q.loc[q.origem_utc.ge(a) & q.destino_utc.lt(b) & observavel].copy()
                assert amostra.destino_utc.max() < b
                particoes[moeda, bloco, nome] = amostra
                contagens.append({'moeda': moeda, 'bloco': bloco, 'particao': nome,
                                  'origens_horarias': len(amostra),
                                  'origens_00_utc': int(amostra.origem_utc.dt.hour.eq(0).sum())})
        for fase, a, b in [('desenvolvimento', '2023-01-01', '2024-01-01'), ('avaliacao', '2024-01-01', '2026-01-01')]:
            # Calendário intacto, pares finitos por lag; sem juntar pontas de lacunas.
            amostra = q.loc[q.origem_utc.ge(pd.Timestamp(a, tz='UTC')) & q.destino_utc.lt(pd.Timestamp(b, tz='UTC'))]
            diario = amostra.loc[amostra.origem_utc.dt.hour.eq(0), 'alvo']
            autocorrelacoes.append({'fase': fase, 'moeda': moeda,
                                   'alvo24_lag1h': float(amostra.alvo.autocorr(1)),
                                   'alvo24_lag24h': float(amostra.alvo.autocorr(24)),
                                   'alvo24_diario_lag1dia': float(diario.autocorr(1))})
    np.testing.assert_array_equal(observavel, np.logical_and.reduce([q.observavel.to_numpy() for q in horas.values()]))
    linhas, epocas, diarios, origens_referencia = [], [], {}, {}
    contagem = Counter()
    for base, sufixo in ((REFERENCIA, 'original'), (CORRIGIDO, 'corrigido')):
        for tentativa in sorted((base / 'celulas').glob('*/tentativa_*/tentativa.json')):
            estado = ler(tentativa)
            if estado['status'] != 'auditada':
                continue
            celula = estado['celula']; moeda, bloco = celula['par'], celula['fold']
            nome = celula['modelo']
            modelo = f'mamba_{sufixo}' if nome == 'mamba' else nome
            fase = 'desenvolvimento' if bloco.startswith('DB') else 'avaliacao'
            chave = (modelo, moeda, bloco, celula.get('contexto'), celula.get('seed'))
            assert chave not in origens_referencia
            origens_referencia[chave] = True
            registrar(tentativa)
            p = tentativa.parent / 'previsoes_teste.parquet'
            auditoria = ler(tentativa.parent / 'auditoria.json')
            assert sha(p) == auditoria['arquivos'][p.name]
            registrar(p); registrar(tentativa.parent / 'auditoria.json')
            q = pd.read_parquet(p)
            esperado = particoes[moeda, bloco, 'teste']
            np.testing.assert_array_equal(q.indice_hora, esperado.indice_hora)
            np.testing.assert_array_equal(q.origem_utc, esperado.origem_utc)
            np.testing.assert_allclose(q.alvo, esperado.alvo, rtol=0, atol=1e-14)
            resultado = ler(tentativa.parent / 'resultado.json'); registrar(tentativa.parent / 'resultado.json')
            referencia = {'fase': fase, 'modelo': modelo, **{k:celula.get(k) for k in ('par','fold','contexto','seed')}}
            for hora in [-1, *range(24)]:
                mascara = np.ones(len(q), bool) if hora == -1 else q.origem_utc.dt.hour.to_numpy() == hora
                y, pred = q.alvo.to_numpy()[mascara], q.previsao.to_numpy()[mascara]
                assert len(y) and np.isfinite(pred).all()
                metrica = resumir(y, pred)
                linhas.append({**referencia, 'hora_utc': hora, **metrica})
                if hora == -1:
                    assert abs(metrica['mse'] - resultado['metricas']['teste']['mse']) < 1e-14
                    np.testing.assert_allclose(metrica['mse']-metrica['mse_naive'],
                                               metrica['energia_previsao']-metrica['alinhamento_duplo'], atol=1e-14)
                if hora == 0:
                    datas = pd.DatetimeIndex(q.loc[mascara, 'origem_utc']).normalize()
                    serie = pd.Series((pred-y)**2, index=datas)
                    diarios.setdefault((fase, bloco, modelo), []).append(serie)
            if nome in ('mamba', 'lstm'):
                caminho = tentativa.parent / 'epocas.json'; historico = ler(caminho); registrar(caminho)
                melhor = min(historico, key=lambda x: x['mse_validacao'])
                assert melhor['epoca'] == resultado['epoca_selecionada']
                assert len(historico) == resultado['epocas_executadas']
                assert all(np.isfinite(x['mse_validacao']) and np.isfinite(x['mse_treino_padronizado']) for x in historico)
                assert len(historico) <= c['treino']['epocas']
                if len(historico) < c['treino']['epocas']:
                    assert len(historico)-melhor['epoca'] == c['treino']['paciencia']
                yv = particoes[moeda, bloco, 'validacao'].alvo.to_numpy()
                epocas.append({**referencia, 'selecionada': melhor['epoca'], 'executadas': len(historico),
                    'treino_primeira': historico[0]['mse_treino_padronizado'],
                    'treino_ultima': historico[-1]['mse_treino_padronizado'],
                    'validacao_primeira': historico[0]['mse_validacao'],
                    'validacao_melhor': melhor['mse_validacao'], 'validacao_ultima': historico[-1]['mse_validacao'],
                    'mse_naive_validacao': float(np.mean(yv**2)),
                    'melhor_vence_naive_validacao': melhor['mse_validacao'] < np.mean(yv**2)})
            contagem[modelo] += 1
            if sum(contagem.values()) % 100 == 0:
                print(f'{sum(contagem.values())} resultados conferidos', flush=True)
    assert dict(contagem) == {'lstm':384, 'mamba_original':384, 'naive':32, 'arima':32, 'mamba_corrigido':384}, dict(contagem)
    quadro = pd.DataFrame(linhas)
    quadro.to_csv(destino/'metricas_por_origem_e_ajuste.csv', index=False)
    medias = quadro.groupby(['fase','modelo','hora_utc'], as_index=False)[list(resumir(np.array([0.,1.]),np.array([0.,1.])).keys())].mean()
    medias['indice_mse_naive_100'] = 100*medias.mse/medias.mse_naive
    medias.to_csv(destino/'resumo_frequencias.csv', index=False)
    pd.DataFrame(contagens).to_csv(destino/'populacoes.csv', index=False)
    pd.DataFrame(autocorrelacoes).to_csv(destino/'dependencia_alvos.csv', index=False)
    ee = pd.DataFrame(epocas); ee.to_csv(destino/'diagnostico_epocas.csv', index=False)
    resumos_epocas = []
    for (fase, modelo), g in ee.groupby(['fase','modelo']):
        resumos_epocas.append({'fase': fase, 'modelo': modelo, 'ajustes':len(g),
            'epoca_mediana':float(g.selecionada.median()), 'epoca_1':int(g.selecionada.eq(1).sum()),
            'ate_3':int(g.selecionada.le(3).sum()), 'executadas_mediana':float(g.executadas.median()),
            'atingiram_100':int(g.executadas.eq(100).sum()),
            'vence_naive_validacao':int(g.melhor_vence_naive_validacao.sum()),
            'treino_caiu_val_ultima_pior_que_primeira':int(((g.treino_ultima<g.treino_primeira)&(g.validacao_ultima>g.validacao_primeira)).sum()),
            'razao_treino_final_inicial_mediana':float((g.treino_ultima/g.treino_primeira).median())})
    contrastes = []
    for fase in ('desenvolvimento','avaliacao'):
        for a,b in [('mamba_corrigido','lstm'),('mamba_corrigido','naive'),('lstm','naive'),('mamba_corrigido','mamba_original')]:
            diferencas=[]
            for bloco in c[f'folds_{fase}']:
                sa=pd.concat(diarios[fase,bloco,a],axis=1)
                sb=pd.concat(diarios[fase,bloco,b],axis=1)
                assert not sa.isna().any().any() and not sb.isna().any().any()
                assert sa.index.equals(sb.index)
                calendario=pd.date_range(cortes[bloco][1],cortes[bloco][2],freq='D',inclusive='left',tz='UTC')
                diferencas.append((sa.mean(axis=1)-sb.mean(axis=1)).reindex(calendario).to_numpy())
            contraste={'fase':fase,'contraste':f'{a}_menos_{b}', 'hora_utc':0,
                       'diferenca_mse':float(np.mean([np.nanmean(v) for v in diferencas])),
                       'intervalos':[intervalo(diferencas,d) for d in (7,14,28)]}
            contraste['origens_diarias_unicas'] = int(sum(np.isfinite(v).sum() for v in diferencas))
            contrastes.append(contraste)
    with (destino/'fontes_lidas.json').open('w',encoding='utf-8') as f:
        json.dump(fontes,f,indent=2,ensure_ascii=False)
    return {'status':'concluido','resultados_conferidos':dict(contagem),
            'origens_primarias_diarias':'00:00 UTC, horário preexistente da política; 23 demais horários como sensibilidade, sem escolha.',
            'natureza':'Reavaliação retrospectiva dos modelos existentes; não estima efeito de retreinar com passo 24h.',
            'epocas':resumos_epocas,'contrastes_diarios':contrastes,
            'medias_horaria_e_diaria':medias.loc[medias.hora_utc.isin([-1,0])].to_dict('records'),
            'fontes_lidas_sha256':sha(destino/'fontes_lidas.json'),
            'limites':['Sem novo treinamento, inferência, busca ou simulação financeira.','IC temporal condicionado aos modelos; não inclui incerteza completa de seleção ou entre treinamentos.','Amostra diária reduz sobreposição dos alvos, mas não garante independência.']}


def main():
    destino=RAIZ/'registros/revisoes'/datetime.now(timezone.utc).strftime('frequencia_%Y-%m-%dT%H%M%S.%fZ')
    destino.mkdir(parents=True,exist_ok=False)
    shutil.copyfile(__file__,destino/'diagnostico.py')
    plano={'inicio_utc':datetime.now(timezone.utc).isoformat(),'host':platform.node(),
           'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,
           'metodo':'Todas as células; origens -1=horárias e 00..23 UTC; hora principal 00 já usada na simulação; médias iguais por moeda/contexto/bloco/seed; bootstrap pareado móvel 7/14/28 dias, 2000 réplicas, seed20261020, sem cruzar folds.',
           'intervencao':'Nenhuma; diagnóstico posterior sem alterar estudos congelados.'}
    (destino/'plano.json').write_text(json.dumps(plano,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Revisão: {destino}',flush=True)
    try:
        resultado=executar(destino)
    except Exception as erro:
        (destino/'falha.json').write_text(json.dumps({'erro':repr(erro),'utc':datetime.now(timezone.utc).isoformat()},indent=2),encoding='utf-8')
        raise
    resultado['fim_utc']=datetime.now(timezone.utc).isoformat()
    resultado['artefatos_sha256']={p.name:sha(p) for p in destino.iterdir() if p.is_file()}
    (destino/'resumo.json').write_text(json.dumps(resultado,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'status':resultado['status'],'recibo':str(destino/'resumo.json')},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
