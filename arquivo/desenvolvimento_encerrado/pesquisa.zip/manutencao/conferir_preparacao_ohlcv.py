"""Audita a preparação OHLCV por cálculo independente, sem treinar modelos."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
from previsao24.arquivos import RAIZ, agora, ler_json, salvar_json, sha256, verificar_arquivos


def conferir():
    ponteiro=ler_json(RAIZ/'registros/ohlcv/dataset.json')
    pasta=RAIZ/ponteiro['pasta']
    verificar_arquivos(pasta,{'dataset.json':ponteiro['sha256']})
    m=ler_json(pasta/'dataset.json')
    verificar_arquivos(pasta,m['arquivos'])
    verificar_arquivos(RAIZ,{m['minutos']:m['minutos_sha256']})
    h=pd.read_parquet(pasta/'horas.parquet')
    minutos=np.load(RAIZ/m['minutos'],mmap_mode='r',allow_pickle=False).reshape(-1,60,6)
    valido=np.isfinite(minutos).all(axis=(1,2))
    ohlcv=np.column_stack([minutos[:,0,0],np.max(minutos[:,:,1],axis=1),np.min(minutos[:,:,2],axis=1),
                          minutos[:,-1,3],np.sum(minutos[:,:,4],axis=1)])
    ohlcv[~valido]=np.nan
    np.testing.assert_array_equal(h[['open','high','low','close','volume']].to_numpy(),ohlcv)
    tempos=pd.to_datetime((m['primeiro_minuto']+(np.arange(len(h))+1)*60)*60,unit='s',utc=True)
    np.testing.assert_array_equal(h.origem_utc.to_numpy(),tempos.to_numpy())
    x=np.full((len(h),5),np.nan)
    x[1:,:4]=np.log(ohlcv[1:,:4]/ohlcv[:-1,3,None])
    x[:,4]=np.log1p(ohlcv[:,4]);x[~valido]=np.nan
    alvo=np.full(len(h),np.nan);alvo[:-24]=np.log(ohlcv[24:,3]/ohlcv[:-24,3])
    # log/std podem variar poucos ULP entre Windows/WSL; contagens e índices são exatos.
    np.testing.assert_allclose(alvo,h.alvo,rtol=1e-12,atol=1e-15,equal_nan=True)
    c=ler_json(RAIZ/'configuracoes/ohlcv24_001.json');w=c['contexto']
    ruins=np.r_[0,np.cumsum(~np.isfinite(x).all(axis=1))]
    causal=np.zeros(len(h),dtype=bool);causal[w-1:]=(ruins[w:]-ruins[:-w])==0
    for nome,(a,b) in c['divisao'].items():
        periodo=(tempos>=pd.Timestamp(a,tz='UTC'))&(tempos<pd.Timestamp(b,tz='UTC'))
        elegivel=periodo&causal&np.isfinite(alvo)&(tempos+pd.Timedelta(hours=24)<pd.Timestamp(b,tz='UTC'))
        q=pd.read_parquet(pasta/f'{nome}.parquet')
        np.testing.assert_array_equal(q.indice_hora,np.flatnonzero(elegivel))
        if nome=='teste':
            np.testing.assert_array_equal(pd.read_parquet(pasta/'operacional.parquet').indice_hora,np.flatnonzero(periodo&causal))
    treino=pd.read_parquet(pasta/'treino.parquet')
    indices=np.unique((treino.indice_hora.to_numpy()[:,None]+np.arange(1-w,1)[None,:]).ravel())
    desvio=x[indices].std(axis=0);desvio=np.where(desvio==0,1.,desvio)
    z=(x-x[indices].mean(axis=0))/desvio
    escalas=ler_json(pasta/'escalas.json');matriz=np.load(pasta/'entradas.npy')
    np.testing.assert_allclose(z.astype(np.float32),matriz,rtol=1e-6,atol=1e-7,equal_nan=True)
    np.testing.assert_allclose(escalas['media_entrada'],x[indices].mean(axis=0),rtol=1e-12,atol=1e-15)
    np.testing.assert_allclose(escalas['escala_entrada'],desvio,rtol=1e-12,atol=1e-15)
    np.testing.assert_allclose(escalas['media_alvo'],treino.alvo.mean(),rtol=1e-12,atol=1e-15)
    np.testing.assert_allclose(escalas['escala_alvo'],treino.alvo.to_numpy().std(),rtol=1e-12,atol=1e-15)
    return {'status':'conferido','utc':agora(),'dataset':m['id'],'dataset_sha256':sha256(pasta/'dataset.json'),
            'metodo':'reagregação dos minutos e reconstrução independente de OHLCV/tempos/alvo; prefixos para elegibilidade; união de índices para escalas',
            'horas':len(h),'horas_ausentes':int((~valido).sum()),'populacoes':m['populacoes'],
            'maxima_diferenca_alvo':float(np.nanmax(abs(alvo-h.alvo))),
            'maxima_diferenca_matriz':float(np.nanmax(abs(z.astype(np.float32)-matriz))),
            'maximo_absoluto_padronizado_treino':np.nanmax(np.abs(z[indices]),axis=0).tolist(),
            'quantil_999_absoluto_padronizado_treino':np.nanquantile(np.abs(z[indices]),.999,axis=0).tolist()}


if __name__=='__main__':
    destino=RAIZ/'registros/ohlcv/conferencias'/agora().replace(':','').replace('+','_')
    destino.mkdir(parents=True)
    try:
        resultado=conferir()
    except BaseException:
        import traceback
        salvar_json(destino/'resumo.json',{'status':'falha','utc':agora(),'erro':traceback.format_exc()})
        raise
    salvar_json(destino/'resumo.json',resultado)
    print(destino/'resumo.json')
