"""Figura descritiva da comparação pareada já publicada; não executa modelos."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from infraestrutura.artefatos import RAIZ,ler_json,salvar_json,sha256,agora


if __name__=='__main__':
    fonte=RAIZ/'dados/experimentos/estado_mamba_dcf4b0ed9012f7247bce/publicacoes/tentativa_001/resultados.json'
    r=ler_json(fonte);pasta=RAIZ/'docs/figuras/estado_mamba'
    pasta.mkdir(parents=True,exist_ok=True)
    if (pasta/'comparacao_pareada.png').exists():
        raise FileExistsError('Figura já publicada; preservar e identificar nova versão se necessário.')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(11.4,4.7));x=np.arange(3);largura=.35
    for familia,cor,deslocamento,nome in [('estado16','#2366A1',-largura/2,'Estado 16 · referência'),('estado8','#CF7134',largura/2,'Estado 8 · variante')]:
        ks=[f'{familia}_{s}' for s in (17,42,2026)]
        valores=[100*r['por_ajuste'][k]['metricas']['teste']['habilidade_mse'] for k in ks]
        retornos=[100*r['por_ajuste'][k]['spot']['base']['retorno_liquido'] for k in ks]
        for ax,y in zip(axes,[valores,retornos]):
            barras=ax.bar(x+deslocamento,y,largura,label=nome,color=cor,zorder=3)
            for barra,v in zip(barras,y):
                ax.annotate(f'{v:+.2f}%'.replace('.',','),(barra.get_x()+barra.get_width()/2,v),
                    xytext=(0,5 if v>=0 else -11),textcoords='offset points',ha='center',fontsize=9)
    for ax in axes:
        ax.set_xticks(x,['Seed 17','Seed 42','Seed 2026']);ax.axhline(0,color='#555',linewidth=.8)
        ax.grid(axis='y',color='#E2E5EA',zorder=0);ax.set_axisbelow(True)
    axes[0].set_title('Erro de previsão: nenhuma vantagem consistente',loc='left',fontsize=11,pad=14)
    axes[0].set_ylabel('Redução do MSE contra Naive (%)\nMaior é melhor');axes[0].set_ylim(-1.8,1.65)
    axes[1].set_title('Operação: perdas menores, ainda negativas',loc='left',fontsize=11,pad=14)
    axes[1].set_ylabel('Retorno líquido Spot (%)');axes[1].set_ylim(-39,3)
    fig.suptitle('Mamba: reduzir o estado interno de 16 para 8',x=.055,ha='left',fontsize=15,fontweight='bold',y=.97)
    fig.legend(*axes[0].get_legend_handles_labels(),loc='lower left',bbox_to_anchor=(.05,.065),ncol=2,frameon=False)
    fig.text(.055,.025,'Mesmas três seeds e origens · teste 2025 retrospectivo · política R0 idêntica · barras são valores pontuais, sem IC',fontsize=8.5,color='#555')
    fig.subplots_adjust(left=.075,right=.98,top=.79,bottom=.24,wspace=.36)
    for extensao in ('png','pdf'):
        fig.savefig(pasta/f'comparacao_pareada.{extensao}',dpi=180,facecolor='white')
    salvar_json(RAIZ/'registros/estado_mamba/figuras.json',{'utc':agora(),'fonte':fonte.relative_to(RAIZ).as_posix(),'fonte_sha256':sha256(fonte),
        'verificador':__file__,'arquivos':{f'docs/figuras/estado_mamba/comparacao_pareada.{e}':sha256(pasta/f'comparacao_pareada.{e}') for e in ('png','pdf')}})
    print(pasta/'comparacao_pareada.png')
