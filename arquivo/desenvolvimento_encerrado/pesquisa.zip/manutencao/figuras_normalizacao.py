"""Figuras posteriores: lê publicações concluídas, sem alterar a execução."""
from pathlib import Path
import hashlib
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

RAIZ = Path(__file__).resolve().parents[1]
ID = '9e03af2150cbb7b1068d'


def main():
    origem = RAIZ / f'dados/experimentos/normalizacao_{ID}'
    assert json.loads((origem/'progresso.json').read_text())['status'] == 'concluido'
    destino = RAIZ / f'docs/figuras/normalizacao_{ID}'
    destino.mkdir(parents=True, exist_ok=True)
    resumos = {f: json.loads((origem/f'analises/{f}/resumo.json').read_text())
               for f in ('desenvolvimento', 'avaliacao')}
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11,
                         'axes.spines.top': False, 'axes.spines.right': False})
    fig, eixos = plt.subplots(1, 2, figsize=(13, 5.3), gridspec_kw={'width_ratios': [1, 1.15]})
    fig.subplots_adjust(left=.16, right=.97, bottom=.28, top=.79, wspace=.63)
    modelos = {v['modelo']: v for v in resumos['avaliacao']['modelos']}
    nomes = ['mamba_posnorm', 'mamba_prenorm', 'lstm', 'naive', 'arima']
    rotulos = ['Mamba anterior', 'Mamba pré-norma', 'LSTM', 'Naive', 'ARIMA']
    valores = [100*modelos[n]['mse']/modelos['naive']['mse'] for n in nomes]
    cores = ['#8794a8', '#157f83', '#476ba2', '#525b69', '#525b69']
    ax = eixos[0]
    ax.axvline(100, color='#525b69', lw=1, ls='--')
    ax.scatter(valores, np.arange(5), c=cores, s=85, zorder=3)
    for i, v in enumerate(valores):
        ax.annotate(f'{v:.3f}'.replace('.', ','), (v, i), xytext=(8, -4), textcoords='offset points')
    ax.set(yticks=np.arange(5), yticklabels=rotulos, xlim=(99.85, 101.8), ylim=(4.6, -.6),
           xticks=[100, 100.5, 101, 101.5], xticklabels=['100,0', '100,5', '101,0', '101,5'],
           xlabel='MSE relativo ao Naive = 100\nMenor é melhor', title='Avaliação retrospectiva · 2024–2025')
    ax.grid(axis='x', alpha=.15)
    ax = eixos[1]
    ax.axvline(0, color='#525b69', lw=1, ls='--')
    for i, fase in enumerate(('desenvolvimento', 'avaliacao')):
        c = resumos[fase]['contrastes'][0]
        ic = next(v for v in c['intervalos'] if v['dias'] == 14)
        valor = c['diferenca_mse']*1e6
        ax.errorbar(valor, i, xerr=[[valor-ic['inferior']*1e6], [ic['superior']*1e6-valor]],
                    fmt='o', color='#157f83', capsize=5, markersize=7, lw=2)
    ax.set(yticks=[0, 1], yticklabels=['2023\nDesenvolvimento', '2024–2025\nRetrospectivo'],
           ylim=(1.6, -.6), xlim=(-31, 7), xlabel='MSE novo − anterior (× 10⁻⁶)\nNegativo favorece pré-normalização',
           title='Efeito pareado e intervalo de 95%')
    ax.grid(axis='x', alpha=.15)
    fig.suptitle('Pré-normalização: erro médio menor, ganho ainda inconclusivo em 2024–2025',
                 fontsize=15, fontweight='bold', y=.97)
    fig.text(.02, .06, 'Médias com pesos iguais entre moedas, contextos, blocos e seeds; não são ensembles.\n'
             'Intervalos: bootstrap temporal pareado, blocos de 14 dias, 2.000 réplicas. Períodos já consultados.', fontsize=10)
    for formato in ('png', 'pdf'):
        fig.savefig(destino/f'comparacao.{formato}', dpi=180, facecolor='white')
    plt.close(fig)
    arquivos = [Path(__file__), *(origem/f'analises/{f}/publicacao.json' for f in resumos),
                *(destino/f'comparacao.{f}' for f in ('png', 'pdf'))]
    manifesto = {'execucao': ID, 'natureza': 'Figuras posteriores; dados congelados preservados.',
                 'arquivos': {p.relative_to(RAIZ).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in arquivos}}
    (destino/'manifesto.json').write_text(json.dumps(manifesto, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    print(destino)


if __name__ == '__main__':
    main()
