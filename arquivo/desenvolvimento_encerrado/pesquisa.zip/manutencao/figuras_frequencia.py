"""Figura posterior, somente a partir das métricas da revisão de frequência."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('revisao',type=Path)
    revisao=p.parse_args().revisao
    assert json.loads((revisao/'resumo.json').read_text(encoding='utf-8'))['status']=='concluido'
    saida=revisao/'figuras';saida.mkdir(exist_ok=False)
    shutil.copyfile(__file__,saida/'gerador.py')
    q=pd.read_csv(revisao/'resumo_frequencias.csv').query("fase=='avaliacao'")
    modelos=['arima','lstm','mamba_original','mamba_corrigido']
    rotulos=['ARIMA','LSTM','Mamba\noriginal','Mamba\ncorrigido']
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(12.8,5.4),gridspec_kw={'width_ratios':[1,1.15]})
    for deslocamento,hora,cor,rotulo in [(-.16,-1,'#3366a3','Todas as origens horárias'),(.16,0,'#d88335','Uma origem diária: 00 UTC')]:
        valores=[q.loc[(q.modelo==m)&(q.hora_utc==hora),'indice_mse_naive_100'].item() for m in modelos]
        axes[0].scatter(np.arange(4)+deslocamento,valores,color=cor,label=rotulo,s=48,zorder=3)
    axes[0].set_xticks(range(4),rotulos)
    axes[0].set_title('Mesmos modelos; outra frequência de avaliação',loc='left',fontsize=11,pad=16)
    axes[0].legend(loc='upper left',frameon=False,fontsize=9)
    for modelo,cor,rotulo in [('arima','#6c7580','ARIMA'),('lstm','#26785b','LSTM'),('mamba_corrigido','#ba5136','Mamba corrigido')]:
        g=q.loc[(q.modelo==modelo)&(q.hora_utc>=0)].sort_values('hora_utc')
        axes[1].plot(g.hora_utc,g.indice_mse_naive_100,label=rotulo,color=cor,marker='o',markersize=3,lw=1.5)
    axes[1].set_title('Sensibilidade: uma previsão por dia em cada horário',loc='left',fontsize=11,pad=16)
    axes[1].set_xticks([0,3,6,9,12,15,18,21,23])
    axes[1].set_xlabel('Horário UTC da origem (nenhum horário selecionado)')
    axes[1].legend(frameon=False,loc='upper right',fontsize=9)
    for eixo in axes:
        eixo.axhline(100,color='#374151',ls='--',lw=1)
        eixo.set_ylim(99,103.4)
        eixo.set_ylabel('MSE relativo ao Naive (Naive = 100)')
        eixo.grid(axis='y',alpha=.17)
    fig.suptitle('Prever uma vez ao dia não resolveu a desvantagem observada',x=.06,ha='left',fontsize=15,fontweight='bold')
    fig.text(.06,.89,'Avaliação retrospectiva de 2024–2025 • Menor é melhor • Modelos treinados com origens horárias',fontsize=10,color='#4b5563')
    fig.text(.06,.025,'Médias com pesos iguais por moeda, contexto e bloco; seeds promediadas nos escores.\nSensibilidade descritiva; intervalos temporais e desenvolvimento de 2023 estão no relatório. Não houve retreinamento.',fontsize=9,color='#4b5563')
    fig.subplots_adjust(left=.07,right=.98,top=.79,bottom=.22,wspace=.28)
    for extensao in ('png','pdf'):
        fig.savefig(saida/f'frequencia_avaliacao.{extensao}',dpi=170,facecolor='white')
    plt.close(fig)
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    (saida/'manifesto.json').write_text(json.dumps({'entrada_sha256':sha(revisao/'resumo_frequencias.csv'),
       'arquivos':{p.name:sha(p) for p in saida.iterdir() if p.is_file()}},indent=2),encoding='utf-8')
    print(saida)


if __name__=='__main__':main()
