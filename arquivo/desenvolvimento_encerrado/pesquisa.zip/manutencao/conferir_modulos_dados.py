"""Conferência posterior independente: lê artefatos, não treina nem altera recibos anteriores."""
import argparse
from pathlib import Path
import sys
import traceback
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
from infraestrutura.artefatos import RAIZ,abrir_artefato,ler_json,salvar_json,sha256,relativo,agora


def conferir(mercado,candles,entradas,revisao):
    m=abrir_artefato(mercado,'mercado_minutos')
    abrir_artefato(candles,'mercado_candles');abrir_artefato(entradas,'entradas_modelo')
    anterior=RAIZ/'dados/processados/retorno24_d25f6a93a9900725f51e'
    referencia=RAIZ/'dados/processados/ohlcv24_00c15349ce0e28a543a6'
    velho=ler_json(anterior/'dataset.json');inicio=velho['primeiro_minuto']
    partes=ler_json(mercado/'qualidade.json')['partes'];pares={}
    for par in m['assinatura']['parametros']['pares']:
        minutos=np.load(anterior/par/'minutos.npy',mmap_mode='r',allow_pickle=False)
        total=ausentes=interrompidos=0
        for parte in (p for p in partes if p['par']==par):
            q=pd.read_parquet(mercado/parte['arquivo'])
            i=int(q.inicio_utc.iloc[0].timestamp()//60)-inicio
            novos=q[['open','high','low','close','volume','negocios']].to_numpy()
            np.testing.assert_array_equal(novos,minutos[i:i+len(q)])
            total+=len(q);ausentes+=parte['ausentes_na_fonte'];interrompidos+=parte['interrompidos']
        assert total==len(minutos)
        h=pd.read_parquet(candles/f'{par}.parquet');h0=pd.read_parquet(anterior/par/'horas.parquet')
        np.testing.assert_array_equal(h[['open','high','low','close','volume']],h0[['open','high','low','close','volume']])
        np.testing.assert_array_equal(h.fim_utc.to_numpy(),h0.origem_utc.to_numpy())
        pares[par]={'minutos':total,'ausentes_na_fonte':ausentes,'interrompidos':interrompidos,
                    'horas':len(h),'horas_indisponiveis':int((~h.completo).sum()),'igualdade_mercado':'exata'}
    x=np.load(entradas/'entradas.npy',allow_pickle=False)
    np.testing.assert_array_equal(x,np.load(referencia/'entradas.npy',allow_pickle=False))
    c=ler_json(entradas/'contrato.json');e=ler_json(entradas/'escalas.json');e0=ler_json(referencia/'escalas.json')
    for chave in ('media_entrada','escala_entrada','media_alvo','escala_alvo'):
        np.testing.assert_allclose(e[chave],e0[chave],rtol=1e-12,atol=1e-15)
    h=pd.read_parquet(candles/f"{c['par']}.parquet")
    precos=h[['open','high','low','close']].to_numpy(float)
    anterior_close=np.r_[np.nan,precos[:-1,3]]
    bruto=np.column_stack([np.log(precos/anterior_close[:,None]),np.log1p(h.volume.to_numpy())])
    alvo=np.full(len(h),np.nan);passos=c['horizonte_minutos']//c['intervalo_minutos']
    alvo[:-passos]=np.log(precos[passos:,3]/precos[:-passos,3])
    origem=h.fim_utc;destino=origem+pd.Timedelta(minutes=c['horizonte_minutos'])
    w=c['contexto_passos'];valida=np.zeros(len(h),bool)
    for i in range(w-1,len(h)):
        valida[i]=np.isfinite(bruto[i-w+1:i+1]).all() and i%c['passo_origens']==0
    populacoes={};usados=np.zeros(len(h),bool);maior_diferenca=0.
    for nome in ('treino','validacao','teste','operacional'):
        q=pd.read_parquet(entradas/f'{nome}.parquet');q0=pd.read_parquet(referencia/f'{nome}.parquet')
        a,b=map(pd.Timestamp,c['divisao']['teste' if nome=='operacional' else nome])
        mascara=valida&(origem>=a).to_numpy()&(origem<b).to_numpy()
        if nome!='operacional':mascara=mascara&np.isfinite(alvo)&(destino<b).to_numpy()
        indices=np.flatnonzero(mascara)
        np.testing.assert_array_equal(q.indice_candle,indices)
        np.testing.assert_array_equal(q.indice_candle,q0.indice_hora)
        np.testing.assert_array_equal(q.origem_utc.to_numpy(),q0.origem_utc.to_numpy())
        np.testing.assert_allclose(q.alvo,alvo[indices],rtol=1e-12,atol=1e-15,equal_nan=True)
        np.testing.assert_allclose(q.alvo,q0.alvo,rtol=1e-12,atol=1e-15,equal_nan=True)
        delta=np.abs(q.alvo.to_numpy()-q0.alvo.to_numpy())
        maior_diferenca=max(maior_diferenca,float(np.nanmax(delta)))
        if nome=='treino':
            for i in indices:usados[i-w+1:i+1]=True
        populacoes[nome]=len(q)
    np.testing.assert_allclose(bruto[usados].mean(axis=0),e['media_entrada'],rtol=1e-12,atol=1e-15)
    np.testing.assert_allclose(bruto[usados].std(axis=0),e['escala_entrada'],rtol=1e-12,atol=1e-15)
    recalculado=((bruto-np.array(e['media_entrada']))/np.array(e['escala_entrada'])).astype(np.float32)
    np.testing.assert_array_equal(x,recalculado)
    resumo={'utc':agora(),'status':'aprovado','treinamento':False,'pares':pares,'populacoes':populacoes,
            'matriz_float32':'exata com R0 e recálculo independente','diferenca_maxima_alvo_r0':maior_diferenca,
            'tolerancia_float64':{'rtol':1e-12,'atol':1e-15},
            'artefatos':{k:{'pasta':relativo(v),'manifesto_sha256':sha256(v/'manifesto.json')}
                         for k,v in [('mercado',mercado),('candles',candles),('entradas',entradas)]},
            'codigo_conferencia_sha256':sha256(Path(__file__))}
    salvar_json(revisao/'conferencia_dados.json',resumo)
    return resumo


def rede(revisao):
    from mercado_binance import Periodo,coletar_api,baixar_arquivos
    anterior=RAIZ/'dados/processados/retorno24_d25f6a93a9900725f51e'
    inicio=ler_json(anterior/'dataset.json')['primeiro_minuto']
    minutos=np.load(anterior/'BTCUSDT/minutos.npy',mmap_mode='r')
    resultados=[]
    for ano in (2024,2025):
        try:
            p=coletar_api('BTCUSDT',Periodo(f'{ano}-01-01T00:00Z',f'{ano}-01-01T00:05Z'),limite=2,maximo_paginas=5)
            q=pd.read_parquet(p/'minutos/BTCUSDT/api.parquet');i=int(q.inicio_utc.iloc[0].timestamp()//60)-inicio
            np.testing.assert_array_equal(q[['open','high','low','close','volume','negocios']],minutos[i:i+len(q)])
            resultados.append({'tipo':'api','ano':ano,'status':'aprovado','minutos':len(q),'pasta':relativo(p),'igualdade_arquivo':'exata'})
        except Exception:
            resultados.append({'tipo':'api','ano':ano,'status':'falhou','erro':traceback.format_exc()})
            break  # Não insistir em outro ano após bloqueio/erro de rede.
    try:
        p=baixar_arquivos(['BTCUSDT'],Periodo('2025-01-01T00:00Z','2025-02-01T00:00Z'))
        nome='BTCUSDT/BTCUSDT-1m-2025-01.zip'
        atual=sha256(p/nome);original=sha256(RAIZ/'dados/brutos/binance_spot_1m'/nome)
        resultados.append({'tipo':'arquivo_mensal','status':'aprovado','pasta':relativo(p),
                           'sha256':atual,'igual_ao_preexistente':atual==original})
    except Exception:
        resultados.append({'tipo':'arquivo_mensal','status':'falhou','erro':traceback.format_exc()})
    salvar_json(revisao/'conferencia_rede.json',{'utc':agora(),'resultados':resultados,'escopo':'5 minutos/ano; 1 ZIP; nenhuma recoleta da base'})
    return resultados


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--revisao',type=Path,required=True)
    p.add_argument('--mercado',type=Path);p.add_argument('--candles',type=Path);p.add_argument('--entradas',type=Path)
    p.add_argument('--rede',action='store_true')
    a=p.parse_args();a.revisao.mkdir(parents=True,exist_ok=True)
    try:
        if a.rede:print(rede(a.revisao))
        else:print(conferir(a.mercado,a.candles,a.entradas,a.revisao))
    except BaseException:
        salvar_json(a.revisao/'falha_conferencia.json',{'utc':agora(),'erro':traceback.format_exc()})
        raise
