"""Conferência posterior independente; não treina nem altera publicações congeladas."""
from collections import Counter
from pathlib import Path
import itertools
import sys
import traceback
import numpy as np
import pandas as pd
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from previsao24.arquivos import RAIZ, agora, ler_json, salvar_json, sha256, identidade, verificar_arquivos
from previsao24.configuracao import FOLDS
from previsao24.dados import verificar_dataset
from experimento_penalizacao.ciclo import conferir_fontes, hashes


def perto(a, b):
    if a is None or b is None:
        assert a is b
    else:
        np.testing.assert_allclose(a, b, rtol=1e-10, atol=1e-13)


def inventario(pasta):
    registros = {}
    estados = Counter()
    for arquivo in sorted(pasta.glob('celulas/*/tentativa_*/tentativa.json')):
        t = ler_json(arquivo); estados[t['status']] += 1
        if t['status'] != 'auditada':
            continue
        x = t['celula']; k = (x['par'], x['fold'], x.get('contexto'), x.get('seed'), x['modelo'])
        assert k not in registros
        a = ler_json(arquivo.parent/'auditoria.json')
        assert a['status'] == 'aprovado'
        verificar_arquivos(arquivo.parent, a['arquivos'])
        registros[k] = arquivo.parent
    return registros, dict(estados)


def medidas(q):
    y = q.alvo.to_numpy(); p = q.previsao.to_numpy(); erro = p-y
    assert np.isfinite(y).all() and np.isfinite(p).all()
    mse = float(np.dot(erro, erro)/len(erro)); mn = float(np.dot(y, y)/len(y))
    recalls = [float(np.mean(np.sign(p[y*k > 0]) == k)) for k in (-1, 1)]
    return dict(mse=mse, rmse=np.sqrt(mse), mae=float(np.abs(erro).mean()), mse_naive=mn,
                habilidade_mse=1-mse/mn, vies=float(erro.mean()),
                acuracia_direcional=float(np.mean(np.sign(p) == np.sign(y))),
                acerto_balanceado_direcional=float(np.mean(recalls)))


def bootstrap(diarios, tamanho, replicas, seed):
    rng = np.random.default_rng(seed); amostras = np.zeros(replicas)
    for somas, contagens in diarios:
        n = len(somas); b = min(n, tamanho); k = (n+b-1)//b
        inicios = rng.integers(n-b+1, size=(replicas, k))
        for i, inicios_replica in enumerate(inicios):
            ids = np.concatenate([np.arange(v, v+b) for v in inicios_replica])[:n]
            amostras[i] += np.sum(somas[ids])/np.sum(contagens[ids])/len(diarios)
    return np.quantile(amostras, [.025, .975])


def main():
    pasta = RAIZ/'dados/experimentos/penalizacao_7868a4d847c1410fc681'
    saida = RAIZ/'registros/revisoes'/('penalizacao_'+agora().replace(':','').replace('+','_'))
    saida.mkdir(parents=True, exist_ok=False)
    recibo = dict(status='em_andamento', inicio_utc=agora(), execucao=pasta.name,
                  codigo_sha256=sha256(Path(__file__)))
    salvar_json(saida/'estado.json', recibo)
    try:
        assert ler_json(pasta/'progresso.json')['status'] == 'concluido'
        assinatura = conferir_fontes(pasta); e = ler_json(pasta/'execucao.json')
        assert identidade(assinatura)[:20] == e['id']
        base = RAIZ/e['referencia_caminho']; dados = RAIZ/e['dataset_caminho']
        c = assinatura['configuracao_treino']; folds = c['folds_desenvolvimento']+c['folds_avaliacao']
        manifesto = verificar_dataset(dados)
        antes = ler_json(RAIZ/e['preparacao_caminho']/'preservacao_antes.json')['arquivos']
        assert hashes([RAIZ/p for p in antes]) == antes
        assert ler_json(pasta/'preservacao_depois.json')['status'] == 'aprovado'
        novos, estados = inventario(pasta); originais, _ = inventario(base); controles, _ = inventario(pasta/'controles')
        esperado = {(p,f,w,s,'mamba') for p,f,w,s in itertools.product(c['pares'],folds,c['contextos'],c['seeds'])}
        assert set(novos) == esperado and len(originais) == 832 and len(controles) == 2
        for k, local in controles.items():
            r = ler_json(local/'reproducao.json'); assert r['mesma_epoca'] and r['variacao_relativa_mse'] <= 1e-4
            assert max(v['maxima'] for v in r['diferencas'].values()) <= 1e-5
            for populacao in ('validacao','teste','operacional'):
                a = pd.read_parquet(local/f'previsoes_{populacao}.parquet')
                b = pd.read_parquet(originais[k]/f'previsoes_{populacao}.parquet')
                perto(float(np.abs(a.previsao-b.previsao).max()), r['diferencas'][populacao]['maxima'])
        print('Cobertura 384+2, fontes, dataset e preservação aprovados.', flush=True)
        erros = {}; tempos = {}; medidas_teste = {}; caminhos = {}
        for variante, registros in [('corrigido', novos), ('original', originais)]:
            for k, local in registros.items():
                p,f,w,s,m = k; nome = ('mamba_'+variante) if m == 'mamba' else m
                salvo = ler_json(local/'resultado.json')
                populacoes = ('validacao','teste','operacional') if variante == 'corrigido' else ('teste',)
                for populacao in populacoes:
                    q = pd.read_parquet(local/f'previsoes_{populacao}.parquet')
                    if variante == 'corrigido':
                        ref = pd.read_parquet(originais[k]/f'previsoes_{populacao}.parquet')
                        pd.testing.assert_frame_equal(q.drop(columns='previsao'), ref.drop(columns='previsao'))
                        assert np.isfinite(q.previsao).all()
                    if populacao != 'operacional':
                        met = medidas(q)
                        for medida,v in met.items(): perto(v, salvo['metricas'][populacao][medida])
                    if populacao == 'teste':
                        chave = (p,f,w,s,nome)
                        erros[chave] = (q.previsao-q.alvo).to_numpy()**2
                        medidas_teste[chave] = met; caminhos[chave] = local
                        if f in tempos: pd.testing.assert_series_equal(tempos[f], q.origem_utc)
                        tempos[f] = q.origem_utc
                if variante == 'corrigido':
                    cp = torch.load(local/'checkpoint.pt',map_location='cpu',weights_only=True)
                    antigo = torch.load(originais[k]/'checkpoint.pt',map_location='cpu',weights_only=True)
                    assert cp['escalas'] == antigo['escalas'] and cp['configuracao'] == antigo['configuracao'] == c
                    grupos = ler_json(local/'otimizador.json')['grupos']
                    isentos = [n for g in grupos if g['weight_decay'] == 0 for n in g['nomes']]
                    assert set(isentos) == {'blocos.0.A_log','blocos.0.D','blocos.1.A_log','blocos.1.D'}
                    del cp, antigo
        print('Métricas, populações, escalas e grupos de 384 ajustes conferidos.', flush=True)
        fases = {}; intervalos_conferidos = 0; ordens_total = 0
        for fase, fs in [('desenvolvimento',c['folds_desenvolvimento']), ('avaliacao',c['folds_avaliacao'])]:
            publicacao = pasta/'analises'/fase; r = ler_json(publicacao/'resumo.json')
            verificar_arquivos(publicacao, ler_json(publicacao/'publicacao.json')['arquivos'])
            auditoria = ler_json(publicacao/'auditoria.json')
            assert auditoria['status'] == 'aprovado' and auditoria['publicacao_sha256'] == sha256(publicacao/'publicacao.json')
            assert r['ajustes_novos'] == 192 and r['resultados_herdados'] == 416 and len(r['pares']) == 192
            escores = {}
            for p,f,w,nome in itertools.product(c['pares'],fs,c['contextos'],[v['modelo'] for v in r['modelos']]):
                chaves = [(p,f,w,s,nome) for s in c['seeds']] if nome not in ('naive','arima') else [(p,f,None,None,nome)]
                escores[p,f,w,nome] = np.mean([erros[k] for k in chaves], axis=0)
            for m in r['modelos']:
                perto(np.mean([v.mean() for k,v in escores.items() if k[-1] == m['modelo']]), m['mse'])
            for contraste in r['contrastes'] + r['contextos']:
                diarios = []; valores = []
                for f in fs:
                    if 'referencia' in contraste:
                        delta = np.mean([escores[p,f,w,'mamba_corrigido']-escores[p,f,w,contraste['referencia']] for p,w in itertools.product(c['pares'],c['contextos'])],axis=0)
                    else:
                        delta = np.mean([escores[p,f,24,contraste['modelo']]-escores[p,f,contraste['contexto_comparado'],contraste['modelo']] for p in c['pares']],axis=0)
                    inicio = pd.Timestamp(FOLDS[f][1],tz='UTC'); fim = pd.Timestamp(FOLDS[f][2],tz='UTC')
                    ids = ((tempos[f]-inicio).dt.total_seconds().to_numpy()//86400).astype(int)
                    n = (fim-inicio).days
                    diarios.append((np.bincount(ids,weights=delta,minlength=n), np.bincount(ids,minlength=n)))
                    valores.append(delta.mean())
                perto(np.mean(valores), contraste['diferenca_mse'])
                for ic in contraste['intervalos']:
                    perto(bootstrap(diarios,ic['dias'],ic['replicas'],c['bootstrap']['seed']), [ic['inferior'],ic['superior']])
                    intervalos_conferidos += 1
            financeiro = []; sinais_alterados = 0; total_ordens_fase = 0
            for par in c['pares']:
                minutos = np.load(dados/par/'minutos.npy',mmap_mode='r')
                for w,s in itertools.product(c['contextos'],c['seeds']):
                    origens = {}
                    for nome in ('mamba_corrigido','mamba_original'):
                        trechos = []
                        for f in fs:
                            q = pd.read_parquet(caminhos[par,f,w,s,nome]/'previsoes_operacional.parquet')
                            limite = pd.Timestamp(FOLDS[f][2],tz='UTC')
                            q = q[(q.origem_utc+pd.Timedelta(hours=24,minutes=1)<limite)&(q.origem_utc.dt.hour==0)]
                            trechos.append(q)
                        q = pd.concat(trechos)
                        op = c['operacao']; limite = np.log((1+op['slippage'])*(1+op['taxa'])/((1-op['slippage'])*(1-op['taxa'])))
                        origens[nome] = q[q.previsao>limite].origem_utc.map(lambda v:v.isoformat()).tolist()
                    sinais_alterados += len(set(origens['mamba_corrigido']) ^ set(origens['mamba_original']))
                    for item in [v for v in r['financeiro'] if v['par']==par and v['contexto']==w and v['seed']==s]:
                        doc = ler_json(publicacao/item['arquivo']); ordens = doc['ordens']
                        assert [o['origem_utc'] for o in ordens] == origens['mamba_corrigido']
                        f = op['taxa'] if item['cenario']=='base' else op['taxa_agravada']
                        sl = op['slippage'] if item['cenario']=='base' else op['slippage_agravado']
                        capital = op['capital']; custo = 0.; pico = capital; dd = 0.; risco = True
                        for o in ordens:
                            t = pd.Timestamp(o['origem_utc']); entrada = int(t.timestamp()/60)+1; vencimento = entrada+1440
                            assert o['entrada_minuto']==entrada and o['saida_minuto']==vencimento
                            i,j = entrada-manifesto['primeiro_minuto'],vencimento-manifesto['primeiro_minuto']
                            assert capital is not None and np.isfinite(minutos[[i,j],0]).all() and (minutos[[i,j],5]>0).all()
                            a,b = minutos[i,0],minutos[j,0]; perto(a,o['preco_entrada']); perto(b,o['preco_saida'])
                            unidades = capital/(a*(1+sl)*(1+f)); final = unidades*b*(1-sl)*(1-f)
                            perto(capital,o['capital_entrada']); perto(final,o['capital_saida']); perto(unidades,o['quantidade'])
                            custo += capital-unidades*a+unidades*b-final
                            percurso = minutos[i:j,3]; risco &= bool(np.isfinite(percurso).all())
                            if np.isfinite(percurso).all():
                                marcas = np.r_[capital, unidades*percurso*(1-sl)*(1-f), final]
                                maximos = np.maximum.accumulate(np.r_[pico,marcas])[1:]
                                dd = max(dd,float(np.max((maximos-marcas)/maximos))); pico=max(pico,float(marcas.max()))
                            capital=final
                        perto(capital,item['capital_final']); perto(capital/op['capital']-1,item['retorno_liquido']); perto(custo,item['custos_observados'])
                        perto(dd if risco else None,item['drawdown']); assert risco == item['risco_auditavel']
                        assert len(ordens)==item['entradas_planejadas']; total_ordens_fase += len(ordens)
                        financeiro.append(item)
                del minutos
            assert total_ordens_fase == r['ordens_conferidas']; ordens_total += total_ordens_fase
            fases[fase] = dict(modelos=r['modelos'],contrastes=r['contrastes'],estabilidade=r['estabilidade'],
                              epocas_selecionadas_alteradas=sum(v['epoca_original']!=v['epoca_corrigida'] for v in r['pares']),
                              pares_melhores=sum(v['diferenca']<0 for v in r['pares']), sinais_alterados=sinais_alterados,
                              ordens_conferidas=total_ordens_fase,
                              financeiro={cenario:dict(mediana=float(np.median([v['retorno_liquido'] for v in financeiro if v['cenario']==cenario])),
                                  pares_retorno_alterado=sum(abs(v['diferenca_retorno'])>1e-12 for v in financeiro if v['cenario']==cenario),
                                  positivos=sum(v['retorno_liquido']>0 for v in financeiro if v['cenario']==cenario)) for cenario in ('base','agravado_sinais_base')})
            print(f'{fase}: métricas, contrastes, intervalos e {total_ordens_fase} ordens conferidos.',flush=True)
        recibo.update(status='aprovado',fim_utc=agora(),ajustes_corrigidos=384,controles=2,estados_tentativas=estados,
                      arquivos_preservados=len(antes),intervalos_conferidos=intervalos_conferidos,ordens_conferidas=ordens_total,fases=fases,
                      limites='Conferência independente aritmética e temporal, escalas/configurações de todos os checkpoints. Não repete o treino nem a inferência neural; recarga exata de cada treino consta dos recibos originais. Todos os cenários desta execução tinham pontas observadas; a ausência financeira gera falha nesta conferência, não imputação.')
        salvar_json(saida/'resumo.json',recibo)
    except Exception as erro:
        recibo.update(status='falha',erro=repr(erro),traceback=traceback.format_exc(),fim_utc=agora())
        raise
    finally:
        salvar_json(saida/'estado.json',{k:v for k,v in recibo.items() if k!='fases'})
        print(saida,flush=True)


if __name__=='__main__': main()
