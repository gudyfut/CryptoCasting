"""Retomada manual unica apos cota: continua 19 ajustes sem editar fontes congeladas.

Entrada: python -m manutencao.retomar_busca_astra_001 preparar|executar
Consulta falha07 conta no teto12: restam cinco consultas(08..12), candidatas07..11.
Prazos absolutos originais mantidos, inclusive tempo parado. Sem retry automatico.
"""
import argparse
import json
import os
import shutil
import socket
import subprocess
import time
import traceback
from pathlib import Path
from infraestrutura.artefatos import RAIZ, agora, ler_json, salvar_json, sha256, conferir_arquivos
from experimentos.busca_astra.ciclo import Coordenador, REG, conferir, controle_cpu
from experimentos.busca_astra.contrato import REFERENCIA, DESENVOLVIMENTO, FINAIS, SEEDS, chave_receita, pontuar, elegivel
from experimentos.busca_astra.agente import consultar

RET = REG/'retomadas/001'
ID = 'b34bad73d6cef1d10a97'
FONTES = ['manutencao/retomar_busca_astra_001.py', 'manutencao/test_retomada_busca_astra.py']

def validar_ponto(p):
    assert not ler_json(p/'processo.json')['ativo']
    assert not ler_json(p/'worker_windows.json')['ativo']
    assert not (p/'finalista.json').exists() and not (p/'fechamento.json').exists()
    jobs=ler_json(p/'ajustes.json'); candidatas=ler_json(p/'candidatas.json')
    assert len(jobs)==19 and all(j['status']=='concluido' for j in jobs)
    assert len(candidatas)==6 and all(len(c['resultados'])==2 for c in candidatas)
    assert [j['numero'] for j in jobs]==list(range(1,20))
    for j in jobs:
        d=RAIZ/j['destino']; conferir_arquivos(d,ler_json(d/'conclusao.json')['arquivos'])
        r=ler_json(d/'resultado.json')
        assert r['receita']==j['receita'] and r['seed']==j['seed'] and r['bloco']==j['bloco']
        assert r['recarga_exata'] and 'teste' not in r
    for c in candidatas:
        assert c['id'].split('_',1)[1]==chave_receita(c['proposta']['receita'])
        for r in c['resultados']:
            assert r==ler_json(p/'desenvolvimento'/c['id']/f"{r['bloco']}_{r['seed']}"/'resultado.json')
    controle_cpu(p/'desenvolvimento/referencia/D1_42',p/'controles/referencia/D1_42')
    assert sorted(x.name for x in (p/'agente').iterdir())==[f'{i:02}' for i in range(1,8)]
    erro=(p/'agente/07/eventos.jsonl').read_text(encoding='utf-8')
    assert 'usage limit' in erro and not (p/'agente/07/resposta.json').exists()
    for n,c in enumerate(candidatas,1):
        assert ler_json(p/f'agente/{n:02}/resposta.json')==c['proposta']
    ps=subprocess.check_output(['wsl','-d','Ubuntu','--','ps','-eo','args'],text=True)
    assert not any('experimentos.busca_astra.worker' in l for l in ps.splitlines())
    return jobs,candidatas

def preparar():
    assert not (RET/'autorizacao.json').exists(), 'Retomada ja preparada.'
    ptr=ler_json(REG/'execucao.json'); assert ptr['id']==ID
    p=RAIZ/ptr['pasta']; conferir(p,ptr);validar_ponto(p)
    RET.mkdir(parents=True,exist_ok=True)
    mutaveis={'processo.json','worker_windows.json','progresso.json','ajustes.json','candidatas.json','gpu.lock'}
    protegidos={}
    for arquivo in p.rglob('*'):
        if arquivo.is_file() and arquivo.relative_to(p).as_posix() not in mutaveis:
            protegidos[arquivo.relative_to(RAIZ).as_posix()]=sha256(arquivo)
    for nome in mutaveis-{'gpu.lock'}:
        shutil.copyfile(p/nome,RET/('anterior_'+nome))
    shutil.copyfile(REG/'estado.json',RET/'anterior_estado.json')
    salvar_json(RET/'preservacao.json',{'arquivos':protegidos})
    a={'utc':agora(),'pedido':'ja voltou os creditos, volte com o processo',
       'execucao':ptr,'fontes':{n:sha256(RAIZ/n) for n in FONTES},
       'preservacao_sha256':sha256(RET/'preservacao.json'),
       'snapshots':{q.name:sha256(q) for q in RET.glob('anterior_*.json')},
       'limites':'Sem renovacao de prazo: inicio original+8h triagem/+12h exploracao. Cinco consultas restantes, contando a falha07 no teto12. Ate106 ajustes totais, abaixo do teto108.',
       'qualificacao':'Testes de retomada sem repetir referencias, teto de consultas/ajustes, selecao e bloqueio sem ganho; worker científico original inalterado.'}
    salvar_json(RET/'autorizacao.json',a)
    print(json.dumps(a),flush=True)

class Retomada(Coordenador):
    def __init__(self,p,ptr,f):
        super().__init__(p,ptr,f)
        self.jobs,self.candidatas=validar_ponto(p)
        anterior=ler_json(RET/'anterior_progresso.json')
        self.inicio=anterior['inicio_timestamp']
        self.limite=anterior['limite_exploracao_timestamp']
        self.triagem_fim=self.inicio+8*3600
        self.ref=[ler_json(p/'desenvolvimento/referencia'/f'{b}_{s}'/'resultado.json')
                  for b in DESENVOLVIMENTO for s in SEEDS[:3]]

    def checar(self):
        super().checar()
        a=ler_json(RET/'autorizacao.json')
        conferir_arquivos(RAIZ,a['fontes'])
        assert sha256(RET/'preservacao.json')==a['preservacao_sha256']

    def encerrar(self,status,motivo):
        conferir_arquivos(RAIZ,ler_json(RET/'preservacao.json')['arquivos'])
        return super().encerrar(status,motivo)

    # CONTINUACAO: selecao e fase final copiadas literalmente do executor congelado.

    def executar(self):
        diag=ler_json(self.p/'diagnostico_desenvolvimento.json')
        vistas={chave_receita(REFERENCIA)} | {chave_receita(c['proposta']['receita']) for c in self.candidatas}
        for n in range(7,12):
            if time.time()>=self.triagem_fim:break
            self.checar();self.estado('astra_propondo',rodada=n)
            contexto={'diagnostico':diag,'referencia':self.ref,'tentativas':self.candidatas,
                'rodada':n,'maximo':12,'horas_restantes_exploracao':max(0,(self.limite-time.time())/3600)}
            proposta=consultar(self.p/'agente'/f'{n+1:02}',contexto,versao_cli=self.f['ambiente_coordenador']['codex'])
            if proposta['acao']=='encerrar':break
            r=proposta['receita'];key=chave_receita(r)
            if key in vistas:raise ValueError('Proposta repetida; preservar e interromper, sem consulta substituta gratuita.')
            vistas.add(key)
            cand={'id':f'C{n:02}_{key}','proposta':proposta,'resultados':[]}
            self.candidatas.append(cand)
            for b in DESENVOLVIMENTO:
                cand['resultados'].append(self.ajuste(r,b,42,'desenvolvimento/'+cand['id']))
            cand['score_triagem']=pontuar(cand['resultados'])
            salvar_json(self.p/'candidatas.json',self.candidatas)
        if not self.candidatas:return self.encerrar('concluido_sem_finalista','Nenhuma candidata proposta/concluida.')
        top=sorted(self.candidatas,key=lambda c:(c['score_triagem'][0],c['score_triagem'][2],
                    c['resultados'][0]['parametros'],c['id']))[:3]
        for cand in top:
            if time.time()>=self.limite:break
            por={(r['bloco'],r['seed']):r for r in cand['resultados']}
            for b in DESENVOLVIMENTO:
                for s in SEEDS[1:3]:
                    por[b,s]=self.ajuste(cand['proposta']['receita'],b,s,'desenvolvimento/'+cand['id'])
            cand['resultados']=[por[b,s] for b in DESENVOLVIMENTO for s in SEEDS[:3]]
            cand['score_promocao']=pontuar(cand['resultados']);cand['elegivel']=elegivel(cand['resultados'],self.ref)
            salvar_json(self.p/'candidatas.json',self.candidatas)
        elegiveis=[c for c in top if c.get('elegivel')]
        if not elegiveis:return self.encerrar('concluido_sem_finalista','Nenhuma candidata cumpriu o criterio fixo de validacao.')
        melhor=min(elegiveis,key=lambda c:(c['score_promocao'][0],c['score_promocao'][2],c['resultados'][0]['parametros'],c['id']))
        finalista={'utc':agora(),'id':melhor['id'],'receita':melhor['proposta']['receita'],
            'score':melhor['score_promocao'],'selecionada_sem_testes':True,'criterio':self.f['configuracao']['selecao']}
        salvar_json(self.p/'finalista.json',finalista)
        self.finalista_sha256=sha256(self.p/'finalista.json')
        self.final_limite=time.time()+12*3600
        salvar_json(self.p/'fase_final.json',{'utc':agora(),'limite_timestamp':self.final_limite,
            'maximo_ajustes':65,'maximo_simulacoes':408,'retrospectiva':True,'finalista_sha256':self.finalista_sha256})
        # A partir daqui nao ha mais chamadas ao Astra nem alteracao da receita.
        for b in FINAIS:
            for v,r in [('referencia',REFERENCIA),('candidata',finalista['receita'])]:
                for s in SEEDS:
                    self.ajuste(r,b,s,'final/'+v)
                    if b=='B1' and v=='candidata' and s==42:
                        self.ajuste(r,b,s,'controles/finalista',True)
                        salvar_json(self.p/'controle_finalista.json',controle_cpu(
                            self.p/'final/candidata/B1_42',self.p/'controles/finalista/B1_42'))
        self.estado('publicacao_final')
        from experimentos.busca_astra.publicacao import publicar
        publicar(self.p)
        return self.encerrar('concluido_conferido','Candidata congelada avaliada; sem promocao automatica.')

def executar():
    import msvcrt
    a=ler_json(RET/'autorizacao.json');ptr=ler_json(REG/'execucao.json')
    assert a['execucao']==ptr and ptr['id']==ID
    conferir_arquivos(RAIZ,a['fontes']);conferir_arquivos(RET,a['snapshots'])
    assert sha256(RET/'preservacao.json')==a['preservacao_sha256']
    p=RAIZ/ptr['pasta'];f=conferir(p,ptr)
    with (REG/'coordenador.lock').open('a+b') as lock:
        lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        assert not (RET/'processo.json').exists(),'Retomada ja iniciada; nao repetir.'
        assert sha256(p/'ajustes.json')==a['snapshots']['anterior_ajustes.json']
        assert sha256(p/'candidatas.json')==a['snapshots']['anterior_candidatas.json']
        conferir_arquivos(RAIZ,ler_json(RET/'preservacao.json')['arquivos'])
        c=Retomada(p,ptr,f)
        assert time.time()<c.triagem_fim,'Prazo original de triagem encerrado.'
        proc={'ativo':True,'pid':os.getpid(),'host':socket.gethostname(),'utc':agora(),'retomada':'001'}
        salvar_json(RET/'processo.json',proc);salvar_json(p/'processo.json',proc)
        try:
            c.estado('retomada_autorizada',consultas_anteriores=7,consultas_restantes=5)
            c.executar()
        except BaseException:
            incidente={'utc':agora(),'situacao':'interrompido','execucao':ptr,'retomada':'001',
                       'erro':traceback.format_exc(),'retomada_automatica':False}
            salvar_json(RET/'incidente.json',incidente);salvar_json(REG/'estado.json',incidente)
            raise
        finally:
            proc.update(ativo=False,utc=agora())
            salvar_json(RET/'processo.json',proc);salvar_json(p/'processo.json',proc)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('acao',choices=['preparar','executar'])
    args=parser.parse_args()
    preparar() if args.acao=='preparar' else executar()

