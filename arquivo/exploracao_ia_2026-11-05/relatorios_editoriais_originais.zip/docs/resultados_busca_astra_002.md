# Busca Astra002 — resultados e encerramento

Execução `932da51c61935c911ec5`, encerrada em04/11/2026 às20:56:59UTC (17:56:59Brasília), sem finalista. Não houve falha registrada, interrupção por cota ou esgotamento do prazo. As12receitas previstas completaram a triagem. Protocolo e critérios permaneceram congelados.

## Cobertura e verificação

100ajustes:18das duas âncoras (3recortes×3seeds×2),72de triagem (12×3×2),9de reforço (3promovidas×3recortes×seed2026),1controle real. Nove consultas Astra, incluindo uma técnica; quatro primeiras receitas predefinidas e oito propostas locais do agente. Controle fora das médias.

109fontes e100ajustes conferidos; MSE e razão ao Naive recalculados em200conjuntos de previsões (V/S); seleção reproduzida e cobertura sem duplicatas. As99linhas científicas foram vinculadas aos artefatos. O executor conferiu45.839arquivos anteriores no fechamento. Recibo posterior: `registros/busca_astra_002/conferencias/2026-11-05T001920.235706_0000/conferencia.json`.

## Critério de leitura

Q é a média de MSE/MSE_Naive nos mesmos recortes e seeds, com peso igual. Na tabela, Q×100:100empata com Naive; menor é melhor. É erro quadrático relativo, não percentual de acertos ou erro percentual de preço. Seleção entre épocas usa V; esta pontuação usa S, os recortes adaptativos de2023. Todas as receitas continuam OHLCV; indicadores são canais adicionais.

## Triagem — duas seeds42/17 em três recortes

| Receita | Pai | Única mudança frente ao pai | Q×100 ↓ |
|---|---|---|---:|
| A0_C05 | — | Âncora | 101.5804 |
| R0_crua_huber | — | Âncora | 101.3690 |
| N01 | A0_C05 | momentum = True | 101.4164 |
| N02 | A0_C05 | volatilidade = True | 101.8870 |
| N03 | A0_C05 | volume_relativo = True | 101.7690 |
| N04 | A0_C05 | pooling = media | 104.9530 |
| N05 | A0_C05 | representacao = relativa | 101.4797 |
| N06 | A0_C05 | contexto = 24 | 101.0825 |
| N07 | N06 | momentum = True | 100.8103 |
| N08 | N07 | dropout = 0.0 | 102.4256 |
| N09 | N07 | dropout = 0.2 | 101.7560 |
| N10 | N07 | taxa = 0.0001 | 101.7952 |
| N11 | N09 | momentum = False | 101.6265 |
| N12 | N09 | contexto = 72 | 101.6417 |

N07, N06 e N01 foram as três menores médias de triagem. As demais não receberam a terceira seed; não misturar suas médias de duas seeds com a comparação ampliada abaixo.

## Comparação ampliada — três seeds42/17/2026, nove ajustes por receita

| Receita | Q×100 ↓ |
|---|---:|
| Naive | 100,0000 |
| R0_crua_huber | 101.3510 |
| A0_C05 | 101.4131 |
| N07 | 101.6391 |
| N01 | 101.9761 |
| N06 | 102.2799 |

Nenhuma candidata superou o Naive ou as duas âncoras no critério primário com três seeds. N07 é a menor média entre as promovidas:contexto24h+momentum24/168. N06 é contexto24h sem esses canais; N01 é contexto72h+momentum.

As vantagens parciais não resistiram à terceira seed. N06 passou deQ1,010825 na triagem para1,022799; a seed2026 isolada teveQ1,046747. N07 passou de1,008103 para1,016391; a seed2026 teve1,032967. Isto demonstra sensibilidade à inicialização nesta amostra; não prova inferioridade universal das receitas.

## Por que não houve finalista

Era necessário Q≤0,999; vencer a melhor âncora em≥6/9pares e≥2/3recortes; respeitar limites de piora por recorte e MAE. As três falharam no limiteQ, nas vitórias por pares e na cobertura temporal: N07/N06 venceram5/9pares, N01 venceu2/9; cada uma venceu somente um dos três recortes. Limites de piora máxima e MAE passaram, mas isso não basta para aprovar.

A triagem e o reforço previstos terminaram. Por não haver elegível, os97ajustes finais possíveis e as800carteiras condicionais não foram iniciados. Foram zero avaliações finais em oito seeds e zero novas simulações operacionais nesta rodada. Os197ajustes e24h eram tetos, não metas de consumo. Tempo total desde preparo operacional:aproximadamente3h21; desde lançamento:3h09.

## Interpretação para o TCC

A busca local encontrou pequenas melhorias exploratórias que não se sustentaram no reforço pareado. Isso justifica preservar as referências e reportar resultado negativo, sem promover nova receita. Não implica que Mamba nunca preveja, que indicadores sejam inúteis ou que outra busca necessariamente melhore. Não houve teste estatístico final em oito seeds nem resultado operacional novo.2023é desenvolvimento adaptativo já consultado;2024–2025 também são retrospectivos no projeto, mas não foram reavaliados nesta busca porque nenhuma candidata passou.

## Evidências

- Protocolo: [busca Astra002](protocolo_busca_astra_002.md).
- Estado: [registro atual](../registros/busca_astra_002/estado.json).
- Desenvolvimento, propostas, receitas, seleção e controles: `dados/experimentos/busca_astra_002_932da51c61935c911ec5`.
- Relatório mínimo original do executor permanece intacto em `dados/experimentos/busca_astra_002_932da51c61935c911ec5/relatorio.md`.
- Nenhum novo treino, busca, mudança de critério ou promoção foi iniciado nesta conferência.
