# Busca adaptativa assistida por Astra — resultados

Concluída e conferida em 04/11/2026 às04h25 de Brasília. Execução `b34bad73d6cef1d10a97`: 11candidatas,106ajustes incluindo controles,64ajustes finais principais e408carteiras. Nenhuma promoção automática da referência.

A candidata C05 combina OHLCV relativo à própria janela, contexto72h e Huber; mantém estado16, duas camadas, AdamW e taxa0,0002. Foi congelada antes da avaliação retrospectiva. O contraste reúne mudanças e não identifica o efeito isolado de cada uma.

## Precisão: médias das oito seeds e quatro blocos

Cada métrica é calculada por modelo e depois recebe peso igual entre seeds/blocos. Não é ensemble. Naive prevê log-retorno zero e não depende de seed. RMSE médio é média dos RMSEs, não raiz do MSE agregado.

| Versão | MSE | RMSE | MAE | Balanced accuracy |
|---|---:|---:|---:|---:|
| referencia | 0.0006212452 | 0.0247827 | 0.0179585 | 49.60% |
| candidata | 0.0006122753 | 0.0245987 | 0.0177640 | 49.59% |
| naive | 0.0006092954 | 0.0245283 | 0.0176953 | Não comparada |

A candidata reduz MSE1,44% e MAE1,08% frente à referência. Frente ao Naive, MSE0,49% e MAE0,39% maiores. Melhor MSE médio nos quatro blocos,22/32pares e6/8seeds ao agregar blocos; isso não é teste de significância.

IC97,5% pareado principal (dias14,2.000réplicas, dois contrastes): candidata−referência de−0,0000222306 a+0,0000039092; candidata−Naive de−0,0000043681 a+0,0000113203. Ambos incluem zero, assim como sensibilidades7/28dias. São intervalos condicionais, sem corrigir toda a seleção adaptativa.

## Simulação operacional

Spot, sem alavancagem; decisão diária, latência1min, dados de1min,10.000USDT novos por carteira/bloco. Cenário base: comissão0,10% e slippage0,05% por lado. Smart compra/vende frações e mantém posição entre decisões; parâmetro2% não é stop-loss. Diária24 liquida diariamente e só compra quando previsão excede o limiar fixo dos custos base (~0,30%). Cenários de custos não recalibram esse sinal.

| Bloco | Smart referência | Smart candidata | Diária24 referência | Diária24 candidata | Comprar/manter |
|---|---:|---:|---:|---:|---:|
| B1 | +14.87% | +36.01% | -1.29% | +3.17% | +43.76% |
| B2 | +36.83% | +21.06% | -1.71% | -3.55% | +47.35% |
| B3 | +7.66% | +10.50% | -3.16% | +0.63% | +15.37% |
| B4 | -13.68% | -18.97% | -14.68% | -12.42% | -17.69% |

| Política/custos | Referência | Candidata |
|---|---:|---:|
| smart/ideal | +12.63% | +12.93% |
| smart/base | +11.42% | +12.15% |
| smart/agravado | +10.23% | +11.38% |
| diaria24/ideal | +1.16% | +4.31% |
| diaria24/base | -5.21% | -3.04% |
| diaria24/agravado | -10.78% | -9.54% |

Médias operacionais são descritivas de carteiras independentes, não retorno acumulado de2024–2025. Naive zero mantém caixa nas duas políticas (0%, sem remuneração). Smart candidata piora emB2/B4; emB4, exposição média90,24% versus32,30% e drawdown médio34,59% versus23,26%. Comprar/manter supera o retorno Smart médio da candidata nos quatro blocos. Não foram calculados intervalos operacionais específicos nesta publicação.

## Interpretação e evidências

Melhora descritiva pequena frente à referência, sem evidência estatística conclusiva ou superação do Naive. Desvio médio das previsões cai de0,00370 para0,00184, frente a0,02448dos alvos: compatível com previsões mais conservadoras, não prova de nova capacidade de antecipar movimentos. Balanced accuracy permanece perto de50%. Resultados operacionais dependem da política, exposição e custos; não demonstram lucro futuro.2024/2025já consultados, sem novo holdout.

[Resultados completos](../dados/experimentos/busca_astra_b34bad73d6cef1d10a97/publicacoes/tentativa_001/resultados.json), [manifesto](../dados/experimentos/busca_astra_b34bad73d6cef1d10a97/publicacoes/tentativa_001/manifesto.json), [conferência posterior](../registros/busca_astra/conferencias/fechamento_20261104/conferencia.json), [fechamento](../registros/busca_astra/fechamento.json). O relatório automático original permanece na publicação imutável.
