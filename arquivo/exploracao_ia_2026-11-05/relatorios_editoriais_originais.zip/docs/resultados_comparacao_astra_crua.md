# Candidata Astra versus OHLCV cru + Huber

Execução `ce284eb4a489f604fb9c`. Mesmos dados, executor científico e oito seeds/quatro blocos.32Astra herdados;32crus novos;dois controles excluídos das médias.

| Versão | MSE médio teste | RMSE médio | MAE médio |
|---|---:|---:|---:|
| astra | 0.0006122753 | 0.0245987 | 0.0177640 |
| crua | 0.0006114371 | 0.0245711 | 0.0177258 |
| naive | 0.0006092954 | 0.0245283 | 0.0176953 |

## Incerteza

Diferença negativa favorece o primeiro modelo. IC98,333% ajustado para três contrastes; bootstrap pareado de seeds/dias14.

| Contraste | Diferença MSE | IC ajustado |
|---|---:|---|
| astra_menos_crua | 8.38188425e-07 | [-7.266237654168076e-06, 9.532796518630295e-06] |
| astra_menos_naive | 2.97989583e-06 | [-4.88912043592503e-06, 1.2208151581791196e-05] |
| crua_menos_naive | 2.1417074e-06 | [-1.2490747545031659e-06, 5.897950261652832e-06] |

## Operação: média das oito seeds, custos base

| Bloco | Smart Astra | Smart crua | Diária Astra | Diária crua |
|---|---:|---:|---:|---:|
| B1 | +36.01% | +6.06% | +3.17% | +0.00% |
| B2 | +21.06% | +0.00% | -3.55% | +0.00% |
| B3 | +10.50% | +13.38% | +0.63% | +0.00% |
| B4 | -18.97% | -21.78% | -12.42% | +0.00% |

192carteiras novas,216herdadas; custos e políticas inalterados. Smart mantém posição; parâmetro2% não é stop-loss. Naive mantém caixa nessas políticas.

2024/2025 conhecidos; comparacao retrospectiva, sem novo holdout.
Duas mudancas simultaneas: representacao e contexto. Nao isola efeito individual.
Medias de oito modelos individuais por bloco; nao ensemble.
Carteiras independentes, sem compor retornos dos quatro blocos.
Intervalos condicionais nao corrigem a selecao previa de receitas.
Sem novas consultas Astra, busca de configuracoes ou promocao automatica.

[Dados completos](../dados/experimentos/comparacao_astra_crua_ce284eb4a489f604fb9c/publicacoes/tentativa_001/resultados.json).

## Interpretação após conferência independente

Concluída em04/11/2026 às06h39 de Brasília:34ajustes novos(32principais e2controles),32modelos Astra herdados,192carteiras novas e216herdadas. Os controles passaram; mesma época e diferenças de previsões abaixo de1e−5. Nenhuma nova promoção ou busca.

Crua apresenta MSE0,1369%menor e MAE0,2149%menor que Astra. Ambas permanecem acima do Naive em MSE:crua+0,3515%,Astra+0,4891%. A diferença entre receitas é pequena e todos os intervalos95%/98,333%incluem zero nas sensibilidades7/14/28dias. Não comprova igualdade nem superioridade. Astra melhora em3/4blocos,21/32pares e5/8seeds quando agregadas; vantagem crua emB4 compensa as vantagens Astra nos demais blocos.

| Bloco | MSE Astra | MSE crua | MSE Naive |
|---|---:|---:|---:|
| B1 | 0.0007275784 | 0.0007291058 | 0.0007274219 |
| B2 | 0.0007201639 | 0.0007213869 | 0.0007158615 |
| B3 | 0.0005860437 | 0.0005892561 | 0.0005900900 |
| B4 | 0.0004153154 | 0.0004059997 | 0.0004038083 |

Balanced accuracy média:Astra49,59%,crua50,18%; acurácia direcional50,37% e49,75%, respectivamente. Não há evidência de forte capacidade direcional.

Smart base, média descritiva de carteiras independentes:Astra+12,15%,crua−0,59%; exposição média72,68% e44,25%; drawdown médio24,23% e15,76%. A maior rentabilidade média Astra vem com mais exposição/risco. Comprar/manter supera o retorno médio Astra em cada um dos quatro blocos; Naive mantém caixa. Não foi calculado intervalo específico de retorno operacional, e essas médias não são retorno acumulado de dois anos.

Diária24:crua0%nos32modelos,sem qualquer ordem; Astra−3,04%com custos base,versus+4,31%sem custos e−9,54%com custos agravados. O maior sinal cru observado nos horários de decisão é0,00134508de log-retorno(~0,135%),abaixo do limiar fixo~0,30%. O zero representa permanecer em caixa,não lucro ou acerto de timing. Smart admite compras fracionadas abaixo desse limiar e mantém posição,por isso pode investir mesmo com previsões pequenas.

O desvio temporal médio das previsões é0,00019366na crua e0,00183976na Astra,contra0,02447833dos alvos. Isso documenta forte compressão da amplitude,especialmente na crua; não prova que a representação ou a LayerNorm isoladamente causaram o fenômeno. EmB4 a crua prevê retorno positivo em100%das origens,apesar da perda na carteira. Os diagnósticos impedem interpretar MSE menor como capacidade operacional superior.

Conclusão:comparação retrospectiva justa não identificou vencedora inequívoca. Crua vence marginalmente no erro agregado; Astra tem sinais mais variáveis e retorno Smart maior nesta amostra,mas não vence todas as políticas/risco nem o benchmark passivo. As duas continuam abaixo do Naive na média de erro. Não atribuir resultado a um único fator:contexto e representação diferem.

Conferência posterior:[recibo](../registros/comparacao_astra_crua/conferencias/2026-11-04T140451.547483_0000/conferencia.json). Foram conferidas fontes/manifestações,64séries com MSE/MAE recalculados e408carteiras reconciliadas com auditorias; todos os32casos diários crus sem ordens foram verificados. Não houve repetição de treino,simulação ou bootstrap. O relatório automático original permanece na publicação congelada.
