# Smart retida: comparação Spot/futuros e filtro — F02

Execução `9e1d6c3686499c020389` concluída e conferida: **1.632 carteiras, zero novos treinamentos**, 64 séries herdadas. [Método congelado](protocolo_smart_mercados.md), [decisão](adr/0025-smart-spot-futuros.md), [estado](../registros/smart_mercados/estado.json).

Quatro blocos independentes de2024–2025,727datas, oito seeds por receita. Primeiro média de seeds por bloco, depois peso igual entre os quatro blocos. Percentuais não são retorno acumulado de dois anos nem retorno anual.

A Smart ajusta parcialmente e mantém posição: não liquida diariamente. Mesma reserva5%, quantidade causal, mínimo100USDT, passo0,001BTC e cobrança equivalenteUSDT nos mercados. Essa Smart95 comum não é reprodução exata da Smart histórica; usar comparações dentro desta rodada.

## Resultado principal, custos iguais

Comissão0,05% e slippage0,05% por ajuste em ambos os mercados. Funding histórico nos braços designados.

| Receita | Política | Spot comprado | Futuro comprado sem funding | Futuro comprado com funding | Futuro bilateral com funding |
|---|---|---:|---:|---:|---:|
| astra | smart | +11.75% | +11.74% | +8.52% | +1.46% |
| astra | smart_filtrada | +9.30% | +9.30% | +6.83% | +2.23% |
| crua | smart | -1.25% | -1.25% | -1.97% | -13.08% |
| crua | smart_filtrada | +0.00% | +0.00% | +0.00% | +0.00% |

## Diferenças pareadas

Cada diferença usa os mesmos32pares bloco/seed. Pontos percentuais positivos favorecem o primeiro termo. Contagens não equivalem a teste de significância; não foi calculado intervalo confirmatório.

| Receita | Política | Contraste | Diferença média p.p. | Pares com ganho |
|---|---|---|---:|---:|
| astra | smart | futuro_sem_funding_menos_spot | -0.01 | 9/32 |
| astra | smart | futuro_menos_futuro_sem_funding | -3.22 | 0/32 |
| astra | smart | futuro_menos_spot | -3.23 | 0/32 |
| astra | smart | futuro_bilateral_menos_futuro | -7.06 | 15/32 |
| astra | smart_filtrada | futuro_sem_funding_menos_spot | -0.00 | 10/32 |
| astra | smart_filtrada | futuro_menos_futuro_sem_funding | -2.47 | 0/32 |
| astra | smart_filtrada | futuro_menos_spot | -2.47 | 0/32 |
| astra | smart_filtrada | futuro_bilateral_menos_futuro | -4.60 | 2/32 |
| crua | smart | futuro_sem_funding_menos_spot | +0.01 | 1/32 |
| crua | smart | futuro_menos_futuro_sem_funding | -0.73 | 0/32 |
| crua | smart | futuro_menos_spot | -0.72 | 0/32 |
| crua | smart | futuro_bilateral_menos_futuro | -11.10 | 2/32 |
| crua | smart_filtrada | futuro_sem_funding_menos_spot | +0.00 | 0/32 |
| crua | smart_filtrada | futuro_menos_futuro_sem_funding | +0.00 | 0/32 |
| crua | smart_filtrada | futuro_menos_spot | +0.00 | 0/32 |
| crua | smart_filtrada | futuro_bilateral_menos_futuro | +0.00 | 0/32 |
| astra | spot | filtrada_menos_smart | -2.45 | 11/32 |
| astra | futuro_sem_funding | filtrada_menos_smart | -2.44 | 12/32 |
| astra | futuro | filtrada_menos_smart | -1.69 | 13/32 |
| astra | futuro_bilateral | filtrada_menos_smart | +0.76 | 12/32 |
| crua | spot | filtrada_menos_smart | +1.25 | 8/32 |
| crua | futuro_sem_funding | filtrada_menos_smart | +1.25 | 8/32 |
| crua | futuro | filtrada_menos_smart | +1.97 | 8/32 |
| crua | futuro_bilateral | filtrada_menos_smart | +13.08 | 20/32 |

## Blocos: Smart sem filtro, custos iguais

| Bloco | Receita | Spot | Futuro comprado | Futuro bilateral |
|---|---|---:|---:|---:|
| B1 | astra | +33.30% | +25.97% | +25.07% |
| B1 | crua | +2.04% | +1.41% | -5.37% |
| B2 | astra | +20.84% | +19.12% | -9.28% |
| B2 | crua | +0.00% | +0.00% | -37.62% |
| B3 | astra | +10.12% | +8.22% | +8.08% |
| B3 | crua | +7.45% | +6.59% | +6.59% |
| B4 | astra | -17.27% | -19.23% | -18.02% |
| B4 | crua | -14.50% | -15.90% | -15.90% |

## Risco, exposição e frequência — custos iguais

| Receita | Política | Braço | Drawdown médio | Exposição média absoluta | Ordens médias | Carteiras ativas |
|---|---|---|---:|---:|---:|---:|
| astra | smart | futuro | 23.17% | 67.04% | 82.2 | 31/32 |
| astra | smart | futuro_bilateral | 24.17% | 63.16% | 100.1 | 32/32 |
| astra | smart | futuro_sem_funding | 22.56% | 66.91% | 83.3 | 31/32 |
| astra | smart | spot | 22.50% | 66.92% | 83.3 | 31/32 |
| astra | smart_filtrada | futuro | 19.67% | 58.30% | 17.5 | 30/32 |
| astra | smart_filtrada | futuro_bilateral | 21.28% | 56.35% | 18.6 | 31/32 |
| astra | smart_filtrada | futuro_sem_funding | 19.15% | 57.97% | 18.0 | 30/32 |
| astra | smart_filtrada | spot | 19.12% | 57.98% | 18.0 | 30/32 |
| crua | smart | futuro | 10.17% | 26.79% | 20.9 | 20/32 |
| crua | smart | futuro_bilateral | 30.97% | 67.84% | 38.4 | 32/32 |
| crua | smart | futuro_sem_funding | 9.99% | 26.80% | 21.2 | 20/32 |
| crua | smart | spot | 9.96% | 26.79% | 21.2 | 20/32 |
| crua | smart_filtrada | futuro | 0.00% | 0.00% | 0.0 | 0/32 |
| crua | smart_filtrada | futuro_bilateral | 0.00% | 0.00% | 0.0 | 0/32 |
| crua | smart_filtrada | futuro_sem_funding | 0.00% | 0.00% | 0.0 | 0/32 |
| crua | smart_filtrada | spot | 0.00% | 0.00% | 0.0 | 0/32 |

## Sensibilidade de custos e referências

Ideal zera execução, mas preserva funding. Por mercado: Spot0,10% e futuro0,05% de comissão; slippage0,05% nos dois. Política/filtro não mudam entre cenários.

| Receita | Política | Braço | Ideal | Custos iguais | Custos por mercado |
|---|---|---|---:|---:|---:|
| astra | smart | spot | +12.17% | +11.75% | +11.52% |
| astra | smart | futuro | +8.94% | +8.52% | +8.52% |
| astra | smart | futuro_bilateral | +2.11% | +1.46% | +1.46% |
| astra | smart_filtrada | spot | +9.52% | +9.30% | +9.18% |
| astra | smart_filtrada | futuro | +7.06% | +6.83% | +6.83% |
| astra | smart_filtrada | futuro_bilateral | +2.52% | +2.23% | +2.23% |
| crua | smart | spot | -1.18% | -1.25% | -1.29% |
| crua | smart | futuro | -1.92% | -1.97% | -1.97% |
| crua | smart | futuro_bilateral | -12.97% | -13.08% | -13.08% |
| crua | smart_filtrada | spot | +0.00% | +0.00% | +0.00% |
| crua | smart_filtrada | futuro | +0.00% | +0.00% | +0.00% |
| crua | smart_filtrada | futuro_bilateral | +0.00% | +0.00% | +0.00% |
| comprar_manter | smart | spot | +21.40% | +21.19% | +21.08% |
| comprar_manter | smart | futuro | +16.18% | +15.97% | +15.97% |
| comprar_manter | smart | futuro_bilateral | +16.18% | +15.97% | +15.97% |
| caixa | smart | spot | +0.00% | +0.00% | +0.00% |
| caixa | smart | futuro | +0.00% | +0.00% | +0.00% |
| caixa | smart | futuro_bilateral | +0.00% | +0.00% | +0.00% |

## Como interpretar

O filtro usa magnitude fixa≈0,30%, baseada nos custos Spot anteriores, igual em todos os mercados. Abaixo disso mantém a posição já aberta. Pode reduzir giro e prejuízos, mas também exposição a altas e velocidade de saída; não mede confiança do modelo e não garante lucro. Carteira em caixa não comprova acerto preditivo.

O braço futuro sem funding é contrafactual, não uma modalidade negociável. Sua diferença para Spot inclui preços negociados, marcação e efeito desses preços no dimensionamento. Funding também altera patrimônio e operações posteriores: a diferença entre braços não é apenas a soma dos pagamentos.

Mesmos modelos e previsões: MSE/MAE não mudaram. Resultados retrospectivos, sem novo holdout e sem promoção automática por lucro. Mais carteiras não são amostras independentes. As médias por seed/bloco e os contrastes completos estão na publicação.

Exposição controlada na abertura/aumento; perdas podem elevar exposição efetiva. Buffer prudencial2% não é fórmula integral de liquidação Binance; violação interromperia a rodada. Custos/filtros são hipóteses, sem livro de ofertas ou certificação de conta real. Sem ordens reais ou novos treinamentos.

Auditoria posterior: [recibo](../registros/smart_mercados/conferencias/2026-11-04T160336.944682_0000/conferencia.json). Dados completos em `dados/experimentos/smart_mercados_9e1d6c3686499c020389/publicacao/resultados.json`; ordens, funding, diários e curvas preservados por carteira. Ledgers/curvas volumosos locais, resumos/fontes/manifestos elegíveis ao Git. Estudos anteriores intactos.


## Interpretação do fechamento

A comparação controlada esclarece a divergência anterior. Astra comprado teve+11,75%noSpot e+11,74%no futuro sem funding: diferença média de apenas−0,006ponto percentual. Com funding, o futuro comprado caiu para+8,52%; inclusão do financiamento reduziu3,22pontos percentuais, incluindo sua repercussão no patrimônio/tamanho posterior. Custos por mercado:SpotAstra+11,52% e futuro+8,52%. Não há a grande inversão observada ao comparar SmartSpot com uma política futura diária distinta.

A extensão bilateral manteve lucro médio Astra de+1,46%,mas ficou7,06pontos abaixo do futuro comprado. Foi melhor em15/32pares bloco/seed,porém pior nas médias dos quatro blocos de cada uma das8seeds. Crua bilateral teve−13,08%. Portanto,não há suporte nesta rodada para preferir automaticamente a extensão vendida.

Filtro≈0,30%:Astra comprado em futuros passou de+8,52%para+6,83%,com queda do drawdown médio de23,17%para19,67% e de82,2para17,5ordens por carteira. No bilateral,Astra passou de+1,46%para+2,23%,drawdown de24,17%para21,28% e ordens de100,1para18,6. Ganho de retorno bilateral apareceu em12/32pares; não é melhora generalizada ou significativa demonstrada. Na crua,o filtro impediu todas as ordens em todos os braços:0%é caixa,não evidência de previsão útil.

Comprar/manter95% apresentou maior retorno médio:Spot+21,19% e futuro com funding+15,97%,com drawdowns médios28,79% e30,09%. Astra comprado teve menor retorno e também menor exposição/drawdown. Lucro Smart não demonstra que o modelo supera uma estratégia passiva; comparar risco,exposição e retorno conjuntamente.

Fechamento:18testes aprovados,1.632auditorias por carteira e conferência posterior independente dos totais/médias.25.918arquivos anteriores preservados,não houve recusa de ordem ou violação do envelope prudencial. Essa validação não certifica uma conta real nem remove a exposição prévia aos testes2024–2025. Sem novo treinamento,sem alteração das previsões e sem promoção de modelo/política.


## Diagnóstico posterior de direção e atribuição — 04/11/2026

Esta conferência adicional qualifica a interpretação anterior, sem mudar fontes/protocolo/publicação ou executar novas carteiras. Foram relidas64séries e reconciliadas128carteiras Smart/custos iguais (comprada e bilateral). [Recibo e fonte de análise](../registros/smart_mercados/diagnosticos/2026-11-04T161117.730616_0000/diagnostico.json).

**Limitação do contraste bilateral:** não é uma ablação pura de acrescentar shorts mantendo todas as compras/vendas anteriores. Para intensidade negativa d, a Smart comprada vende−d da posição q; a bilateral ajusta d×(0,95E+qP)/P,aproximando-se da capacidade vendida. Portanto,também reduz compras mais rapidamente antes mesmo de ficar vendida. Isso segue a fórmula congelada,mas a descrição resumida de “só permitir shorts” era insuficiente. A comparação Spot comprado versus futuro comprado permanece com a mesma política; a extensão bilateral combina permissão de shorts e diferente dinâmica de redução/reversão.

Exemplo,antes de quantização/custos:E=10.000USDT,posição comprada equivalente a5.000USDT,intensidade−10%. A comprada reduz500USDT;a bilateral reduz1.450USDT. Não atribuir toda diferença final apenas a operações vendidas.

Atribuição contábil exata,em pontos percentuais do capital inicial10.000USDT,média das32carteiras,com preços,custos,funding e resíduo marcado:

| Receita | Comprada: contribuição long | Bilateral: contribuição long | Bilateral: contribuição short | Bilateral: total |
|---|---:|---:|---:|---:|
| Astra |+8,52|+4,80|−3,34|+1,46|
| Crua |−1,97|−1,99|−11,09|−13,08|

Na Astra,a perda relativa de7,06pontos contém3,34pontos de contribuição negativa dos shorts e3,72pontos de redução da contribuição comprada. É uma identidade contábil das trajetórias realizadas,não um efeito causal de remover shorts mantendo o restante fixo. Na crua,a contribuição short negativa domina a diferença. Funding dos shorts foi positivo em média (Astra+35,91USDT,crua+182,92USDT); o movimento dos preços foi adverso (−349,22 e−1.284,53USDT respectivamente),antes das comissões/slippage.

Diagnóstico de sinais:727datas×8seeds por receita,sem considerar repetições de seeds como dias independentes. Taxas abaixo são **contagens agrupadas condicionadas ao sinal**,não média das taxas de cada seed/bloco. Alvo observado Spot de24h das previsões originais:

| Receita | Precisão quando prevê queda | Precisão quando prevê alta | Retorno médio real após previsão de queda |
|---|---:|---:|---:|
| Astra |49,59%|51,69%|+0,212%|
| Crua |48,12%|50,87%|+0,231%|

Nas datas únicas,51,31%dos dias tiveram alta; taxa de acerto precisa ser contextualizada com essa frequência e magnitudes. Após sinal negativo Astra,as quedas acertadas tiveram magnitude média1,61%,mas as altas contrárias tiveram2,00%. Na crua,1,85%versus2,16%. Direção quase50% não implica equilíbrio econômico. No horizonte de execução futuro00:01→00:01,o acerto de sinais negativos foi49,07%/47,64%,e o retorno do ativo após esses sinais permaneceu positivo em média(+0,209%/+0,230%). Nenhuma nova estratégia foi simulada a partir dessas observações.

Na crua,28/32combinações bloco/seed mantêm a mesma direção durante todo o bloco. Todas as8seeds doB2 sempre preveem queda; todas as8doB4 sempre alta. Isso indica pouca discriminação temporal do sinal,compatível com viés persistente próximo de zero. Não estabelece por si só a causa na entrada,perda,otimizador ou arquitetura. Na Astra,os sinais de queda tiveram retorno real médio positivo emB1/B2 e negativo emB3/B4:há dependência de período,não incapacidade universal de prever quedas.

A Smart retida também pode manter short após um sinal positivo,desmontando gradualmente:isso ocorreu em29,4%dos dias vendidos doAstra. Logo,o retorno de uma posição mantida não equivale ao resultado de executar cada previsão isoladamente por24h. Esses dias,por si sós,não explicam o prejuízo:na atribuição observada sua contribuição bruta foi positiva; o diagnóstico registra a diferença entre sinal e posição.

Conclusão delimitada:os shorts prejudicaram a amostra,e os sinais negativos mostram fragilidade econômica,especialmente na crua. O resultado não demonstra que Mamba seja intrinsecamente incapaz de prever quedas nem que Spot seja sempre superior. Uma futura ablação de shorts precisaria manter idêntica a política no domínio comprado e documentar separadamente o que ocorre ao cruzar zero. Não inverter sinais/selecionar limiar com esses mesmos testes para alegar ganho confirmado.
