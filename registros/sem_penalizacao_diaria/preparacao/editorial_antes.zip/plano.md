# Plano de trabalho

Atualizado em 08/11/2026. Rodada de **padronização dos seis canais diários concluída e conferida**, execução `f3f8772670f244779ad7`. [Estado](registros/padronizacao_diaria/estado.json), [protocolo preservado](docs/protocolo_padronizacao_diaria.md), [análise na cronologia](docs/andamento.md), [conferência independente](registros/padronizacao_diaria/conferencias/2026-11-08T080345.207956_0000/conferencia.json).

Foram concluídos os quatro ajustes de 1000 épocas, controle exato e 70 carteiras. Referência de retorno `de09c2193737c2581261` herdada sem retreino; preservação aprovada. A análise separa a média das métricas/carteiras individuais da carteira que opera a média das previsões (ensemble). Não promover uma versão apenas pelo lucro retrospectivo ou pelo erro agregado.

Diagnóstico posterior concluído sem atualizações de pesos: os ramos Mamba perderam contribuição, e a predição passou a depender do caminho residual linear. Isso também aparece na referência de retorno, não apenas após padronizar. [Evidências e proposta](registros/padronizacao_diaria/diagnosticos/2026-11-08T200124.658529Z/conclusao.json).

Próximo teste recomendado, **ainda não autorizado**: alterar somente `weight_decay` do Adam de 0,001 para zero, mantendo a receita padronizada, três seeds e controle, seleção e simulações. Testa a hipótese de supressão dos ramos por regularização; não pressupõe ganho. Registrar contribuição dos ramos e normas/gradientes junto às métricas e à estabilidade operacional. A direção do eixo SSM, taxa de aprendizagem e representação dos canais são questões separadas, não alterar simultaneamente.

2024 selecionou checkpoints; 2025 já foi consultado e é retrospectivo. A autorização da padronização terminou. Nenhum treinamento adicional iniciado. A [cronologia](docs/andamento.md) e o [catálogo](registros/catalogo_estudos.json) preservam resultados, incidentes e decisões anteriores.
