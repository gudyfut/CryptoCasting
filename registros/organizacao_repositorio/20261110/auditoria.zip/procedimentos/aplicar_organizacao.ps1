param([Parameter(Mandatory=$true)][string]$Manifesto, [switch]$Executar)
$ErrorActionPreference = 'Stop'
$raizOrganizacao = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$dadosOrganizacao = Get-Content -LiteralPath $Manifesto -Raw -Encoding UTF8 | ConvertFrom-Json
if ([IO.Path]::GetFullPath($dadosOrganizacao.raiz) -ne $raizOrganizacao) { throw 'Raiz do manifesto divergente' }
function CaminhoSeguro([string]$relativo) {
    if ([IO.Path]::IsPathRooted($relativo)) { throw 'Caminho absoluto no manifesto' }
    $p = [IO.Path]::GetFullPath((Join-Path $raizOrganizacao $relativo))
    if (-not $p.StartsWith($raizOrganizacao + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw "Fora do repositorio: $relativo" }
    if (Test-Path -LiteralPath $p) {
        $resolvido = (Resolve-Path -LiteralPath $p).Path
        if (-not $resolvido.StartsWith($raizOrganizacao + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Resolucao fora do repositorio' }
        $item = Get-Item -LiteralPath $p -Force
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Nao operar sobre links ou junctions' }
    }
    return $p
}
function HashArquivo([string]$p) { return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() }
$pacoteOrganizacao = CaminhoSeguro $dadosOrganizacao.pacote
if ((HashArquivo $pacoteOrganizacao) -ne $dadosOrganizacao.pacote_sha256) { throw 'Pacote de preservacao divergente' }
$fixosOrganizacao = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($nome in $dadosOrganizacao.fixos) { [void]$fixosOrganizacao.Add($nome) }
$protegidosOrganizacao = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($nome in $dadosOrganizacao.protegidos_caches) { [void]$protegidosOrganizacao.Add($nome) }
foreach ($acao in $dadosOrganizacao.acoes) {
    $p = CaminhoSeguro $acao.origem
    if ($fixosOrganizacao.Contains($acao.origem)) { throw "Fonte ativa ou da interface: $($acao.origem)" }
    if ((HashArquivo $p) -ne $acao.sha256) { throw "Origem modificada desde a preservacao: $($acao.origem)" }
    if ($acao.acao -eq 'mover') {
        $destino = CaminhoSeguro $acao.destino
        if (Test-Path -LiteralPath $destino) { throw "Destino ja existe: $destino" }
    } elseif ($acao.acao -ne 'arquivar') { throw 'Acao desconhecida' }
}
foreach ($cache in $dadosOrganizacao.caches) {
    [void](CaminhoSeguro $cache.origem)
    if ($fixosOrganizacao.Contains($cache.origem) -or $protegidosOrganizacao.Contains($cache.origem)) { throw 'Cache esta referenciado por hash' }
    if ($cache.origem -notmatch '(^|/)(__pycache__|\.pytest_cache|\.mypy_cache|\.ruff_cache)/' -and -not $cache.origem.StartsWith('dataview/.next/')) { throw 'Arquivo fora dos caches permitidos' }
}
if (-not $Executar) {
    [pscustomobject]@{fase='preverificacao';acoes=$dadosOrganizacao.acoes.Count;caches=$dadosOrganizacao.caches.Count} | ConvertTo-Json
    exit 0
}
$arquivadosOrganizacao = [Collections.Generic.List[string]]::new()
$movidosOrganizacao = [Collections.Generic.List[object]]::new()
$cachesOrganizacao = [Collections.Generic.List[string]]::new()
$ignoradosOrganizacao = [Collections.Generic.List[string]]::new()
$pastasOrganizacao = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$bytesCachesOrganizacao = 0L
foreach ($acao in $dadosOrganizacao.acoes) {
    $p = CaminhoSeguro $acao.origem
    if ($acao.acao -eq 'mover') {
        $destino = CaminhoSeguro $acao.destino
        $pai = [IO.Path]::GetDirectoryName($destino)
        [void][IO.Directory]::CreateDirectory($pai)
        [void](CaminhoSeguro ([IO.Path]::GetRelativePath($raizOrganizacao,$pai)))
        Move-Item -LiteralPath $p -Destination $destino
        if ((HashArquivo $destino) -ne $acao.sha256) { throw 'Destino divergente apos mover' }
        $movidosOrganizacao.Add([pscustomobject]@{origem=$acao.origem;destino=$acao.destino;sha256=$acao.sha256})
    } else {
        Remove-Item -LiteralPath $p
        $arquivadosOrganizacao.Add($acao.origem)
    }
    $pai = [IO.Path]::GetDirectoryName($p)
    while ($pai -ne $raizOrganizacao -and $pai.StartsWith($raizOrganizacao + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {
        [void]$pastasOrganizacao.Add($pai); $pai=[IO.Path]::GetDirectoryName($pai)
    }
}
foreach ($cache in $dadosOrganizacao.caches) {
    $p = CaminhoSeguro $cache.origem
    if (-not (Test-Path -LiteralPath $p) -or (HashArquivo $p) -ne $cache.sha256) { $ignoradosOrganizacao.Add($cache.origem); continue }
    Remove-Item -LiteralPath $p
    $cachesOrganizacao.Add($cache.origem); $bytesCachesOrganizacao += $cache.bytes
}
foreach ($pasta in $dadosOrganizacao.pastas_caches) { [void]$pastasOrganizacao.Add((CaminhoSeguro $pasta)) }
$vaziasOrganizacao = [Collections.Generic.List[string]]::new()
foreach ($p in ($pastasOrganizacao | Sort-Object Length -Descending)) {
    if ((Test-Path -LiteralPath $p -PathType Container) -and -not [IO.Directory]::EnumerateFileSystemEntries($p).GetEnumerator().MoveNext()) {
        [void](CaminhoSeguro ([IO.Path]::GetRelativePath($raizOrganizacao,$p)))
        Remove-Item -LiteralPath $p
        $vaziasOrganizacao.Add([IO.Path]::GetRelativePath($raizOrganizacao,$p))
    }
}
$reciboOrganizacao = [ordered]@{utc=[DateTime]::UtcNow.ToString('o');arquivados=@($arquivadosOrganizacao);movidos=@($movidosOrganizacao);caches_excluidos=@($cachesOrganizacao);bytes_caches=$bytesCachesOrganizacao;caches_modificados_ignorados=@($ignoradosOrganizacao);pastas_vazias_removidas=@($vaziasOrganizacao);pacote_sha256=$dadosOrganizacao.pacote_sha256}
$saidaOrganizacao = Join-Path ([IO.Path]::GetDirectoryName((Resolve-Path -LiteralPath $Manifesto).Path)) 'aplicacao.json'
[IO.File]::WriteAllText($saidaOrganizacao,($reciboOrganizacao | ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
[pscustomobject]@{arquivados=$arquivadosOrganizacao.Count;movidos=$movidosOrganizacao.Count;caches=$cachesOrganizacao.Count;bytes_caches=$bytesCachesOrganizacao;pastas=$vaziasOrganizacao.Count;recibo=$saidaOrganizacao} | ConvertTo-Json
