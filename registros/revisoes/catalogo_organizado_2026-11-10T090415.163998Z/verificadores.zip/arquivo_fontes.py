"""Consulta e recuperacao verificadas das fontes de desenvolvimento encerrado."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
from zipfile import ZipFile


class ArquivoFontes:
    def __init__(self, raiz):
        self.raiz = Path(raiz).resolve()
        self.indice = self.raiz / 'arquivo/desenvolvimento_encerrado/indice.json'
        self.dados = json.loads(self.indice.read_bytes()) if self.indice.exists() else {'entradas': {}}
        self.entradas = self.dados['entradas']
        self.zip = None
        if self.entradas:
            pacote = self.local(self.dados['pacote'])
            if hashlib.sha256(pacote.read_bytes()).hexdigest() != self.dados['pacote_sha256']:
                raise ValueError('Pacote historico divergente do indice')
            self.zip = pacote
            for nome, entrada in self.entradas.items():
                self.normalizar(nome)
                self.normalizar(entrada.get('membro', nome))
                if entrada.get('destino'):
                    self.local(entrada['destino'])

    @staticmethod
    def normalizar(nome):
        texto = str(nome).replace('\\', '/')
        p = PurePosixPath(texto)
        if p.is_absolute() or '..' in p.parts or ':' in texto or texto in ('', '.'):
            raise ValueError(f'Caminho historico invalido: {nome}')
        return p.as_posix()

    def local(self, nome):
        p = (self.raiz / self.normalizar(nome)).resolve()
        if not p.is_relative_to(self.raiz):
            raise ValueError('Destino historico fora do repositorio')
        return p

    def contem(self, nome):
        return self.normalizar(nome) in self.entradas

    def ler(self, nome):
        nome = self.normalizar(nome)
        entrada = self.entradas[nome]
        if entrada['tipo'] == 'movido':
            dados = self.local(entrada['destino']).read_bytes()
        else:
            with ZipFile(self.zip) as pacote:
                dados = pacote.read(entrada.get('membro', nome))
        if hashlib.sha256(dados).hexdigest() != entrada['sha256']:
            raise ValueError(f'Fonte historica divergente: {nome}')
        return dados

    def original(self, nome):
        nome = self.normalizar(nome)
        entrada = self.entradas[nome]
        with ZipFile(self.zip) as pacote:
            dados = pacote.read(entrada.get('membro', nome))
        if hashlib.sha256(dados).hexdigest() != entrada['sha256']:
            raise ValueError(f'Fonte original divergente: {nome}')
        return dados

    def extrair(self, destino, prefixo=''):
        destino = Path(destino).resolve()
        if destino.exists():
            raise FileExistsError('Use uma pasta de destino nova; nao sobrescrever arquivos')
        selecionados = [p for p in self.entradas if p.startswith(prefixo)]
        dados = {p: self.original(p) for p in selecionados}
        destino.mkdir(parents=True, exist_ok=False)
        for nome, conteudo in dados.items():
            p = (destino / nome).resolve()
            if not p.is_relative_to(destino):
                raise ValueError('Extracao fora do destino')
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(conteudo)
        return len(dados)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('acao', choices=['listar', 'conferir', 'extrair'])
    p.add_argument('--prefixo', default='')
    p.add_argument('--destino', type=Path)
    a = p.parse_args()
    arquivo = ArquivoFontes(Path(__file__).resolve().parents[1])
    nomes = sorted(n for n in arquivo.entradas if n.startswith(a.prefixo))
    if a.acao == 'listar':
        print(json.dumps({n: arquivo.entradas[n] for n in nomes}, ensure_ascii=False, indent=2))
    elif a.acao == 'conferir':
        for nome in nomes:
            arquivo.ler(nome)
            arquivo.original(nome)
            e = arquivo.entradas[nome]
            if e.get('destino') and hashlib.sha256(arquivo.local(e['destino']).read_bytes()).hexdigest() != e.get('sha256_destino', e['sha256']):
                raise ValueError(f'Destino reorganizado divergente: {nome}')
        print(json.dumps({'status': 'conferido', 'fontes': len(nomes)}))
    else:
        if a.destino is None:
            p.error('--destino e obrigatorio para extrair')
        print(json.dumps({'extraidos': arquivo.extrair(a.destino, a.prefixo)}))


if __name__ == '__main__':
    main()
