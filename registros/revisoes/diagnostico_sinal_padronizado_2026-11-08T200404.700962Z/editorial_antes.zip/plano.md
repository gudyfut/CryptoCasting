# Plano de trabalho

Atualizado em 08/11/2026. Rodada de **padronização dos seis canais diários concluída e conferida**, execução `f3f8772670f244779ad7`. [Estado](registros/padronizacao_diaria/estado.json), [protocolo preservado](docs/protocolo_padronizacao_diaria.md), [análise na cronologia](docs/andamento.md), [conferência independente](registros/padronizacao_diaria/conferencias/2026-11-08T080345.207956_0000/conferencia.json).

Foram concluídos os quatro ajustes de 1000 épocas, controle exato e 70 carteiras. Referência de retorno `de09c2193737c2581261` herdada sem retreino; preservação aprovada. A análise separa a média das métricas/carteiras individuais da carteira que opera a média das previsões (ensemble). Não promover uma versão apenas pelo lucro retrospectivo ou pelo erro agregado.

Próximo passo a decidir com o pesquisador: investigar a estabilidade da calibração e dos sinais entre seeds e períodos antes de outra alteração. O ensemble previamente definido é resultado secundário relevante, mas sua concentração temporal e por lado, risco na validação e sensibilidade aos custos limitam a conclusão. Qualquer hipótese nova exige escopo e comparação previamente definidos; não escolher filtros no teste.

2024 selecionou checkpoints; 2025 já foi consultado e é retrospectivo. A autorização da padronização terminou. Nenhum treinamento adicional iniciado. A [cronologia](docs/andamento.md) e o [catálogo](registros/catalogo_estudos.json) preservam resultados, incidentes e decisões anteriores.
