# Plano de trabalho

Atualizado em 08/11/2026. Autorizado testar **Adam com weight_decay zero**, mantendo o desenho diário padronizado. [Protocolo](docs/protocolo_sem_penalizacao_diaria.md), [ADR0035](docs/adr/0035-sem-penalizacao-diaria.md). Qualificação aprovada; execução `8a0aeee4d78503b7f50d` congelada e lançador iniciado. [Estado real](registros/sem_penalizacao_diaria/estado.json). Treino real iniciado em08/11 às19:19 de Brasília; primeiras épocas da seed42 e observações registradas, sem erro. Controle real ainda pendente.

- Referência `f3f8772670f244779ad7` preservada, sem retreino.
- Mesmas entradas, escalas, alvo, arquitetura, Adam/taxa/scheduler, seleção e simulação; apenas coeficiente de penalização0,001→0.
- Quatro ajustes de1000épocas:42→controle42→17→2026; controle excluído das médias e aprovado antes da grade restante/teste.70carteiras.
- Observar contribuição dos ramos e normas/gradientes em épocas fixas sem alterar trajetória ou seleção. Qualificar equivalência exata antes de iniciar.
- Após conclusão, conferir previsões/carteiras, comparação pareada, observações e preservação. Não promover por maior amplitude ou lucro isolado.

2024selecionou checkpoints;2025já consultado, retrospectivo. Nenhuma hipótese adicional autorizada. [Cronologia](docs/andamento.md), [catálogo](registros/catalogo_estudos.json).
