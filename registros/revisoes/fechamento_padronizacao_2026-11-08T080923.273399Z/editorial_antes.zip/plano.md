# Plano de trabalho

Atualizado em07/11/2026. Etapa autorizada: **padronização dos seis canais do modelo diário de retorno**. [Protocolo](docs/protocolo_padronizacao_diaria.md), [ADR0034](docs/adr/0034-padronizacao-diaria.md). Execução `f3f8772670f244779ad7` lançada em07/11 às19:29Brasília, seed42. [Estado verificável](registros/padronizacao_diaria/estado.json). Qualificação aprovada; controle real completo ainda pendente.

- Referência de retorno preservada: `de09c2193737c2581261`; nenhuma repetição dos seus treinamentos.
- Única alteração: z-score por canal nos candles únicos usados nas janelas do treino; parâmetros fixos em validação/teste.
- Mesmo BTCUSDTUSD-M, candles diários, contexto14dias, treino2020–2023/validação2024/teste2025, alvo retorno simples decimal.
- Mesma arquitetura64/3×4, Adam0,01/decay0,001, StepLR100/0,5, lote32,RMSE e1000épocas.
- Sequência42→controle42→17→2026. Controle excluído das médias e aprovado antes das outras seeds.
-70carteiras, mesmos custos/funding/políticas. Comparação pareada, médias individuais e ensemble separados; avaliar erro, calibração, risco e lucro sem promoção automática.

Conferir qualificação CUDA, fontes, dados, escalas, ambiente e ausência de processos antes de iniciar. Falha interrompe, sem repetição automática. Após conclusão, conferir comparação/contabilidade/preservação em leitura posterior.2024/2025já consultados, não novo holdout. Nenhuma hipótese adicional autorizada.

A [cronologia](docs/andamento.md) e o [catálogo](registros/catalogo_estudos.json) preservam resultados, incidentes e decisões anteriores.
