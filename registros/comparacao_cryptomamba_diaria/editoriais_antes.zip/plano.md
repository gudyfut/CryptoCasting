# Plano de trabalho

Atualizado em **11/11/2026**. A prioridade é desenvolver a investigação e a redação do TCC conforme as [diretrizes de pesquisa](docs/diretrizes_pesquisa.md): comparar configurações e registrar conclusões fundamentadas, mesmo sem obter um modelo adequado à operação no mercado.

## Próximos passos

**Ensemble em2026 concluído:** mesmos12checkpoints e escalas, sem novos treinos,314decisões por moeda de01/01 a10/11.24carteiras e12controles exatos de previsão aprovados. Superou comprar/manter nas quatro moedas, mas ETH permaneceu negativo e os intervalos principais incluem zero. [Resultado e limites](docs/andamento.md#11112026--ensemble-preservado-avaliação-temporal-em-2026), [exposição](registros/ensemble_2026/exposicao.json), [fechamento](registros/ensemble_2026/fechamento.json), [protocolo](docs/protocolo_ensemble_2026.md). Incidente e continuação técnica preservados.2026 agora foi avaliado; não reutilizá-lo como reserva intocada nem alterar receita automaticamente pelo resultado. Escopo cumprido.

**Avaliação operacional concluída em11/11:** continuidade das posições aplicada à receita diária padronizada completa deBTC/ETH/BNB/XRP, três seeds, ensemble e referências.408carteiras conferidas, sem retreinar redes; ARIMA diário novo ajustado apenas no treino, selecionado por erro de validação. A mudança reduz giro, mas só ETH tem lucro médio em2025 e sua queda máxima continua elevada. [Marco ADR0037](docs/adr/0037-continuidade-posicoes-diarias.md), [resultado e limites](docs/andamento.md#11112026--marco-operacional-continuidade-das-posições-diárias), [fechamento](registros/continuidade_moedas/fechamento.json). Originais e tentativa técnica preservados; filtros por ordem corrigidos em identidade própria. Não interfere na rodada de taxa abaixo nem autoriza novo ciclo.

**Ablação da taxa concluída em 11/11/2026:** Adam0,001 versus0,01, ambas sem penalização, BTC, seeds42/17/2026 e controle42. Execução `64c5a9532894252c7b88` encerrada às13h17BRT; três principais, controle exato e70carteiras conferidos. [Resultado e interpretação](docs/resultados_taxa_diaria.md), [fechamento](registros/taxa_diaria/fechamento.json), [conferência independente](registros/taxa_diaria/conferencia_posterior.json) e [estado](registros/taxa_diaria/estado.json). A hipótese não melhorou a referência; preservar ambas, sem promoção ou reinício automático.

**Retomada na próxima sessão:** consultar a [receita do ensemble](docs/arquitetura_modelos.md), o [índice dos12checkpoints](registros/ensemble_2026/modelos_utilizados.json), os [resultados de2026](registros/ensemble_2026/entrega.json) e a [cronologia](docs/andamento.md). Treinos e avaliações solicitados estão encerrados. Definir com o pesquisador quais conclusões/configuração entram no fechamento do desenvolvimento e na redação, sem iniciar novas buscas ou atualizar modelos por inferência desta passagem de contexto. Pesos e scalers permanecem nos estudos originais; os índices fazem os vínculos.

Incorporar resultados favoráveis, negativos e limites à redação pelo [roteiro](docs/roteiro_redacao_tcc.md). O [diagnóstico publicado](registros/taxa_diaria/diagnostico.json) conserva receitas anteriores, decomposição de erros e referências simples.2024–2025 são retrospectivos; a exposição de01/01–10/11/2026 foi auditada e esse período já foi avaliado. Outros intervalos exigem auditoria própria antes de qualquer alegação de reserva independente. O orçamento autorizado está cumprido.

1. Consolidar o que as comparações existentes sustentam e quais perguntas permanecem abertas: entradas, alvo, treinamento dos pesos, estrutura, estabilidade e utilidade das previsões. Usar o [roteiro de redação](docs/roteiro_redacao_tcc.md), a [narrativa](escrita_tcc/cronologia_narrativa/narrativa_desenvolvimento.md) e as evidências vinculadas, distinguindo achados de hipóteses.
2. Escolher, com o pesquisador, o próximo recorte que acrescente conhecimento ao TCC. Pode ser análise dos artefatos existentes, revisão de literatura, redação ou novo experimento; não é obrigatório buscar outra estratégia operacional.
3. Para qualquer novo experimento, delimitar pergunta, comparação, critérios de avaliação, orçamento e condição de encerramento pelo [procedimento de registro](docs/registro_de_experimentos.md). Outras hipóteses permanecem propostas até definição e autorização de seu escopo.
4. Incorporar aprendizados à escrita durante a investigação, com referência à evidência e às limitações. Não adiar a conclusão acadêmica até surgir lucro ou superioridade preditiva.

Esta revisão das orientações, por si só, não autoriza novos treinamentos. As autorizações dos ciclos encerrados acima já foram cumpridas. Trabalhos futuros seguem o escopo explicitamente solicitado, sem confirmação redundante quando ele já estiver autorizado.

## Referências de estado e contexto

| Assunto | Evidência a consultar |
|---|---|
| Generalização diária encerrada, BTC herdado e continuação identificada de XRP | [Estado](registros/generalizacao_moedas/estado.json), [fechamento](registros/generalizacao_moedas/fechamento.json), [comparação das quatro moedas](registros/generalizacao_moedas/comparacao_quatro_moedas.json) |
| Receita, qualificação, fontes e exceções de dados dessa rodada | [Protocolo congelado](docs/protocolo_generalizacao_moedas.md), [ponteiro da execução](registros/generalizacao_moedas/execucao.json) e [ADR0036](docs/adr/0036-generalizacao-tres-moedas.md) |
| Releitura financeira vigente, concluída sem treino | [Configuração](configuracoes/custos_vigentes_001.json), [execução](registros/custos_vigentes/execucao.json), [publicação conferida](registros/custos_vigentes/vigente.json) |
| Sensibilidade dos custos | [Recibo](registros/generalizacao_moedas/custos/ultima.json) |
| Trajetória, estudos e exploração assistida por IA | [Cronologia](docs/andamento.md), [catálogo](registros/catalogo_estudos.json), [síntese histórica](docs/exploracao_ia.md) |

A receita diária, os dados oficiais e suas exceções permanecem congelados sob as identidades originais. Não completar lacunas nem mudar filtros, alvos ou seleção retrospectivamente. A apresentação financeira usa slippage **provisório de 0,01% por lado**, mantendo taxas/funding; isso não certifica custo real histórico Binance. Os 5 bp anteriores permanecem na evidência original.

2024 selecionou checkpoints e 2025 já foi consultado na família diária. Interpretações desse material são retrospectivas; comparações e redação devem conservar esses limites. Conferir estado/processos na máquina executora antes de qualquer ação operacional; um documento não comprova disponibilidade local ou ausência de processo vivo.
