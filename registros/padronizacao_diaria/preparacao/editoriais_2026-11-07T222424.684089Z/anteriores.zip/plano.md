# Plano de trabalho

Atualizado em07/11/2026. Etapa concluída: **comparar alvo de retorno simples diário com alvo de preço**, mantendo o restante da receita. [Protocolo](docs/protocolo_alvo_retorno_diario.md), [ADR0033](docs/adr/0033-alvo-retorno-diario.md), [estado verificável](registros/retomada_alvo_diario/estado.json).

Tentativa `1dbfa7ae982c8060367d` interrompida na época760 da primeira seed após mudança de boot WSL; preservada. Reinício operacional autorizado, mesma receita e quatro ajustes completos, novo coordenador/identidade. Consultar estado atual para início real.

## Rodada

- Referência de preço preservada: `ac8183e1ecfb91102b48`. Nenhum novo treinamento dessa versão.
- Mesmo BTCUSDT/BinanceUSD-M, treino2020–2023, validação2024, teste2025 retrospectivo; entradas timestamp+OHLCV,14dias, sem scaler novo.
- Alvo retorno simples decimal; RMSE por lote e seleção global em retorno. Preço equivalente calculado pelo último fechamento conhecido para o mesmo simulador.
- Mesma arquitetura64/3×4 e backend reproduzível, Adam0,01, decay0,001, StepLR100/0,5, lote32,1.000épocas.
- Quatro ajustes:42principal,42controle,17,2026; controle fora das médias. Teste e70carteiras somente após controle/treinos.
- Política24h/custos/funding/cenários idênticos. Comparação pareada nas mesmas seeds/origens, métricas comuns de retorno e preço; ensemble separado.

## Qualificação e leitura posterior

23testes aprovados,60repetições de gradientes/saídas exatas e dois ajustes artificiais de50épocas exatos. Execução `de09c2193737c2581261` concluída às10:20 de Brasília, com controle exato,4/4ajustes e70/70carteiras. Conferência independente de404arquivos, seis séries e11.968operações aprovada; evidência na cronologia.

Diagnóstico posterior concluído: [recibo](registros/retomada_alvo_diario/diagnosticos/conclusao_calibracao.json). A queda do erro veio sobretudo de menor dispersão/viés, sem melhor correlação operacional em2025. Sinais pequenos e custos explicam a perda; compensação constante de viés estimada em2024 não se transferiu.

Próxima hipótese proposta, ainda sem autorização de treinamento: padronizar os seis canais (média/desvio por canal nos candles únicos das janelas de treino2020–2023; aplicar parâmetros fixos a2024/2025, sem clipping), mantendo alvo de retorno e demais fatores. Mesmas três seeds+controle, referência de retorno herdada, seleção por RMSE de validação e política/custos atuais. Congelar novo protocolo antes de qualquer ajuste. Verificar MSE/MAE, correlação/calibração, estabilidade e lucro/drawdown; promoção operacional não decorre de MSE isolado. A troca de alvo melhorou o erro médio contra preço, mas piorou as operações de2025; não promover automaticamente. Não selecionar seed ou política favorável retrospectivamente. Nenhuma busca de outros hiperparâmetros autorizada.

A rodada anterior concluiu sem lucro robusto; a [cronologia](docs/andamento.md) guarda análise e evidências.2024–2025já consultados; esta comparação não cria novo holdout intocado.
