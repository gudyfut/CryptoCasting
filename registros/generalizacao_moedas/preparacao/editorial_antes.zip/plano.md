# Plano de trabalho

Atualizado em 09/11/2026. A ablação **Adam com weight_decay zero** terminou, com controle exato e conferência posterior. [Estado](registros/sem_penalizacao_diaria/estado.json), [análise e evidências](docs/andamento.md), [catálogo](registros/catalogo_estudos.json). Execução `8a0aeee4d78503b7f50d` e referência `f3f8772670f244779ad7` preservadas; autorização encerrada.

Os ramos Mamba permaneceram ativos nas sondas, sem vantagem preditiva/operacional demonstrada. Treino exibiu sobreajuste nas seeds 42/17 e instabilidade extrema na seed 2026. A próxima hipótese recomendada, **ainda não autorizada**, é reduzir somente a taxa inicial do Adam de 0,01 para 0,001, usando a versão sem penalização como referência imediata. Manter seeds, entradas/escalas, alvo, arquitetura, lote, perda, StepLR, seleção e política. Não combinar clipping, AdamW, troca de canais ou regularização nessa comparação.

Antes de executar outra rodada, definir protocolo/identidade/orçamento e obter autorização. Preservar comparação com as duas referências anteriores. Sucesso exige estabilidade e erros/operacional melhores; contribuição funcional e amplitude maiores, isoladamente, não aprovam modelo. A taxa menor é hipótese motivada pelo histórico, não causa demonstrada nem promessa de lucro. Revisar entradas em nível e eixo do scan como hipóteses separadas, caso necessário.

2024 selecionou checkpoints; 2025 já consultado, retrospectivo. Não usar mais épocas, seeds ou consulta aos mesmos anos como substituto de mercados independentes. [Cronologia](docs/andamento.md), [protocolo encerrado](docs/protocolo_sem_penalizacao_diaria.md).
