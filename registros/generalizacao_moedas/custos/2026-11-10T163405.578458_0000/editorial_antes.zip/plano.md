# Plano de trabalho

Atualizado em10/11/2026. Generalização da receita diária padronizada encerrada: ETH/BNB e continuação de XRP concluídos, BTC herdado. [Estado](registros/generalizacao_moedas/estado.json), [fechamento](registros/generalizacao_moedas/fechamento.json), [comparação das quatro moedas](registros/generalizacao_moedas/comparacao_quatro_moedas.json), [cronologia](docs/andamento.md).

Foram nove ajustes principais e três controles novos,1000épocas cada,210carteiras. XRP recomeçou somente a seed interrompida, em pasta própria; as390épocas anteriores foram reproduzidas exatamente. ETH/BNB e tentativa incompleta preservados. Os controles ficaram fora das médias.

Próxima etapa: discutir os limites preditivos, a instabilidade entre seeds, o colapso funcional dos ramos e a sensibilidade a custos, antes de autorizar qualquer hipótese. Uma taxa inicial menor permanece proposta; não iniciar automaticamente. Menor erro e lucro pontual não promovem um modelo final. Validação2024 selecionou; teste2025 retrospectivo já consultado.

Usar as evidências para a redação: média das três seeds por moeda, Naive, operações e riscos separados, ensemble identificado como outro sistema. Não ordenar moedas por erro em USDT nem somar retornos de carteiras. Organização local não comprova backup externo. [Catálogo](registros/catalogo_estudos.json) e [roteiro de redação](docs/roteiro_redacao_tcc.md).
