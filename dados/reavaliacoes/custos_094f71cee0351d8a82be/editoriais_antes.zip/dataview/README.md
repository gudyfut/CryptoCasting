# Evolução da pesquisa CryptoCasting

Interface local com dez fases da pesquisa, das primeiras tentativas à generalização para ETH, BNB e XRP. A visão geral começa pelo estágio atual; cada fase explica a pergunta, a alteração, a conclusão e seus limites. **Resultados e conclusões** compara as receitas diárias de BTC, separa carteiras individuais de ensemble e permite imprimir. **Como avaliamos** explica o método atual e mantém o desenho histórico em uma seção recolhida.

Os 14 testes detalhados do panorama OHLCV de 03/11, seus gráficos e 205 séries permanecem acessíveis na terceira fase. O modo **Apresentar** usa ←/→ e Esc. Links antigos com `?etapa=` continuam funcionando.

Cada fase abre com um resumo em cinco linhas: entrada, rede, treino, avaliação e operação. Até três mudanças principais aparecem como antes → depois; um destaque amarelo discreto identifica alterações. Fases com várias receitas têm um seletor, e a comparação pode usar a fase anterior ou a referência científica. A configuração integral, todas as diferenças e as fontes ficam recolhidas em **Consultar configuração completa**, sem remover os parâmetros originais.

## Executar

Executar npm neste diretório:

```sh
npm run dev
```

Abrir http://localhost:3000. Para a versão de produção: `npm run build` e `npm start`. A interface requer o repositório e os artefatos locais; não foi publicada em serviço externo.

## Dados e rastreabilidade

`scripts/exportar_panorama.py` exporta resultados existentes. Executado a partir da raiz do repositório, requer Python, pandas, NumPy e o leitor Parquet já disponíveis no ambiente científico:

```sh
python dataview/scripts/exportar_panorama.py
```

Ele confere manifestos, hashes das previsões e históricos de épocas, alinhamento de 24h, preço/alvo e o MSE de todas as origens horárias. Não importa treinadores e não inicia treinamento, inferência ou backtest. Escreve apenas o snapshot da apresentação (`src/data/panorama.json`), as séries em `dados/portal_panorama/series/` e o recibo em `registros/interface/panorama_20261103/exportacao.json`.

O snapshot atual reúne 205 séries de previsões salvas. O explorador mostra uma origem diária às 00h UTC para facilitar a leitura; as métricas publicadas usam a população horária completa. O gráfico liga previsões terminais independentes, sem representar uma trajetória prevista dentro do dia. O CSV contém os exemplos diários da série selecionada. O primeiro exemplo usa a seed 42 por convenção, sem seleção por resultado.

O servidor confere a disponibilidade e a integridade das fontes originais. Os endpoints `/api/panorama/serie` e `/api/panorama/fonte` aceitam somente identidades e caminhos da exportação e verificam SHA-256 antes da entrega. Ausência local recebe aviso explícito; nunca gera resultado artificial. Para usar em outra máquina, preservar/restaurar as fontes e as séries conforme a política de armazenamento do projeto.

Os resultados posteriores são lidos por `src/lib/evolucao-servidor.ts`, sem chamar executores científicos. Resumos e carteiras são verificados contra os hashes dos fechamentos. Fontes narrativas também têm uma lista explícita de caminhos e hashes. Ausências ou divergências não são preenchidas com zero. O snapshot histórico e seu recibo não são regenerados para incluir fases novas.

`src/lib/fichas-servidor.ts` lê configurações, receitas efetivamente ajustadas e protocolos por uma lista fixa de fontes com SHA-256. Não chama treinamento nem regenera resultados. `src/lib/fichas.ts` mantém os campos comparáveis; `FichaTecnica.tsx` exibe seus valores e diferenças. Uma fonte ausente ou alterada impede exibir a ficha dependente, em vez de presumir parâmetros. As fontes originais completas ficam acessíveis no rodapé da ficha.

O estágio atual lê o estado operacional e o progresso do ajuste, atualizando a página a cada minuto enquanto estiver visível. Mostra a data do registro e sinaliza registros antigos; um arquivo de progresso não é prova independente de processo vivo. XRP aparece sem métricas até haver publicação completa e recibo de fechamento da continuação. As três publicações não substituem a auditoria conjunta.

Controles não entram nas médias. Carteiras são independentes; ensemble combina previsões antes da operação. 2024 selecionou checkpoints e 2025 já foi consultado. Não há ranking único entre populações, moedas e políticas diferentes.

## Verificação

```sh
npm test
node --test tests/panorama.integration.mjs
npm run build
```

O teste de integração exige o servidor ativo em `http://127.0.0.1:3000`. Os testes verificam as 205 séries, pareamentos, médias, incerteza, custos, cronologia, resultados recentes e entrega pela API. A revisão visual inclui desktop/celular, navegação entre fases, conclusões e detalhes históricos.

A interface anterior foi substituída na navegação. Os componentes e endpoints históricos permanecem sem uso pela página nova, preservando os artefatos e testes anteriores. O aceite antigo está em `registros/interface/aceite_final.json`; a evidência desta entrega fica em `registros/interface/panorama_20261103/`.

## Fontes da trajetória

A fase de busca com IA está consolidada em [Exploração do processo de melhoria com IA](../docs/exploracao_ia.md). A [cronologia do projeto](../docs/andamento.md), o catálogo e as publicações científicas sustentam as etapas posteriores. A interface é uma leitura desses resultados; não inicia, retoma ou altera treinamentos.
