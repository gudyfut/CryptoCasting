# CryptoCasting

TCC sobre previsão com Mamba, dados OHLCV e avaliação de utilidade operacional. Os estudos acadêmicos anteriores usam LSTM, Naive e ARIMA como referências; a linha posterior investiga também políticas de operação em futuros.

## Situação atual

Etapa atual: [generalização da receita diária padronizada para ETH, BNB e XRP](docs/protocolo_generalizacao_moedas.md), concluída e conferida em10/11/2026. Modelos independentes por moeda, referência BTC preservada; [comparação das quatro moedas](registros/generalizacao_moedas/comparacao_quatro_moedas.json); consultar o [estado real](registros/generalizacao_moedas/estado.json), [plano](plano.md) e [cronologia](docs/andamento.md). A rodada sem penalização está encerrada; não há modelo/backtest final promovido. A [exploração com IA](docs/exploracao_ia.md) permanece histórica.

| Para quê | Onde começar |
|---|---|
| Entender a exploração posterior à interface | [Síntese única](docs/exploracao_ia.md) |
| Ver o próximo passo | [Plano](plano.md) |
| Consultar documentação e metodologia | [Índice documental](docs/README.md) |
| Localizar uma execução/evidência | [Catálogo](registros/catalogo_estudos.json), [mapa dos registros](registros/README.md) |
| Acompanhar a trajetória acadêmica até 03/11 | [Panorama web](dataview/README.md) |
| Trabalhar no código | [Orientações](AGENTS.md) |
| Preparar a escrita e receber o projeto LaTeX | [Espaço de escrita do TCC](escrita_tcc/README.md) |

## Estrutura

`mercado_binance/` e `mercado_futuros/` fornecem dados; `entradas_modelo/` define canais/alvos/janelas; `modelos/`, `treinamento/` e `avaliacao/` tratam previsão; `simulacao_operacoes/` separa políticas e execução. `experimentos/` identifica ciclos e `analises/` contém leituras posteriores.

Receitas ficam em `configuracoes/`, evidências em `registros/`, modelos/previsões/publicações em `dados/experimentos/` e diagnósticos em `dados/diagnosticos/`. O [mapa dos dados](dados/README.md) explica esses limites. Os [leitores posteriores](analises/README.md) estão agrupados por etapa.

Executores encerrados, testes específicos antigos, scripts avulsos e versões editoriais anteriores foram retirados da área de trabalho e preservados em [um pacote histórico verificável](arquivo/desenvolvimento_encerrado/README.md). O índice conserva cada caminho e hash original. As dependências do núcleo e as fontes exigidas pelo treinamento em andamento permanecem nos caminhos atuais.

A interface usa `npm run dev` dentro de `dataview/`; ela apresenta o estudo até 03/11, não todos os ciclos posteriores. Para verificar o repositório organizado: `python -m manutencao.auditar_repositorio --integridade --exigir-completo`. Esse comando mantém os critérios do auditor anterior e localiza explicitamente as fontes originais no pacote histórico. Não reabre treinamentos.

Dados volumosos e checkpoints locais não são baixados automaticamente pelo Git. Consultar a [política de preservação](docs/armazenamento_e_reproducao.md) antes de transferir de máquina. Organização local não equivale a backup externo.
